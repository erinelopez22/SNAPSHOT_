﻿$(document).ready(function () {
    var AllowAdd;
    var AllowEdit;
    var AllowDelete;
    var AllowView;
    var AllowPrint;
    var AllowImport
    var AllowExport;
    var AllowPost;
    var AllowUnpost;
    var AllowApprove;

    $.ajax({
        type: "POST",
        url: "/CBS/Common/Permissions",
        success: function (data) {
            data = JSON.parse(data)
            AllowAdd = data[0]["Add"]
            AllowEdit = data[0]["Edit"];
            AllowDelete = data[0]["Delete"];
            AllowView = data[0]["View"];
            AllowPrint = data[0]["Print"];
            AllowImport = data[0]["Import"];
            AllowExport = data[0]["Export"];
            AllowPost = data[0]["Post"];
            AllowUnpost = data[0]["Unpost"];
            AllowApprove = data[0]["Approve"];
        },
        async: false

    })
    //-------------------------------

    function getBool(val) {
        return !!JSON.parse(String(val).toLowerCase());
    }
    //-----------------------------------------------------------------



    $.post("/CBS/SystemUpdateLogs/GetSystemUpdate")
    .done(function (data) {
        data = JSON.parse(data);

        if (data.length == 1) {
            $('#AppVersion').text("Version: " + data[0].Version);
            $("#SystemUpdate").text(data[0].SystemUpdates)
            $("#ModAppUpdate").modal("show");
        }
    })
        .fail(function (stat, msg, custom) {
            toastr.warning(stat.status + ": " + custom)
        });
    //------------------------------------------------------------
    $("#ModAppUpdate").on("click", "#btnok", function () {
        $.post("/CBS/SystemUpdateLogs/UpdateUserID", function () { })
        $("#ModAppUpdate").modal("hide");
    })
    //------------------------------------------------------------
    function GetAllLogs() {
        $("#tblSysUpdateLogs_header tbody tr").remove();
        $("#tblSysUpdateLogs_header").DataTable().clear().draw();
        $("#tblSysUpdateLogs_header").DataTable().destroy();
        $.post("/CBS/SystemUpdateLogs/GetAllLogs")
        .done(function (data) {
            data = JSON.parse(data);
            var tblSysUpdateLogs_Body = $("#tblSysUpdateLogs_Body");
            tblSysUpdateLogs_Body.html("");
            $(data).each(function (i, logs) {
                tblSysUpdateLogs_Body.append('<tr>' +
                    '<td>' + logs.ID + '</td>' +
                    '<td>' + logs.Version + '</td>' +
                    '<td>' + logs.SystemUpdates + '</td>' +
                    '<td>' + moment(logs.DateCreated).format('MM-DD-YYYY HH:mm') + '</td>' +

                      '<td align="right">' +
                  ' <div class="btn-group btn-group-rounded" role="group"> ' +
                      '  <button id="btnDelete" type="button" class="btn btn-outline-primary btn-xs" title="click to Delete" ' +
                                 'data-ID="' + logs.ID + '"' +
                            '> ' +
                      '     <i class="fa fa-trash mr-5"></i> Delete ' +
                      '  </button> ' +
                  '  </div> ' +
                   '</td>' +


                    '</tr>')
            })

            $("#tblSysUpdateLogs_header").DataTable({
                scrollX: true
            }).draw();

        })
        .fail(function (stat, msg, custom) {
            toastr.warning(stat.status + ": " + custom)
        });

    }

    GetAllLogs();

    //------------------------------------------------------------
    $("#tblSysUpdateLogs_header").on("click", "#btnDelete", function () {


        if (getBool(AllowDelete) == false) {
            toastr.info("Access Denied!", "Notification");
            return;
        }


        var logID = $(this).attr("data-ID");

        $.confirm({
            title: "Confirmation",
            content: "Delete Logs?",
            buttons: {
                yes: function () {
                    $(".preloader-it").fadeIn(); //show
                    $.post("/CBS/SystemUpdateLogs/DeleteLog", { ID: logID })
                      .done(function () {
                          $(".preloader-it").fadeOut("slow");
                          toastr.success("Record successfully deleted.")
                          GetAllLogs();
                      })
                      .fail(function (stat, msg, custom) {

                          $(".preloader-it").fadeOut("slow");
                          toastr.warning(stat.status + ": " + custom)
                      });


                },
                cancel: function () { }
            }

        })



    })
    //------------------------------------------------------------
    $("#btnNew").on("click", function () {

        if (getBool(AllowAdd) == false) {
            toastr.info("Access Denied!", "Notification");
            return;
        }



        $("#versionNo").val("");
        $("#SystemUpdate").val("");
        $("#modDetail").modal("show");

    })
    //------------------------------------------------------------
    $("#modDetail").on("click", "#btnSave", function () {
        var ver = $("#versionNo").val();
        var updates = $("#SystemUpdate").val();


        if (ver == "") {
            toastr.info("Version No. is required", "Notification");
            return;
        }
        else if (updates == "") {
            toastr.info("Update Detail(s) are required", "Notification");
            return;
        }

        $.confirm({
            title: "Confirmation",
            content: "Save system update(s)?",
            buttons: {
                yes: function () {

                    $.post("/CBS/SystemUpdateLogs/InserNewUpdate", { verNo: ver, NewUpdates: updates })
                     .done(function () {
                         $(".preloader-it").fadeOut("slow");
                         $("#modDetail").modal("hide");
                         toastr.success("Record successfully Saved.")
                         GetAllLogs();
                     })
                    .fail(function (stat, msg, custom) {
                        $(".preloader-it").fadeOut("slow");
                        toastr.warning(stat.status + ": " + custom)
                    });


                },
                cancel: function () { }

            }

        })




    })



})



