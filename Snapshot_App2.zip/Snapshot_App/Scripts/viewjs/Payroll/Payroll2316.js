﻿$(document).ready(function () {
    document.getElementById('btnSave_P2316').disabled = true;
    document.getElementById('btnExport_P2316').disabled = true;
    document.getElementById('lblNEW_P2316').style.visibility = 'hidden';
    var is_Exist;
    //-----------------------------------------
    function OnLoad() {
        $.post("/CBS/Payroll/OnLoad")
            .done(function (data) {
                data = JSON.parse(data);

                var cboCorp_P2316 = $("#cboCorp_P2316");
                cboCorp_P2316.html("");
                $(data.Corps).each(function (index, val) {
                    cboCorp_P2316.append('<option value="' + val.CorpName + '">' + val.CorpName + '</option>');
                });

                document.getElementById('dtsd').valueAsDate = new Date()
                document.getElementById('dted').valueAsDate = new Date()


            })
            .fail(function (stat, msg, custom) {
                $(".preloader-it").fadeOut("slow");
                toastr.info(stat.status + ": " + custom)
            })
    }
    OnLoad();
    //-----------------------------------------

    function Generate(corp,dtfrm,dtto)
    {
        $(".preloader-it").fadeIn(); //show
        $("#tbl2316_Header tbody tr").remove();
        $("#tbl2316_Header").DataTable().clear().draw();
        $("#tbl2316_Header").DataTable().destroy();

        var IsExist;
        $.post("/CBS/Payroll2316/CheckifExist", { corp: corp, DtFrm: dtfrm, DtTo: dtto }, function (data) {
            IsExist = data;
            is_Exist = data;
        })
        
        $.post("/CBS/Payroll2316/Generate", { corp: corp, DtFrm: dtfrm, DtTo: dtto })
                .done(function (data) {
                    data = JSON.parse(data);
                    var tbl2316_Body = $("#tbl2316_Body");
                    tbl2316_Body.html('');

                    $(data).each(function (i, val) {
                        tbl2316_Body.append('<tr>' +
                             '<td>' + val.EmpCode + '</td>' +
                             '<td class="text-right">' + numeral(val.BasicPay).format("0,0.00") + '</td>' +
                             '<td class="text-right">' + numeral(val.Cola).format("0,0.00") + '</td>' +
                             '<td class="text-right">' + numeral(val.Overtime).format("0,0.00") + '</td>' +
                             '<td class="text-right">' + numeral(val.HazardPay).format("0,0.00") + '</td>' +
                             '<td class="text-right">' + numeral(val.HolidayPay).format("0,0.00") + '</td>' +
                             '<td class="text-right">' + numeral(val.a13thtax).format("0,0.00") + '</td>' +
                             '<td class="text-right">' + numeral(val.GovContri).format("0,0.00") + '</td>' +
                             '<td class="text-right">' + numeral(val.TotalTaxable).format("0,0.00") + '</td>' +
                             '<td class="text-right">' + numeral(val.OA3).format("0,0.00") + '</td>' +
                             '<td class="text-right">' + numeral(val.UnUsedLeave).format("0,0.00") + '</td>' +
                             '<td class="text-right">' + numeral(val.BirthdayCake).format("0,0.00") + '</td>' +
                             '<td class="text-right">' + numeral(val.Deminimis).format("0,0.00") + '</td>' +
                             '<td class="text-right">' + numeral(val.MATSalaryDifferential).format("0,0.00") + '</td>' +
                             '<td class="text-right">' + numeral(val.a13th).format("0,0.00") + '</td>' +
                             '<td class="text-right">' + numeral(val.OA4).format("0,0.00") + '</td>' +
                             '<td class="text-right">' + numeral(val.CondoCoordinator).format("0,0.00") + '</td>' +
                             '<td class="text-right">' + numeral(val.a13thNontax).format("0,0.00") + '</td>' +
                             '<td class="text-right">' + numeral(val.NonTaxable).format("0,0.00") + '</td>' +
                          '</tr>')
                    });
            
                    //  $("#tbl2316_Header").DataTable().draw();
                    $("#tbl2316_Header").DataTable({
                        ordering: false,
                        scrollX: true,
                        fixedColumns: {
                            leftColumns: 1
                        }
                    }).draw();

                    if ($("#tbl2316_Header").DataTable().rows().any() == true)
                        {
                        if (IsExist == 0) {
                            document.getElementById('lblNEW_P2316').style.visibility = 'visible';
                        }
                        else {
                            document.getElementById('lblNEW_P2316').style.visibility = 'hidden';
                        }
                        }

                        document.getElementById('btnSave_P2316').disabled = false;
                        document.getElementById('btnExport_P2316').disabled = false;


                    $(".preloader-it").fadeOut("slow");

                })
           .fail(function (stat, msg, custom) {
               document.getElementById('btnSave_P2316').disabled = true;
               document.getElementById('btnExport_P2316').disabled = true;

               $(".preloader-it").fadeOut("slow");
               toastr.info(stat.status + ": " + custom)
           })


    }

    //-----------------------------------------

    $("#btnGenerate_P2316").on('click', function () {
        var corp = $("#cboCorp_P2316").val();
        var dtsd = $("#dtsd").val();
        var dted = $("#dted").val();



               
        if (corp == "")
            {
                toastr.info("Company is required", "Notification")
                return;
            }
        else {
            Generate(corp, dtsd, dted);
        }
    })

    //-----------------------------------------
    

    $("#btnSave_P2316").on("click", function () {
        var corp = $("#cboCorp_P2316").val();
        var dtsd = $("#dtsd").val();
        var dted = $("#dted").val();

        var msg;

        if (is_Exist == "1")
            {
            msg = "Record/s already Exist, Would you like to overwrite?"
            }
        else
            {
                 msg =  "Save Record/s?"
        }

        var Generated = [];
        var data = $("#tbl2316_Header").DataTable().rows().data();
        data.each(function (value, index) {
            Generated.push({
                "EmpCode": value[0],
                "BasicPay": numeral(value[1]).value(),
                "Cola": numeral(value[2]).value(),
                "Overtime": numeral(value[3]).value(),
                "HazardPay": numeral(value[4]).value(),
                "HolidayPay": numeral(value[5]).value(),
                "a13thtax": numeral(value[6]).value(),
                "GovContri": numeral(value[7]).value(),
                "TotalTaxable": numeral(value[8]).value(),
                "OA3": numeral(value[9]).value(),
                "UnUsedLeave": numeral(value[10]).value(),
                "BirthdayCake": numeral(value[11]).value(),
                "Deminimis": numeral(value[12]).value(),
                "MATSalaryDifferential": numeral(value[13]).value(),
                "a13th": numeral(value[14]).value(),
                "OA4": numeral(value[15]).value(),
                "CondoCoordinator": numeral(value[16]).value(),
                "a13thNontax": numeral(value[17]).value(),
                "NonTaxable": numeral(value[18]).value()
            })
        })



        $.confirm({
            title: "Confirmation",
            content: msg,
            buttons: {
                yes: function () {
                    $(".preloader-it").fadeIn(); //show

                    if (is_Exist == "1")
                        {
                           $.post("/CBS/Payroll2316/DeleteExisting", { corp: corp, DtFrm: dtsd, DtTo: dted })
                            .done(function () {
                                $.post("/CBS/Payroll2316/Save2316", { Data: Generated, corp: corp, DtFrm: dtsd, DtTo: dted })
                                    .done(function () {
                                        is_Exist == "0";
                                        $(".preloader-it").fadeOut("slow");
                                        is_Exist = "1";
                                        document.getElementById('lblNEW_P2316').style.visibility = 'hidden';
                                        toastr.success("Record successfully Saved.", "Notification");
                                    })
                                    .fail(function (stat, msg, custom) {
                                        $(".preloader-it").fadeOut("slow");
                                        document.getElementById('lblNEW_P2316').style.visibility = 'visible';
                                        toastr.info(stat.status + ": " + custom)
                                    })

                            })
                              .fail(function (stat, msg, custom) {
                                  toastr.info(stat.status + ": " + custom)
                                  return;
                              })

                        }
                    else
                    {
                        $.post("/CBS/Payroll2316/Save2316", { Data: Generated, corp: corp, DtFrm: dtsd, DtTo: dted })
                            .done(function () {
                                $(".preloader-it").fadeOut("slow");
                                is_Exist = "1";
                                document.getElementById('lblNEW_P2316').style.visibility = 'hidden';
                                toastr.success("Record successfully Saved.", "Notification");
                            })
                            .fail(function (stat, msg, custom) {
                                $(".preloader-it").fadeOut("slow");
                                document.getElementById('lblNEW_P2316').style.visibility = 'visible';
                                toastr.info(stat.status + ": " + custom)
                            })
                    }

                
                },
                cancel: function () { }
            }

        })


    })

    //-----------------------------------------

    $("#btnExport_P2316").on("click", function () {

        var corp = $("#cboCorp_P2316").val();
        var dtsd = $("#dtsd").val();
        var dted = $("#dted").val();


        $.confirm({
            title: "Confirmation",
            content: "Export records?",
            buttons: {
                yes: function () {
                    $(".preloader-it").fadeIn(); //show
                    var Generated = [];
                    var data = $("#tbl2316_Header").DataTable().rows().data();
                    data.each(function (value, index) {
                        Generated.push({
                            "EmpCode": value[0],
                            "BasicPay": numeral(value[1]).value(),
                            "Cola": numeral(value[2]).value(),
                            "Overtime": numeral(value[3]).value(),
                            "HazardPay": numeral(value[4]).value(),
                            "HolidayPay": numeral(value[5]).value(),
                            "a13thtax": numeral(value[6]).value(),
                            "GovContri": numeral(value[7]).value(),
                            "TotalTaxable": numeral(value[8]).value(),
                            "OA3": numeral(value[9]).value(),
                            "UnUsedLeave": numeral(value[10]).value(),
                            "BirthdayCake": numeral(value[11]).value(),
                            "Deminimis": numeral(value[12]).value(),
                            "MATSalaryDifferential": numeral(value[13]).value(),
                            "a13th": numeral(value[14]).value(),
                            "OA4": numeral(value[15]).value(),
                            "CondoCoordinator": numeral(value[16]).value(),
                            "a13thNontax": numeral(value[17]).value(),
                            "NonTaxable": numeral(value[18]).value()
                        })
                    })


                    $.post("/CBS/Payroll2316/Extract", { Data: Generated, corp: corp, DtFrm: dtsd, DtTo: dted })
                       .done(function (data) {
                           window.location = '/CBS/Asset/Download?fileGuid=' + data.FileGuid + '&filename=' + data.FileName;
                           $(".preloader-it").fadeOut("slow");
                           toastr.success("Record successfully Exported.", "Notification");
                       })
                       .fail(function (stat, msg, custom) {
                           $(".preloader-it").fadeOut("slow");
                           toastr.info(stat.status + ": " + custom)
                        })





                },
                cancel: function () { }
            }

        })



    })

})
