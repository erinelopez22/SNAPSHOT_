﻿$(document).ready(function () {
    document.getElementById('dtsd').valueAsDate = new Date()
    document.getElementById('dted').valueAsDate = new Date()
    //document.getElementById('btnSave_PJE').disabled = true;
    document.getElementById('btnExport_PJE').disabled = true;

    //-----------------------------------------------------

    //$(".preloader-it").fadeIn(); //show
    function Generate(dtFrom, dtTo)
    {
        $(".preloader-it").fadeIn(); //show

        $("#tblJEView_header tbody tr").remove();
        $("#tblJEView_header").DataTable().clear().draw();
        $("#tblJEView_header").DataTable().destroy();
        
        $.post("/CBS/JEView/Generate", { DtFrm: dtFrom, DtTo: dtTo })
            .done(function (data) {
                data = JSON.parse(data);
                var tblJEView_Body = $("#tblJEView_Body");
                tblJEView_Body.html('');
                    $(data).each(function (i, JEView) {
                        tblJEView_Body.append('<tr>' +
                            '<td>' + JEView.Line_ID + '</td>' +
                            '<td>' + JEView.Branch + '</td>' +
                            '<td>' + JEView.AcctCode + '</td>' +
                            '<td>' + JEView.AcctName + '</td>' +
                            '<td class="text-right">' + numeral(JEView.Amount).format("0,0.00") + '</td>' +
                            '<td>' + moment(JEView.RefDate).format("YYYY-MM-DD") + '</td >' +
                            '<td>' + JEView.LineMemo + '</td>' +
                            '<td>' + JEView.EmpID + '</td>' +
                            '<td>' + JEView.EmpName + '</td>' +
                            '<td>' + JEView.Ref1 + '</td>' +
                            '<td>' + JEView.Ref2 + '</td>' +
                            '<td>' + JEView.Ref3 + '</td>' +
                            '<td>' + JEView.TransId + '</td>' +
                        '</tr>');
                    })

                    $("#tblJEView_header").DataTable({
                            scrollX: true
                        }).draw();

                  //  document.getElementById('btnSave_PJE').disabled = false;
                    document.getElementById('btnExport_PJE').disabled = false;


                    $(".preloader-it").fadeOut("slow");
            })
            .fail(function (stat, msg, custom) {
              //  document.getElementById('btnSave_PJE').disabled = true;
                document.getElementById('btnExport_PJE').disabled = true;
                $(".preloader-it").fadeOut("slow");
                toastr.info(stat.status + ": " + custom)
            })
    }

    //-----------------------------
    $("#btnGenerate_PJE").on("click", function () {
        var dtsd = $("#dtsd").val();
        var dted = $("#dted").val();
        Generate(dtsd, dted);
    })

    //------------------------------------------------------
    $("#btnSave_PJE").on("click", function () {
        $.confirm({
            title: "Confirmation",
            content: "Save data?",
            buttons: {
                yes: function () { },
                cancel: function () { }
            }
        })
    })
    //------------------------------------------------------
    $("#btnExport_PJE").on("click", function () {
        $.confirm({
            title: "Confirmation",
            content: "Export data?",
            buttons: {
                yes: function () {
                    $(".preloader-it").fadeIn(); //show
                    var Generated = [];
                    var data = $("#tblJEView_header").DataTable().rows().data();
                    data.each(function (value, index) {
                        Generated.push({
                            "Line_ID": value[0],
                            "Branch": value[1],
                            "AcctCode": value[2], 
                            "AcctName": value[3], 
                            "Amount": value[4],
                            "RefDate": value[5],
                            "LineMemo": value[6], 
                            "EmpID": value[7],
                            "EmpName": value[8],
                            "Ref1": value[9],
                            "Ref2": value[10],
                            "Ref3": value[11],
                            "TransId": value[12]
                        })


                    })


                    $.post("/CBS/JEView/Extract", { Data: Generated })
                     .done(function (data) {
                         window.location = '/CBS/Asset/Download?fileGuid=' + data.FileGuid + '&filename=' + data.FileName;
                         $(".preloader-it").fadeOut("slow");
                         toastr.success("Record successfully Exported.", "Notification");
                     })
                       .fail(function (stat, msg, custom) {
                           $(".preloader-it").fadeOut("slow");
                           toastr.info(stat.status + ": " + custom)
                       })
                    

                },
                cancel: function () { }
            }

        })

    })



})