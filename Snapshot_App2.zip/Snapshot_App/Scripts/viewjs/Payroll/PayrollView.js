﻿$(document).ready(function () {
    var x = document.getElementById('lblNEW_PV');
    x.style.visibility = 'hidden';

    document.getElementById('btnSave_PV').disabled = true;
    document.getElementById('btnExport_PV').disabled = true;
    document.getElementById('btnCJE_PV').disabled = true;
    
    //-----------------------------------------------------------------
    var AllowAdd;
    var AllowEdit;
    var AllowDelete;
    var AllowView;
    var AllowPrint;
    var AllowImport
    var AllowExport;
    var AllowPost;
    var AllowUnpost;
    var AllowApprove;
    //-----------------------------------------------------------------
    $.ajax({
        type: "POST",
        url: "/CBS/Common/Permissions",
        success: function (data) {
            data = JSON.parse(data)
            AllowAdd = data[0]["Add"]
            AllowEdit = data[0]["Edit"];
            AllowDelete = data[0]["Delete"];
            AllowView = data[0]["View"];
            AllowPrint = data[0]["Print"];
            AllowImport = data[0]["Import"];
            AllowExport = data[0]["Export"];
            AllowPost = data[0]["Post"];
            AllowUnpost = data[0]["Unpost"];
            AllowApprove = data[0]["Approve"];
        },
        async: false

    })
    //-----------------------------------------------------------------
    function OnLoad()
    {
        $.post("/CBS/Payroll/OnLoad")
            .done(function (data) {
                data = JSON.parse(data);
                

                var cboCorp_PV = $("#cboCorp_PV");
                cboCorp_PV.html("");
                $(data.Corps).each(function (index, val) {
                    cboCorp_PV.append('<option value="' + val.CorpName + '">' + val.CorpName + '</option>');
                });


                var cboMonth_PV = $("#cboMonth_PV");
                cboMonth_PV.html("");
                $(data.Months).each(function (index, val) {
                    cboMonth_PV.append('<option value="' + val.MonthNo + '">' + val.MonthName + '</option>');
                });

                var cboYear_PV = $("#cboYear_PV");
                cboYear_PV.html("");
                $(data.Years).each(function (index, val) {
                    cboYear_PV.append('<option value="' + val.year + '">' + val.year + '</option>');
                })

                var cboPeriod_PV = $("#cboPeriod_PV");
                cboPeriod_PV.html("");
                $(data.Periods).each(function (index, val) {
                    cboPeriod_PV.append('<option value="' + val.PeriodNo + '">' + val.PeriodName + '</option>');
                })
             

            })
            .fail(function (stat, msg, custom) {
                $(".preloader-it").fadeOut("slow");
                toastr.info(stat.status + ": " + custom)
            })
    }
    OnLoad();
    //-----------------------------------------------------------------
    function getBool(val) {
        return !!JSON.parse(String(val).toLowerCase());
    }
    //-----------------------------------------------------------------
    $("#btnImport_PV").on("click", function () {

        if (getBool(AllowImport) == false) {
            toastr.info("Access Denied!", "Notification");
            return;
        }
        
        var monthNo = $("#cboMonth_PV").val();
        var year = $("#cboYear_PV").val();
        var period = $("#cboPeriod_PV").val();
        
        if (monthNo == 0)
            {
                toastr.info("Month is required", "Notification")
                return;
            }
        else if (year == 0)
            {
                toastr.info("Year is required", "Notification")
                return;
            }
        else if (period == 0)
            {
                toastr.info("Period is required", "Notification")
                return;
            }
        
        //$('#txtImportFile_PV').val('');
        //$('.custom-file-label').text("Choose file...");

        //$("#tblImport_Header tbody tr").remove();
        //$("#tblImport_Header").DataTable().clear().draw();
        //$("#tblImport_Header").DataTable().destroy();

        $("#modImport_PV").modal("show");
        
    })
    //----------------------------------------------------------------
    $("#modImport_PV").on("hidden.bs.modal", function () {
        $(this).find('form').trigger('reset');
        $('.custom-file-label').text("Choose file...");
        $("#tblImport_Header").DataTable().clear().draw();
    });
    //----------------------------------------------------------------
    $("#txtImportFile_PV").on("change", function () {
        var fileName = $(this).val();
        $(this).next('.custom-file-label').html(fileName.replace('C:\\fakepath\\', " "));
       
       // $(this).next('.custom-file-label').html(fileName.mozFullPath);
        })
    //----------------------------------------------------------------
    $("#modImport_PV").on("click", "#btnSave_ImP", function () {
    
           var corp = $("#cboCorp_PV").val();
           var month = $("#cboMonth_PV").val();
           var year = $("#cboYear_PV").val();
           var period = $("#cboPeriod_PV").val();

           if (month == 0) {
                toastr.info("Month is required", "Notification")
                return;
            }
            else if (year == 0) {
                toastr.info("Year is required", "Notification")
                return;
            }
            else if (period == "")
            {
                toastr.info("Period is required", "Notification")
                return;
            }


        var formData = new FormData()
        var fileInput = document.getElementById('txtImportFile_PV')

        for (i = 0; i < fileInput.files.length; i++) {
            formData.append(fileInput.files[i].name, fileInput.files[i]);
        }
        var fileName = $("#txtImportFile_PV").val().replace('C:\\fakepath\\', " ");

        formData.append('month', month);
        formData.append('year', year);
        formData.append('period', period);
        formData.append('fileName', fileName);

        //console.log(formData)

        $.confirm({
            title: "Confirmation",
            content: "Save Excel Content?",
            buttons: {
                yes: function () {
                    $(".preloader-it").fadeIn(); //show
                    $.ajax({
                        url: "/CBS/Payroll/SaveData",
                        type: "POST",
                        processData: false,
                        contentType: false,
                        data: formData,
                        cache: false,
                        success: function (data) {
                            $(".preloader-it").fadeOut('slow');
                            $("#modImport_PV").modal("hide");
                            toastr.success("Records Successfully Saved.", "Notification")
                        },
                        error: function (stat, msg, custom) {
                            $(".preloader-it").fadeOut('slow');
                            toastr.info(stat.status + ": " + custom);
                        }

                    })
                },
                cancel: function () { }
            }

        })

     

    })
    //----------------------------------------------------------------
    $("#btnGenerate_PV").on("click", function () {
        
        var corp = $("#cboCorp_PV").val();
        var monthNo = $("#cboMonth_PV").val();
        var year = $("#cboYear_PV").val();
        var period = $("#cboPeriod_PV").val();
        
        //console.log(corp)
        //return

        if (corp == "") {
            toastr.info("Company is required", "Notification")
            return;
        }
        else if (monthNo == 0) {
            toastr.info("Month is required", "Notification")
            return;
        }
        else if (year == 0) {
            toastr.info("Year is required", "Notification")
            return;
        }
        //else if (period == 0) {
        //    toastr.info("Period is required", "Notification")
        //    return;
        //}

        $(".preloader-it").fadeIn(); //show

        var IsExist;
        $.post("/CBS/Payroll/CheckIfExist", { corp: corp, month: monthNo, year: year, period: period }, function (data) {
            IsExist = data;
        })
                
        $("#tblPV_Header tbody tr").remove();
        $("#tblPV_Header").DataTable().clear().draw();
        $("#tblPV_Header").DataTable().destroy();
        
        var totalrowcolor;
        var row;
             
        $.post("/CBS/Payroll/Generate", { corp: corp, month: monthNo, year: year, period: period })
                .done(function (data) {
                    data = JSON.parse(data);
                    var tblPV_Body = $("#tblPV_Body");
                    tblPV_Body.html("");
                    if (data.length > 0)
                    {
                        document.getElementById('btnSave_PV').disabled = false;
                        document.getElementById('btnExport_PV').disabled = false;
                        document.getElementById('btnCJE_PV').disabled = false;
                    }
                    else {
                        document.getElementById('btnSave_PV').disabled = true;
                        document.getElementById('btnExport_PV').disabled = true;
                        document.getElementById('btnCJE_PV').disabled = true;
                    }


                    $(data).each(function (i, payview) {
                                                
                        //---------------------------------------------------------------

                  

                       if (payview.Department.match("TOTAL"))
                            {
                            totalrowcolor = "background-color: rgb(163, 165, 162);color: white;font-size: 12px;font-weight: bold;"
                            row = "-";
                            }
                        else
                           {

                               if (payview.SSS_EE > 800 && !payview.Department.match("TOTAL")) {
                                   totalrowcolor = "color: black;font-weight: bold;";
                                 }
                               else if (payview.PHIC_EE > 550 && !payview.Department.match("TOTAL")) {
                                   totalrowcolor = "color: black;font-weight: bold;";
                                 }
                               else if (payview.HDMF_EE > 100 && !payview.Department.match("TOTAL")) {
                                   totalrowcolor = "color: black;font-weight: bold;";
                                 }
                               else{
                                   totalrowcolor = ""
                                }

                            row = payview.row;
                      
                           }

                        
                        tblPV_Body.append('<tr style="' + totalrowcolor + '">' +
                            '<td class="text-center">' + payview.Branch + '</td>' +
                            '<td>'+ payview.PeriodNo +'</td>' + 
                            '<td>' + payview.Department + '</td>' +
                            '<td>' + row + '</td>' +
                            '<td>' + payview.EmpCode + '</td>' +
                            '<td class="text-right">' + numeral(payview.BasicPay).format("0,0.00") + '</td>' +
                            '<td class="text-right">' + numeral(payview.Absences).format("0,0.00") + '</td>' +
                            '<td class="text-right">' + numeral(payview.UTTardiness).format("0,0.00") + '</td>' +
                            '<td class="text-right">' + numeral(payview.BasicPayNet).format("0,0.00") + '</td>' +
                            '<td class="text-right">' + numeral(payview.LH).format("0,0.00") + '</td>' +
                            '<td class="text-right">' + numeral(payview.SPLH).format("0,0.00") + '</td>' +
                            '<td class="text-right">' + numeral(payview.HazardPay).format("0,0.00") + '</td>' +
                            '<td class="text-right">' + numeral(payview.Overtime).format("0,0.00") + '</td>' +
                            '<td class="text-right">' + numeral(payview.OtherAllowance1).format("0,0.00") + '</td>' +
                            '<td class="text-right">' + numeral(payview.BirthdayCake).format("0,0.00") + '</td>' +
                            '<td class="text-right">' + numeral(payview.OtherAllowance2).format("0,0.00") + '</td>' +
                            '<td class="text-right">' + numeral(payview.CondoCoor).format("0,0.00") + '</td>' +
                            '<td class="text-right">' + numeral(payview.a13thMonthPay).format("0,0.00") + '</td>' +
                            '<td class="text-right">' + numeral(payview.UnusedLeave).format("0,0.00") + '</td>' +
                            '<td class="text-right">' + numeral(payview.ServiceRecognition).format("0,0.00") + '</td>' +
                            '<td class="text-right">' + numeral(payview.MATSalaryDifferential).format("0,0.00") + '</td>' +
                            '<td class="text-right">' + numeral(payview.HolidayOA).format("0,0.00") + '</td>' +
                            '<td class="text-right">' + numeral(payview.RDOTOA).format("0,0.00") + '</td>' +
                            '<td class="text-right">' + numeral(payview.RetroOA).format("0,0.00") + '</td>' +
                            '<td class="text-right">' + numeral(payview.UniformAllowance).format("0,0.00") + '</td>' +
                            '<td class="text-right">' + numeral(payview.MotorAllowance).format("0,0.00") + '</td>' +
                            '<td class="text-right">' + numeral(payview.MotorOil).format("0,0.00") + '</td>' +
                            '<td class="text-right">' + numeral(payview.PhoneAl).format("0,0.00") + '</td>' +
                            '<td class="text-right">' + numeral(payview.FoodAllowance).format("0,0.00") + '</td>' +
                            '<td class="text-right">' + numeral(payview.Referral).format("0,0.00") + '</td>' +
                            '<td class="text-right">' + numeral(payview.DrugTestReim).format("0,0.00") + '</td>' +
                            '<td class="text-right">' + numeral(payview.TraineeAl).format("0,0.00") + '</td>' +
                            '<td class="text-right">' + numeral(payview.BranchVisitAllowance).format("0,0.00") + '</td>' +
                            '<td class="text-right">' + numeral(payview.TaxRefund).format("0,0.00") + '</td>' +
                            '<td class="text-right">' + numeral(payview.DebitMemo).format("0,0.00") + '</td>' +
                            '<td class="text-right">' + numeral(payview.GrossPay).format("0,0.00") + '</td>' +
                            '<td class="text-right">' + numeral(payview.SSS_Ded).format("0,0.00") + '</td>' +
                            '<td class="text-right">' + numeral(payview.PHIC_Ded).format("0,0.00") + '</td>' +
                            '<td class="text-right">' + numeral(payview.HDMF_Ded).format("0,0.00") + '</td>' +
                            '<td class="text-right">' + numeral(payview.AddContri).format("0,0.00") + '</td>' +
                            '<td class="text-right">' + numeral(payview.SSSSalLoan).format("0,0.00") + '</td>' +
                            '<td class="text-right">' + numeral(payview.HDMFLoan).format("0,0.00") + '</td>' +
                            '<td class="text-right">' + numeral(payview.TaxWithheld).format("0,0.00") + '</td>' +
                            '<td class="text-right">' + numeral(payview.WrongInOut).format("0,0.00") + '</td>' +
                            '<td class="text-right">' + numeral(payview.UniformDeduction).format("0,0.00") + '</td>' +
                            '<td class="text-right">' + numeral(payview.ChargeTest).format("0,0.00") + '</td>' +
                            '<td class="text-right">' + numeral(payview.AceInsurance).format("0,0.00") + '</td>' +
                            '<td class="text-right">' + numeral(payview.CedulaPTR).format("0,0.00") + '</td>' +
                            '<td class="text-right">' + numeral(payview.HealthCert).format("0,0.00") + '</td>' +
                            '<td class="text-right">' + numeral(payview.Intellicare).format("0,0.00") + '</td>' +
                            '<td class="text-right">' + numeral(payview.HepaB).format("0,0.00") + '</td>' +
                            '<td class="text-right">' + numeral(payview.CompanyEvents).format("0,0.00") + '</td>' +
                            '<td class="text-right">' + numeral(payview.ExcessGlobe).format("0,0.00") + '</td>' +
                            '<td class="text-right">' + numeral(payview.ExcessSunCellUsage).format("0,0.00") + '</td>' +
                            '<td class="text-right">' + numeral(payview.TaxDue).format("0,0.00") + '</td>' +
                            '<td class="text-right">' + numeral(payview.TownHouse).format("0,0.00") + '</td>' +
                            '<td class="text-right">' + numeral(payview.CompanyLoan).format("0,0.00") + '</td>' +
                            '<td class="text-right">' + numeral(payview.AR).format("0,0.00") + '</td>' +
                            '<td class="text-right">' + numeral(payview.OtherDed).format("0,0.00") + '</td>' +
                            '<td class="text-right">' + numeral(payview.NetIncome).format("0,0.00") + '</td>' +
                            '<td class="text-right">' + numeral(payview.SSS_EE).format("0,0.00") + '</td>' +
                            '<td class="text-right">' + numeral(payview.PHIC_EE).format("0,0.00") + '</td>' +
                            '<td class="text-right">' + numeral(payview.HDMF_EE).format("0,0.00") + '</td>' +
                            '<td class="text-right">' + numeral(payview.Wtax).format("0,0.00") + '</td>' +
                            '<td class="text-right">' + numeral(payview.SSS_ER).format("0,0.00") + '</td>' +
                            '<td class="text-right">' + numeral(payview.PHIC_ER).format("0,0.00") + '</td>' +
                            '<td class="text-right">' + numeral(payview.HDMF_ER).format("0,0.00") + '</td>' +
                            '</tr>')
                    })


                    $("#tblPV_Header").DataTable({
                        ordering: false,
                        scrollX: true,
                        fixedColumns: {
                          leftColumns: 5
                        }
                    }).draw();

                    if ($("#tblPV_Header").DataTable().rows().any() == true) {
                        if (IsExist == 0) {
                            document.getElementById('lblNEW_PV').style.visibility = 'visible';
                            document.getElementById('btnSave_PV').disabled = false;
                            document.getElementById('btnCJE_PV').disabled = true;
                        }
                        else
                        {
                            document.getElementById('lblNEW_PV').style.visibility = 'hidden';
                            document.getElementById('btnSave_PV').disabled = true;
                            document.getElementById('btnCJE_PV').disabled = false;
                        }
                    }


                   
                    $(".preloader-it").fadeOut("slow");
                    
                })
                  .fail(function (stat, msg, custom) {
                      document.getElementById('btnSave_PV').disabled = true;
                      $(".preloader-it").fadeOut("slow");
                      toastr.info(stat.status + ": " + custom)
                  })



    })
    //----------------------------------------------------------------
    $("#btnExport_PV").on("click", function () {
        if (getBool(AllowExport) == false) {
            toastr.info("Access Denied!", "Notification");
            return;
        }

        var corp = $("#cboCorp_PV").val();
        var month = $("#cboMonth_PV").val();
        var year = $("#cboYear_PV").val();
        var period = $("#cboPeriod_PV").val();

        if (corp == "") {
            toastr.info("Corp is required", "Notification")
            return;
        }
        else if (month == 0) {
            toastr.info("Month is required", "Notification")
            return;
        }
        else if (year == 0) {
            toastr.info("Year is required", "Notification")
            return;
        }
        //else if (period == 0) {
        //    toastr.info("Period is required", "Notification")
        //    return;
        //}

        $.confirm({
            title: "confirmation",
            content: "Extract Records?",
            buttons:{
                yes: function () {
                    $(".preloader-it").fadeIn(); //show
                    var Extracted = [];
                    var data = $("#tblPV_Header").DataTable().rows().data();
                    data.each(function (value, index) {
                        Extracted.push({
                            "Branch": value[0],
                            "PeriodNo": value[1],
                            "Department": value[2],
                            "row": value[3],
                            "EmpCode": value[4],
                            "BasicPay": numeral(value[5]).value(),
                            "Absences": numeral(value[6]).value(),
                            "UTTardiness": numeral(value[7]).value(),
                            "LH": numeral(value[8]).value(),
                            "SPLH": numeral(value[9]).value(),
                            "HazardPay": numeral(value[10]).value(),
                            "Overtime": numeral(value[11]).value(),
                            "OtherAllowance1": numeral(value[12]).value(),
                            "BirthdayCake": numeral(value[13]).value(),
                            "OtherAllowance2": numeral(value[14]).value(),
                            "CondoCoor": numeral(value[15]).value(),
                            "a13thMonthPay": numeral(value[16]).value(),
                            "UnusedLeave": numeral(value[17]).value(),
                            "ServiceRecognition": numeral(value[18]).value(),
                            "MATSalaryDifferential": numeral(value[19]).value(),
                            "HolidayOA": numeral(value[20]).value(),
                            "RDOTOA": numeral(value[21]).value(),
                            "RetroOA": numeral(value[22]).value(),
                            "MotorAllowance": numeral(value[23]).value(),
                            "MotorOil": numeral(value[24]).value(),
                            "PhoneAl": numeral(value[25]).value(),
                            "FoodAllowance": numeral(value[26]).value(),
                            "Referral": numeral(value[27]).value(),
                            "DrugTestReim": numeral(value[28]).value(),
                            "TraineeAl": numeral(value[29]).value(),
                            "BranchVisitAllowance": numeral(value[30]).value(),
                            "TaxRefund": numeral(value[31]).value(),
                            "DebitMemo": numeral(value[32]).value(),
                            "GrossPay": numeral(value[33]).value(),
                            "SSS_Ded": numeral(value[34]).value(),
                            "PHIC_Ded": numeral(value[35]).value(),
                            "HDMF_Ded": numeral(value[36]).value(),
                            "AddContri": numeral(value[37]).value(),
                            "SSSSalLoan": numeral(value[38]).value(),
                            "HDMFLoan": numeral(value[39]).value(),
                            "TaxWithheld": numeral(value[40]).value(),
                            "WrongInOut": numeral(value[41]).value(),
                            "UniformDeduction": numeral(value[42]).value(),
                            "ChargeTest": numeral(value[43]).value(),
                            "AceInsurance": numeral(value[44]).value(),
                            "CedulaPTR": numeral(value[45]).value(),
                            "HealthCert": numeral(value[46]).value(),
                            "Intellicare": numeral(value[47]).value(),
                            "HepaB": numeral(value[48]).value(),
                            "CompanyEvents": numeral(value[49]).value(),
                            "ExcessGlobe": numeral(value[50]).value(),
                            "ExcessSunCellUsage": numeral(value[51]).value(),
                            "TaxDue": numeral(value[52]).value(),
                            "TownHouse": numeral(value[53]).value(),
                            "CompanyLoan": numeral(value[54]).value(),
                            "AR": numeral(value[55]).value(),
                            "OtherDed": numeral(value[56]).value(),
                            "NetIncome": numeral(value[57]).value(),
                            "SSS_EE": numeral(value[58]).value(),
                            "PHIC_EE": numeral(value[59]).value(),
                            "HDMF_EE": numeral(value[60]).value(),
                            "Wtax": numeral(value[61]).value(),
                            "SSS_ER": numeral(value[62]).value()
                        });
                    });

                    $.post("/CBS/Payroll/Extract", { Extracted: Extracted, corp: corp, month: month, year: year, period: period })
                    .done(function (data) {
                        window.location = '/CBS/Asset/Download?fileGuid=' + data.FileGuid + '&filename=' + data.FileName;
                        $(".preloader-it").fadeOut("slow");
                        toastr.success("Record successfully Exported.", "Notification");
                    })
                     .fail(function (stat, msg, custom) {
                         $(".preloader-it").fadeOut("slow");
                         toastr.info(stat.status + ": " + custom)
                     })
                    
                },
                cancel: function () { }
            }

        })

    })
    //----------------------------------------------------------------
    $("#btnCJE_PV").on("click", function () {
        
        var month = $("#cboMonth_PV").val();
        var year = $("#cboYear_PV").val();
        var period = $("#cboPeriod_PV").val();
        var corp = $("#cboCorp_PV").val();

        $.confirm({
            title: "Confirmation",
            content: "Create Journal Entries?",
            buttons: {
                yes: function () {
                    $(".preloader-it").fadeIn(); //show
                    $("#tblJE_Header tbody tr").remove();
                    $("#tblJE_Header").DataTable().clear().draw();
                    $("#tblJE_Header").DataTable().destroy();

                    $.post("/CBS/Payroll/CreateJE", { corp: corp, month: month, year: year, period: period })
                     .done(function (data) {
                         data = JSON.parse(data);
                         var tblJE_Body = $("#tblJE_Body");
                         tblJE_Body.html('');
                         $(data).each(function (i, JE) {
                             tblJE_Body.append('<tr>' +
                                 '<td>' + JE.Transnum + '</td>' +
                                 '<td>' + JE.Branch + '</td>' +
                                 '<td>' + JE.AcctCode + '</td>' +
                                 '<td>' + JE.AcctDesc + '</td>' +
                                 '<td class="text-right">' + numeral(JE.Amount).format("0,0.00") + '</td >' +
                                 '<td>' + moment(JE.RefDate).format("YYYY-MM-DD") + '</td>' +
                                 '<td>' + JE.Remarks + '</td>' +
                                 '<td>' + JE.Ref1 + '</td>' +
                                 '<td>' + JE.Ref2 + '</td>' +
                                 '<td>' + JE.Ref3 + '</td>' +
                             '</tr>');

                         });

                         $("#tblJE_Header").DataTable({
                             "order": [[0, "asc"]]
                         }).draw();
                         $("#modPost_PV").modal("show");
                         $(".preloader-it").fadeOut("slow");
                     })
                      .fail(function (stat, msg, custom) {
                          $(".preloader-it").fadeOut("slow");
                          toastr.info(stat.status + ": " + custom)
                      })



                },
                cancel: function () { }
            }

        })

        
       
    })
    //----------------------------------------------------------------
    $("#btnSave_PV").on("click", function () {
        var corp = $("#cboCorp_PV").val();
        var month = $("#cboMonth_PV").val();
        var year = $("#cboYear_PV").val();
        var period = $("#cboPeriod_PV").val();

        if (corp == "") {
            toastr.info("Corp is required", "Notification")
            return;
        }
        else if (month == 0) {
            toastr.info("Month is required", "Notification")
            return;
        }
        else if (year == 0) {
            toastr.info("Year is required", "Notification")
            return;
        }
        //else if (period == 0) {
        //    toastr.info("Period is required", "Notification")
        //    return;
        //}


        $.confirm({
            title: "Confirmation",
            content: "Save Records?",
            buttons: {
                yes: function () {

                    $(".preloader-it").fadeIn(); //show
                    var Extracted = [];
                    var data = $("#tblPV_Header").DataTable().rows().data();
                    data.each(function (value, index) {
                        Extracted.push({
                            "Branch": value[0],                                                         
                            "PeriodNo": value[1],
                            "Department": value[2],
                            "row": value[3],
                            "EmpCode": value[4],
                            "BasicPay": numeral(value[5]).value(),
                            "Absences": numeral(value[6]).value(),
                            "UTTardiness": numeral(value[7]).value(),
                            "BasicPayNet": numeral(value[8]).value(),
                            "LH": numeral(value[9]).value(),
                            "SPLH": numeral(value[10]).value(),
                            "HazardPay": numeral(value[11]).value(),
                            "Overtime": numeral(value[12]).value(),
                            "OtherAllowance1": numeral(value[13]).value(),
                            "BirthdayCake": numeral(value[14]).value(),
                            "OtherAllowance2": numeral(value[15]).value(),
                            "CondoCoor": numeral(value[16]).value(),
                            "a13thMonthPay": numeral(value[17]).value(),
                            "UnusedLeave": numeral(value[18]).value(),
                            "ServiceRecognition": numeral(value[19]).value(),
                            "MATSalaryDifferential": numeral(value[20]).value(),
                            "HolidayOA": numeral(value[21]).value(),
                            "RDOTOA": numeral(value[22]).value(),
                            "RetroOA": numeral(value[23]).value(),
                            "UniformAllowance": numeral(value[24]).value(),
                            "MotorAllowance": numeral(value[25]).value(),
                            "MotorOil": numeral(value[26]).value(),
                            "PhoneAl": numeral(value[27]).value(),
                            "FoodAllowance": numeral(value[28]).value(),
                            "Referral": numeral(value[29]).value(),
                            "DrugTestReim": numeral(value[30]).value(),
                            "TraineeAl": numeral(value[31]).value(),
                            "BranchVisitAllowance": numeral(value[32]).value(),
                            "TaxRefund": numeral(value[33]).value(),
                            "DebitMemo": numeral(value[34]).value(),
                            "GrossPay": numeral(value[35]).value(),
                            "SSS_Ded": numeral(value[36]).value(),
                            "PHIC_Ded": numeral(value[37]).value(),
                            "HDMF_Ded": numeral(value[38]).value(),
                            "AddContri": numeral(value[39]).value(),
                            "SSSSalLoan": numeral(value[40]).value(),
                            "HDMFLoan": numeral(value[41]).value(),
                            "TaxWithheld": numeral(value[42]).value(),
                            "WrongInOut": numeral(value[43]).value(),
                            "UniformDeduction": numeral(value[44]).value(),
                            "ChargeTest": numeral(value[45]).value(),
                            "AceInsurance": numeral(value[46]).value(),
                            "CedulaPTR": numeral(value[47]).value(),
                            "HealthCert": numeral(value[48]).value(),
                            "Intellicare": numeral(value[49]).value(),
                            "HepaB": numeral(value[50]).value(),
                            "CompanyEvents": numeral(value[51]).value(),
                            "ExcessGlobe": numeral(value[52]).value(),
                            "ExcessSunCellUsage": numeral(value[53]).value(),
                            "TaxDue": numeral(value[54]).value(),
                            "TownHouse": numeral(value[55]).value(),
                            "CompanyLoan": numeral(value[56]).value(),
                            "AR": numeral(value[57]).value(),
                            "OtherDed": numeral(value[58]).value(),
                            "NetIncome": numeral(value[59]).value(),
                            "SSS_EE": numeral(value[60]).value(),
                            "PHIC_EE": numeral(value[61]).value(),
                            "HDMF_EE": numeral(value[62]).value(),
                            "Wtax": numeral(value[63]).value(),
                            "SSS_ER": numeral(value[64]).value()
                        });
                    });


                    
                    $.post("/CBS/Payroll/SavePayroll_BKFormat", { Formated: Extracted, corp: corp, month: month, year: year, period: period })
                    .done(function () {
                        $(".preloader-it").fadeOut("slow");
                        document.getElementById('lblNEW_PV').style.visibility = 'hidden';
                        document.getElementById('btnSave_PV').disabled = true;
                        document.getElementById('btnCJE_PV').disabled = false;
                        toastr.success("Record successfully Saved.", "Notification");
                    })
                      .fail(function (stat, msg, custom) {
                          $(".preloader-it").fadeOut("slow");
                          document.getElementById('lblNEW_PV').style.visibility = 'visible';
                          document.getElementById('btnSave_PV').disabled = false;
                          document.getElementById('btnCJE_PV').disabled = true;
                          toastr.info(stat.status + ": " + custom)
                      })
                },
                cancel: function () { }
            }

        })

    })
    //----------------------------------------------------------------
    $("#modPost_PV").on("click", "#btnPost_PV", function () {
        $.confirm({
            title: "Confirmation",
            content: "Post Entrie(s)?",
            buttons:{
                yes: function () {
                    $(".preloader-it").fadeIn(); //show
                    var month = $("#cboMonth_PV").val();
                    var year = $("#cboYear_PV").val();
                    var period = $("#cboPeriod_PV").val();
                    var corp = $("#cboCorp_PV").val();


                    var JE = [];
                    var data = $("#tblJE_Header").DataTable().rows().data();
                    data.each(function (value, index) {
                        JE.push({
                            "Transnum": value[0], 
                            "Branch ": value[1],
                            "AcctCode": value[2], 
                            "AcctDesc": value[3], 
                            "Amount": numeral(value[4]).value(),
                            "RefDate": value[5],
                            "Remarks": value[6],
                            "Ref1": value[7]
                        });
                    });





                },
                cancel: function(){}
            }
        })
    })
    //----------------------------------------------------------------
    $("#modPost_PV").on("click", "#btnExportJE_PV", function () {
        $.confirm({
            title: "Confirmation",
            content: "Export Data?",
            buttons: {
                yes: function () {
                    $(".preloader-it").fadeIn(); //show
                    var month = $("#cboMonth_PV").val();
                    var year = $("#cboYear_PV").val();
                    var period = $("#cboPeriod_PV").val();
                    var corp = $("#cboCorp_PV").val();

                    var JE = [];
                    var data = $("#tblJE_Header").DataTable().rows().data();
                    data.each(function (value, index) {
                        JE.push({
                            "Transnum": value[0],
                            "Branch": value[1],
                            "AcctCode": value[2],
                            "AcctDesc": value[3],
                            "Amount": numeral(value[4]).value(),
                            "RefDate": value[5],
                            "Remarks": value[6],
                            "Ref1": value[7],
                            "Ref2": value[8],
                            "Ref3": value[9]
                        });
                    });
                                       
                    $.post("/CBS/Payroll/ExtractJE", { data: JE, corp: corp, month: month, year: year, period: period })
                       .done(function (data) {
                           window.location = '/CBS/Asset/Download?fileGuid=' + data.FileGuid + '&filename=' + data.FileName;
                           $(".preloader-it").fadeOut("slow");
                           toastr.success("Record successfully Exported.", "Notification");
                       })
                        .fail(function (stat, msg, custom) {
                            $(".preloader-it").fadeOut("slow");
                            toastr.info(stat.status + ": " + custom)
                        })



                },
                cancel: function () { }
            }
        })
    })
    //----------------------------------------------------------------

})