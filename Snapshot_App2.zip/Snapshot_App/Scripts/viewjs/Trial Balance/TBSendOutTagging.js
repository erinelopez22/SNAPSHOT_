﻿$(document).ready(function () {

    $.post("/CBS/Common/GetBranch", function (data) {
        $('.chosen-select').chosen({ allow_single_deselect: true });
        data = JSON.parse(data);
        var cboBranch = $("#cboBranch");
        cboBranch.html('');
        $(data).each(function (index, br) {
            cboBranch.append('<option value="' + br.Whscode + '">' + br.whsName + '</option>');
        });
      $("#cboBranch").trigger("chosen:updated");
    });
    //---------------------------------------------------------
    $.post("/CBS/TBTools/GetCardList", function (data) {
        $('.chosen-select').chosen({ allow_single_deselect: true });
        data = JSON.parse(data);
        var cboCardCode = $("#cboCardCode");
        cboCardCode.html('');
        $(data).each(function (index, br) {
            cboCardCode.append('<option value="' + br.CardCode + '">' + br.CardName + '</option>');
        });
        $("#cboCardCode").trigger("chosen:updated");
    });
    //---------------------------------------------------------
    function GenerateData(whscode)
    {
        $("#tblSentOutTagging_Header tbody tr").remove();
        $("#tblSentOutTagging_Header").DataTable().clear().draw();
        $("#tblSentOutTagging_Header").DataTable().destroy();
        $.post("/CBS/TBTools/GenerateDataByWhsCode", { WhsCode: whscode })
        .done(function (data) {
            data = JSON.parse(data);

            var tblSentOutTagging_Body = $("#tblSentOutTagging_Body");
            tblSentOutTagging_Body.html("");
            $(data).each(function (i, TBTools) {
                tblSentOutTagging_Body.append('<tr>' +
                    '<td>' + TBTools.DocEntry + '</td>' +
                    '<td>' + TBTools.Desc + '</td>' +
                    '<td>' + TBTools.CardCode + '</td>' +
                    '<td>' + TBTools.CardName + '</td>' +
                    '</tr>')

            });
            $("#tblSentOutTagging_Header").DataTable().draw();
        })
         .fail(function (stat, msg, custom) {
             toastr.warning(stat.status + ": " + custom)
         });
        //--------------

        $.post("/CBS/TBTools/GetDescbyWhsCode", { WhsCode: whscode }, function (data) {
            
            data = JSON.parse(data);

                $('.chosen-select').chosen({ allow_single_deselect: true });
                var cboDocEntry = $("#cboDocEntry");
                cboDocEntry.html('');
                $(data).each(function (index, br) {
                    cboDocEntry.append('<option value="' + br.DocEntry + '">' + br.Desc + '</option>');
                });
                $("#cboDocEntry").trigger("chosen:updated");
            
        });
    }
    //---------------------------------------------------------
    $("#cboBranch").on("change", function () {
        var whscode = $(this).val();
        GenerateData(whscode);
    });
    //---------------------------------------------------------
    $("#btnTag").on("click", function () {
        var whscode = $("#cboBranch").val();
        var cardCode = $("#cboCardCode").val();
        var docEntry = $("#cboDocEntry").val();

       
        if (docEntry == null)
        {
            toastr.info("Doc Entry is requried.", "Notification");
        }
        else
        {
            $.confirm({
                title: "Confirmation",
                content: "Tag Record/s?",
                buttons: {
                            yes: function () {
                                $(".preloader-it").fadeIn(); //show

                                $.post("/CBS/TBTools/Tag", { WhsCode: whscode, CardCode: cardCode, DocEntry: docEntry })
                                  .done(function () {
                                      $(".preloader-it").fadeOut("slow");
                                      toastr.success("Record Successfully Tagged", "Notification");
                                      GenerateData(whscode);
                                  })
                                .fail(function (stat, msg, custom) {
                                    $(".preloader-it").fadeOut("slow");
                                    toastr.warning(stat.status + ": " + custom)
                                });

                               
                            },
                            cancel: function () { }
                           }
            })

          
        }

    })

})

