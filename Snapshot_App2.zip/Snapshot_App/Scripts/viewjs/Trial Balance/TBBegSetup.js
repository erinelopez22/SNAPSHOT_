﻿$(document).ready(function () {

    //-----------------------------------------------------------------
    var AllowAdd;
    var AllowEdit;
    var AllowDelete;
    var AllowView;
    var AllowPrint;
    var AllowImport
    var AllowExport;
    var AllowPost;
    var AllowUnpost;
    var AllowApprove;
    //-----------------------------------------------------------------
    $.ajax({
        type: "POST",
        url: "/CBS/Common/Permissions",
        success: function (data) {
            data = JSON.parse(data)
            AllowAdd = data[0]["Add"]
            AllowEdit = data[0]["Edit"];
            AllowDelete = data[0]["Delete"];
            AllowView = data[0]["View"];
            AllowPrint = data[0]["Print"];
            AllowImport = data[0]["Import"];
            AllowExport = data[0]["Export"];
            AllowPost = data[0]["Post"];
            AllowUnpost = data[0]["Unpost"];
            AllowApprove = data[0]["Approve"];
        },
        async: false

    })
    //-------------------------------

    function getBool(val) {
        return !!JSON.parse(String(val).toLowerCase());
    }
    //-----------------------------------------------------------------


    $.post("/CBS/Common/GetBranch", function (data) {
        data = JSON.parse(data);
        var cboBranch = $("#cboBranch");
        cboBranch.html('');
        $(data).each(function (index, br) {
            cboBranch.append('<option value="' + br.Whscode + '">' + br.whsName + '</option>');
        });
    });
    //----------------------------------------------------------------
    $.post("/CBS/Common/GetMonths", function (data) {
        data = JSON.parse(data);
        var cboMonth = $("#cboMonth");
        cboMonth.html('');
        $(data).each(function (index, br) {
            cboMonth.append('<option value="' + br.MonthNum + '">' + br.MonthName + '</option>');
        });
    });
    //---------------------------------------------------------------
    function GetMonth(monthno) {
        var month = new Array();
        month[1] = "January";
        month[2] = "February";
        month[3] = "March";
        month[4] = "April";
        month[5] = "May";
        month[6] = "June";
        month[7] = "July";
        month[8] = "August";
        month[9] = "September";
        month[10] = "October";
        month[11] = "November";
        month[12] = "December";

        return month[monthno];
    }
    //---------------------------------------------------------------
    function LoadData(){
    
        $("#tblBegSetup_Header tbody tr").remove();
        $("#tblBegSetup_Header").DataTable().clear().draw();
        $("#tblBegSetup_Header").DataTable().destroy();
        $.post("/CBS/TBTools/BegSetup_LoadData")
        .done(function (data) {
            data = JSON.parse(data);
            
            var tblBegSetup_Body = $("#tblBegSetup_Body");
            tblBegSetup_Body.html("");
            $(data).each(function (i, TBTools) {

                var MonthName;
                var Year;
                if (TBTools.Month == 0) { MonthName = "---"; Year = "---"; }
                else { MonthName = GetMonth(TBTools.Month); Year = TBTools.Year; }


                tblBegSetup_Body.append('<tr>' +
                    '<td>' + TBTools.BranchCode + '</td>' +
                    '<td>' + TBTools.Branch + '</td>' +
                    '<td>' + TBTools.Block + '</td>' +
                    '<td>' + MonthName + '</td>' +
                    '<td>' + Year + '</td>' +
                         '<td align="middle">' +
                            '<button type="button" id="btnUpdateBegSetup" class="btn btn-xs btn-outline-primary btn-rounded" title="Click to Edit" ' +
                            ' data-whsCode ="' + TBTools.BranchCode + '"' +
                            ' data-Month ="' + TBTools.Month + '"' +
                            ' data-year ="' + TBTools.Year + '"' +
                            ' >' +
                            '<i class="fa fa-edit"></i>' +
                            '</button > ' +
                               '</td > ' +


                    '</tr>')

            });

            $("#tblBegSetup_Header").DataTable().draw();


            

        })
        .fail(function (stat, msg, custom) {
            toastr.warning(stat.status + ": " + custom)
        });
            

      
    
    }
    //---------------------------------------------------------------
    LoadData();
    //---------------------------------------------------------------
    $("#tblBegSetup_Header").on("click", "#btnUpdateBegSetup", function () {

        if (getBool(AllowEdit) == false) {
            toastr.info("Access Denied!", "Notification");
            return;
        }


        var whscode = $(this).attr("data-whsCode");
        var month = $(this).attr("data-Month");
        var year = $(this).attr("data-year");
        

        $("#mod-BegSetup #cboBranch").val(whscode);
        $("#mod-BegSetup #cboMonth").val(month);
        $("#mod-BegSetup #txtyear").val(year);


        $("#mod-BegSetup").modal("show");
    });
    //---------------------------------------------------------------
    $("#mod-BegSetup").on("click", "#btnSaveBegSetup", function () {
        var b = document.getElementById("cboBranch");
        var selectedText = b.options[b.selectedIndex].text;
        var month = $("#mod-BegSetup #cboMonth").val();
        var year = $("#mod-BegSetup #txtyear").val();
        var whsCode = $("#mod-BegSetup #cboBranch").val();

        if (year.length != 4) {
            toastr.error("Invalid Year", "Notification");
            document.getElementById("txtyear").focus();
        }
        else {
            $.confirm({
                title: "Confirmation",
                content: "Save/Update Beginning setup of " + selectedText + " for " + GetMonth(month) + " " + year + "?",
                buttons: {
                    yes: function () {
                        $(".preloader-it").fadeIn(); //show
                        $.post("/CBS/TBTools/Upsert", { whsCode: whsCode, month: month, year: year })
                        .done(function () {
                            $(".preloader-it").fadeOut("slow");
                            $("#mod-BegSetup").modal("hide");
                            toastr.success("Record successfully Saved.", "Notification");
                            LoadData();
                        })
                          .fail(function (stat, msg, custom) {
                              $(".preloader-it").fadeOut("slow");
                              toastr.warning(stat.status + ": " + custom)
                          });

                    },
                    cancel: function () { }

                }

            })
        }


    

    
    })
    //---------------------------------------------------------------
    $("#btnNewBegSetup").on("click", function () {
        if (getBool(AllowAdd) == false) {
            toastr.info("Access Denied!", "Notification");
            return;
        }
        
        $("#mod-BegSetup").modal("show");
        
    })

});