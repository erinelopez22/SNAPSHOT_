﻿$(document).ready(function () {


    function Generate(TransID)
    {
        if (TransID == "") {
            toastr.info("TransId is requried.", "Notification");
        }

        else {
            $("#tblReSplit_Header tbody tr").remove();
            $("#tblReSplit_Header").DataTable().clear().draw();
            $("#tblReSplit_Header").DataTable().destroy();

            $.post("/CBS/TBTools/RS_Generate", { TransID: TransID })
             .done(function (data) {
                 data = JSON.parse(data);

                 var tblReSplit_Body = $("#tblReSplit_Body");
                 tblReSplit_Body.html("");
                 $(data).each(function (i, TBTools) {
                     tblReSplit_Body.append('<tr>' +
                         '<td>' + TBTools.TransID + '</td>' +
                         '<td>' + TBTools.LineID + '</td>' +
                         '<td>' + TBTools.SplitID + '</td>' +
                         '<td>' + TBTools.TransType + '</td>' +
                         '<td>' + TBTools.FormatCode + '</td>' +
                         '<td>' + TBTools.AcctName + '</td>' +
                         '<td class="text-right">' + numeral(TBTools.TransAmt).format("0,0.00") + '</td>' +
                        '<td>' + moment(TBTools.RefDate).format("YYYY-MM-DD") + '</td>' +
                         '<td>' + TBTools.Ref1 + '</td>' +
                         '</tr>')

                 });
                 $("#tblReSplit_Header").DataTable().draw();


             })
             .fail(function (stat, msg, custom) {
                 toastr.warning(stat.status + ": " + custom)
             });
        }
    }


    //-----------------------------------------------------
    $("#btnLoad").on("click", function () {
         
         var TransID = $("#txtTransID").val();
         Generate(TransID);
    })
    //-----------------------------------------------------
    $("#btnReSplit").on("click", function () {
        var TransID = $("#txtTransID").val();
        var data = $("#tblReSplit_Header").DataTable().rows().data();
      
        if (TransID == "") {
            toastr.info("TransId is requried.", "Notification");
        }
        else if (data.length == 0) {
            toastr.info("Load transaction first for checking.","Notification");
        }
        else
        {
            $.confirm({
                title: "Confirmation",
                content: "Re-Split Transaction/s?",
                buttons: {
                    yes: function () {
                        $(".preloader-it").fadeIn(); //show
                        $.post("/CBS/TBTools/ReSplit", { TransID: TransID })
                        .done(function () {
                            $(".preloader-it").fadeOut("slow");
                            toastr.success("Record Successfully splited!", "Notification");
                            Generate(TransID);
                        })
                        .fail(function (stat, msg, custom) {
                            $(".preloader-it").fadeOut("slow");
                             toastr.warning(stat.status + ": " + custom)
                        });
                    },
                    cancel: function(){}
                }


            })
        }


    })


});