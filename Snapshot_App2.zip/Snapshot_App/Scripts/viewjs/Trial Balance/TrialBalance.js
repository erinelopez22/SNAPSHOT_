﻿$(document).ready(function () {
    //-----------------onload------------------------------------------
    document.getElementById('btnSave_WS').disabled = true;
    document.getElementById('btnExport_WS').disabled = true;
    //document.getElementById('btnAddbegAmt_WS').disabled = true;

    //-----------------------------------------------------------------
    var AllowAdd;
    var AllowEdit;
    var AllowDelete;
    var AllowView;
    var AllowPrint;
    var AllowImport
    var AllowExport;
    var AllowPost;
    var AllowUnpost;
    var AllowApprove;
    //-----------------------------------------------------------------
    $.ajax({
        type: "POST",
        url: "/CBS/Common/Permissions",
        success: function (data) {
            data = JSON.parse(data)
            AllowAdd = data[0]["Add"]
            AllowEdit = data[0]["Edit"];
            AllowDelete = data[0]["Delete"];
            AllowView = data[0]["View"];
            AllowPrint = data[0]["Print"];
            AllowImport = data[0]["Import"];
            AllowExport = data[0]["Export"];
            AllowPost = data[0]["Post"];
            AllowUnpost = data[0]["Unpost"];
            AllowApprove = data[0]["Approve"];
        },
        async: false

    })
    //-------------------------------

    function getBool(val) {
        return !!JSON.parse(String(val).toLowerCase());
    }
    //-----------------------------------------------------------------

    var UserID;
    $.post("/CBS/Common/GetUserID")
        .done(function (data) {
            data = JSON.parse(data);
            userID = data;
        })
    //----------------------------------------------------------------
    $.post("/CBS/Common/GetBranch", function (data) {
        data = JSON.parse(data);
        var cboBranch_WS = $("#cboBranch_WS");
        cboBranch_WS.html('');
        $(data).each(function (index, br) {
            cboBranch_WS.append('<option value="' + br.Whscode + '">' + br.whsName + '</option>');
        });
    });
    //----------------------------------------------------------------
    $.post("/CBS/TrialBalance/GetMonths", function (data) {
        data = JSON.parse(data);
        var cboMonth_WS = $("#cboMonth_WS");
        cboMonth_WS.html('');
        $(data).each(function (index, br) {
            cboMonth_WS.append('<option value="' + br.MonthNum + '">' + br.MonthName + '</option>');
        });
    });
    //-----------------------COLLAPSE TABLE-----------------------------------------
    function fnFormatDetails(oTable, nTr, tid) {
        var aData = oTable.fnGetData(nTr);
        var sOut = '<table style="color: #324148;background-color: white; margin:auto; width: 90%;" class="insideTable small" id=' + tid + '>';
        sOut += '   <tr> ' +
                    '<th  style="font-size: 12px;">Line ID</th>' +
                    '<th  style="font-size: 12px;">Split ID</th>' +
                    '<th  style="font-size: 12px;">Trans Amount</th>' +
                    '<th  style="font-size: 12px;">Format Code</th>' +
                    '<th  style="font-size: 12px;">Ref. Date</th>' +
                    '<th  style="font-size: 12px;">Account Name</th>' +
                    '<th  style="font-size: 12px;">Ref1</th>' +
                '</tr>';
        sOut += '<tbody> </tbody> ';
        sOut += '</table>';

        return sOut;
        
    }
    //-----------------------CHECK ALL-----------------------------------------
    function CheckAll() {
        var table = $('#tblJEDetailsHeader').DataTable();
        var Debit = parseFloat("0.00");
        var Credit = parseFloat("0.00");
        var Net = parseFloat("0.00");
        var NetAmount;

        table.rows().every(function (index, element) {
            var row = $(this.nodes());
            var statusElement = row.find('td:first-child input[type="checkbox"]');
            var isChecked = statusElement.prop('checked');
            var data = this.data();
            
            if (isChecked == true) {
                 Debit = parseFloat(Debit) + numeral(data[7]).value()
                Credit = parseFloat(Credit) + numeral(data[8]).value()
                Net = parseFloat(Debit) - parseFloat(Credit);
                
            }
        });

        $('#txtDebit_WS').val(numeral(Debit).format("0,0.00"));
        $('#txtCredit_WS').val(numeral(Credit).format("0,0.00"));
        $('#txtNetAmount_WS').val(numeral(Net).format("0,0.00"))
    };
    //-----------------------LOAD MODAL-----------------------------------------
    function LoadModal(month, year, posted, formatcode, AccountName, IsRefresh) {

        if (IsRefresh == 1) {
                var formatcode = $("#txtFormatCode_WS").val();
        }
        else {
                $("#txtFormatCode_WS", "#mod-WSView").val(formatcode);
                $("#txtAccountName_WS", "#mod-WSView").val(AccountName);
             }

        $("#tblJEDetailsHeader tbody tr").remove();
        $("#tblJEDetailsHeader").DataTable().clear().draw();
        $("#tblJEDetailsHeader").DataTable().destroy();

        $.post("/CBS/TrialBalance/GenerateTBDetails", { posted: posted, FormatCode: formatcode, month: month, year: year })
        .done(function (data) {
            data = JSON.parse(data);
            var tblJEDetailsBody = $("#tblJEDetailsBody");
            tblJEDetailsBody.html('');

            var checkboxState;
            var chkclassname;
            $(data).each(function (i, TrialBalance) {
               
                if (TrialBalance.ReconNo != "0")
                {
                    checkboxState = "disabled";
                    chkclassname = "";
                }
                else
                {
                    checkboxState = '';
                    chkclassname = "chkRow";
                }
             
               
                tblJEDetailsBody.append('<tr data-TransID=' + TrialBalance.TransID + ' data-rowindex =' + i + '>' +
                   '<td  style="text-align: center;vertical-align: middle;">' +
                   '   <div class="checkbox">' +
                   '     <input type="checkbox" class="' + chkclassname + '" id="chkRow"  ' + checkboxState + '/>' +
                   '     <label for="chkRow"></label>' +
                   '   </div>' +
                   '</td>' +
                   '<td align="middle" id="Expand" ><img src="/CBS/Resouces/details_open.png" id="img"></img>  </td > ' +
                   '<td>' + TrialBalance.ReconNo + '</td>' +
                   '<td>' + TrialBalance.TransID + '</td>' +
                   '<td>' + TrialBalance.TransType + '</td>' +
                   '<td>' + moment(TrialBalance.RefDate).format("YYYY-MM-DD") + '</td>' +
                   '<td>' + TrialBalance.Memo + '</td>' +
                   '<td class="text-right">' + numeral(TrialBalance.Debit).format("0,0.00") + '</td>' +
                   '<td class="text-right">' + numeral(TrialBalance.Credit).format("0,0.00") + '</td>' +
                   '</tr>')
            });
            //,
            //"aTargets": [1]
            var oTable = $('#tblJEDetailsHeader').dataTable({
                "aoColumnDefs": [{
                    "bSortable": false
                }],
                "aaSorting": [
                    [1, 'asc']
                ]
            });

            //--------------checkbox check all--------------
            $('#tblJEDetailsHeader').on('click', '#Chkall_WS', function () {
                $('#tblJEDetailsHeader').DataTable()
                    .column(0)
                    .nodes()
                    .to$()
                    .find(".chkRow").prop('checked', this.checked);
                CheckAll();
               })

            //--------------Collapse Details--------------
            //$('#tblJEDetailsHeader tbody td #img').on('click', function () {
            $('#tblJEDetailsHeader').on('click', '#img', function (e) {
                var nTr = $(this).parents('tr')[0];
                var Transid = $(this).parents('tr').attr("data-TransID");

                if (oTable.fnIsOpen(nTr))
              
                {
                    this.src = "/CBS/Resouces/details_open.png";
                    oTable.fnClose(nTr);
               //     console.log('Close');

                } else {
                    console.log('Collapse');
                    this.src = "/CBS/Resouces/details_close.png";
                    oTable.fnOpen(nTr, fnFormatDetails(oTable, nTr, Transid), 'details');
                    $.post("/CBS/TrialBalance/LoadJEDetails", { Transid: Transid }, function (data) {

                        //$('.insideTable td').parent().remove();
                        var TblJEDetails = $("#tblJEDetailsBody").find("tr").find("#" + Transid + '').html('');
                        data = JSON.parse(data);

                        if (data.length > 0) {
                            //header
                            TblJEDetails.append('<tr> ' +
                         '<th  style="font-size: 12px;">Line ID</th>' +
                         '<th  style="font-size: 12px;">Split ID</th>' +
                         '<th  style="font-size: 12px;">Trans Amount</th>' +
                         '<th  style="font-size: 12px;">Format Code</th>' +
                         '<th  style="font-size: 12px;">Ref. Date</th>' +
                         '<th  style="font-size: 12px;">Account Name</th>' +
                         '<th  style="font-size: 12px;">Ref1</th>' +
                         '</tr>');

                            $(data).each(function (i, TrialBalance) {
                                TblJEDetails.append('<tr>' +
                                    '<td>' + TrialBalance.LineID + '</td>' +
                                    '<td>' + TrialBalance.SplitID + '</td>' +
                                    '<td class="text-right">' + numeral(TrialBalance.TransAmount).format("0,0.00") + '</td>' +
                                    '<td>' + TrialBalance.FormatCode + '</td>' +
                                    '<td>' + moment(TrialBalance.RefDate).format("YYYY-MM-DD") + '</td>' +
                                    '<td>' + TrialBalance.AcctName + '</td>' +
                                    '<td>' + TrialBalance.Ref1 + '</td>' +
                                    '</tr>'
                                    );
                            });

                        }
                        else {
                            toastr.warning("No Details", "Consolidated Bookkeeping System");
                        }
                    })
                }
                e.stopImmediatePropagation();
            })
            //--------------------------------------------------------------------

            $('#tblJEDetailsHeader').on('click', '#chkRow', function () {
                var oTable = $('#tblJEDetailsHeader').DataTable();
                var Debit = parseFloat("0.00");
                var Credit = parseFloat("0.00");
                var Net = parseFloat("0.00");

                oTable.rows().every(function (index, element) {
                    var row = $(this.nodes());
                    var statusElement = row.find('td:first-child input[type="checkbox"]');
                    var isChecked = statusElement.prop('checked');
                    var data = this.data();
                    if (isChecked == true) {
                        Debit = parseFloat(Debit) + numeral(data[7]).value()
                        Credit = parseFloat(Credit) + numeral(data[8]).value()
                        Net = parseFloat(Debit) - parseFloat(Credit);
                    }
                })
                $('#txtDebit_WS').val(numeral(Debit).format("0,0.00"));
                $('#txtCredit_WS').val(numeral(Credit).format("0,0.00"));
                $('#txtNetAmount_WS').val(numeral(Net).format("0,0.00"))

            });
            $('#txtDebit_WS').val("0.00");
            $('#txtCredit_WS').val("0.00");
            $('#txtNetAmount_WS').val("0.00");
            $("#Chkall_WS").prop("checked", false);
            $("#ChkHideRecon_WS").prop("checked", false);
            if (IsRefresh == 0) {
                $('#mod-WSView').modal('show');
            }

        })

        .fail(function (stat, msg, custom) {
            toastr.warning(stat.status + ": " + custom)
        });


    };
    //-----------------------GENERATE TB-----------------------------------------
    var GenerateTB = function () {
     
        var branch = $("#cboBranch_WS").val();
        var month = $("#cboMonth_WS").val();
        var year = $("#txtyear_WS").val();
        var posted = document.getElementById("ChkPosted_WS").checked;
        var vis;
        var totalrowcolor;

        $("#TBWorksheetHeader tbody tr").remove();
        $("#TBWorksheetHeader").DataTable().clear().draw();
        $("#TBWorksheetHeader").DataTable().destroy();


        if (year.length != 4) {
            toastr.error("Invalid Year", "Notification");
        }
        else {
            $(".preloader-it").fadeIn(); //show

            $.post("/CBS/TrialBalance/GenerateTB", { Branch: branch, Month: month, Year: year, Posted: posted })
                .done(function (data) {
                    data = JSON.parse(data);
                    var TBWorksheetBody = $("#TBWorksheetBody");
                    TBWorksheetBody.html('');

                    $(data).each(function (i, TrialBalance) {

                        if (TrialBalance.AcctName.match("TOTAL")) {
                            vis = 'hidden';
                            totalrowcolor = "background-color: #61646094;color: white;font-size: 12px;font-weight: bold;"
                        }
                        else if (TrialBalance.VarianceDr != "0") {
                            totalrowcolor = "background-color:rgba(255, 27, 1, 0.5); color: white;"
                            vis = "";
                        }
                        else if (TrialBalance.VarianceCr != "0") {
                            totalrowcolor = "background-color:rgba(255, 27, 1, 0.5); color: white;"
                            vis = "";
                        }
                        else {
                            totalrowcolor = "";
                            vis = "";
                        }


                        TBWorksheetBody.append('<tr style="' + totalrowcolor + '">' +
                            '<td>' + TrialBalance.FormatCode + '</td>' +
                            '<td hidden>' + TrialBalance.AcctCode + '</td>' +
                            '<td>' + TrialBalance.AcctName + '</td>' +
                            '<td class="text-right">' + numeral(TrialBalance.BegDr).format("0,0.00") + '</td>' +
                            '<td class="text-right">' + numeral(TrialBalance.BegCr).format("0,0.00") + '</td>' +
                            '<td class="text-right">' + numeral(TrialBalance.NetDr).format("0,0.00") + '</td>' +
                            '<td class="text-right">' + numeral(TrialBalance.NetCr).format("0,0.00") + '</td>' +
                            '<td class="text-right">' + numeral(TrialBalance.EndDr).format("0,0.00") + '</td>' +
                            '<td class="text-right">' + numeral(TrialBalance.EndCr).format("0,0.00") + '</td>' +
                            '<td class="text-right">' + numeral(TrialBalance.RunningDr).format("0,0.00") + '</td>' +
                            '<td class="text-right">' + numeral(TrialBalance.RunningCr).format("0,0.00") + '</td>' +
                            '<td class="text-right">' + numeral(TrialBalance.VarianceDr).format("0,0.00") + '</td>' +
                            '<td class="text-right">' + numeral(TrialBalance.VarianceCr).format("0,0.00") + '</td>' +
                            '<td hidden >' + TrialBalance.TransID + '</td>' +
                            '<td align="middle">' +
                            '<button type="button" id="btnView_WS" class="btn btn-xs btn-outline-primary btn-rounded" title="Click to View Transactions" ' +
                            ' data-FormatCode ="' + TrialBalance.FormatCode + '"' +
                            ' data-AcctCode ="' + TrialBalance.AcctCode + '"' +
                            ' data-AcctName ="' + TrialBalance.AcctName + '"' + vis + '' +
                            ' data-VarianceDr ="' + TrialBalance.VarianceDr + '"' +
                            ' data-VarianceCr ="' + TrialBalance.VarianceCr + '"' +
                            ' >' +
                            '<i class="fa fa-folder-open"></i>' +
                            '</button > ' +
                            '</td > ' +
                            '</tr>')

                    });

                    //$('#TBWorksheetHeader').DataTable();
                    //$('#TBWorksheetHeader').append(
                    //      $('<tfoot/>').append($("#TBWorksheetHeader thead tr").clone())
                    //    );

                    $("#TBWorksheetHeader").DataTable({
                        scrollX: true,
                        ordering: false//,
                        //fixedColumns: {
                        //    leftColumns: 0,
                        //    rightColumns: 1
                        //}
                    }).draw();



                    if (document.querySelectorAll('#TBWorksheetHeader tbody tr').length > 1) {
                        document.getElementById('btnSave_WS').disabled = false;
                        //document.getElementById('btnAddbegAmt_WS').disabled = false;
                        document.getElementById('btnExport_WS').disabled = false;
                    }
                    else {
                        document.getElementById('btnSave_WS').disabled = true;
                        //document.getElementById('btnAddbegAmt_WS').disabled = true;
                        document.getElementById('btnExport_WS').disabled = true;
                    }

                    var table = $('#TBWorksheetHeader').DataTable();
                    table.columns([9, 10, 11, 12]).visible(!posted)




                    $(".preloader-it").fadeOut("slow");
                })
                .fail(function (stat, msg, custom) {
                    $(".preloader-it").fadeOut("slow");
                    toastr.warning(stat.status + ": " + custom)
                });
        }

       
        

    };
    //-----------------------GENERATE TB-----------------------------------------
    $("#btnGenerate_WS").on("click", function () {
        GenerateTB();
    });
    //----------------------------------------------------------------
    $("#TBWorksheetHeader").on("click", "#btnView_WS", function () {

        if (getBool(AllowView) == false) {
            toastr.info("Access Denied!", "Notification");
            return;
        }


        var formatcode = $(this).attr("data-FormatCode");
        var branch = $("#cboBranch_WS").val();
        var month = $("#cboMonth_WS").val();
        var year = $("#txtyear_WS").val();
        var posted = document.getElementById("ChkPosted_WS").checked;
        var AccountName = $(this).attr("data-AcctName");

        LoadModal(month, year, posted, formatcode, AccountName, 0)

    });
    //-----------------------RECON-----------------------------------------
    $("#mod-WSView").on('click', '#btnRecon_WS', function () {

        var TBData = [];
        var oTable = $('#tblJEDetailsHeader').DataTable();
        oTable.rows().every(function (index, element) {
            var row = $(this.nodes());
            var statusElement = row.find('td:first-child input[type="checkbox"]');
            var isChecked = statusElement.prop('checked');
            var data = this.data();
            if (isChecked == true && data[2] == "0") {
                TBData.push({
                    "TransID": data[3]
                })

            }
    
        })
    

        if (TBData.length == 0)
        {
         
            toastr.info("No Record/s Selected!", "Notification");
        }

        else
        {
            $.confirm({
                title: "Confirmation",
                content: "Reconcile Selected Transactions?",
                buttons: {
                    yes: function () {
                        $(".preloader-it").fadeIn(); //show
                        $.post("/CBS/TrialBalance/Recon", { TB: TBData })
                            .done(function () {
                               
                                var formatcode = $("#txtFormatCode_WS", "#mod-WSView").val();
                                var branch = $("#cboBranch_WS").val();
                                var month = $("#cboMonth_WS").val();
                                var year = $("#txtyear_WS").val();
                                var posted = document.getElementById("ChkPosted_WS").checked;
                                var AccountName = $("#txtAccountName_WS", "#mod-WSView").val();;

                                LoadModal(month, year, posted, formatcode, AccountName, 1)
                                                                
                                $(".preloader-it").fadeOut("slow");
                                toastr.success("Transaction/s successfully Reconciled.", "Notification");
                           

                            })
                            .fail(function (stat, msg, custom) {
                                $(".preloader-it").fadeOut("slow");
                                toastr.info(stat.status + ": " + custom)
                            })

                    },
                    cancel: function () { }
                }

            })
        }
    

    })
    //-----------------------HIDE RECON-------------------------
    $('#mod-WSView').on('click', '#ChkHideRecon_WS', function () {
        var table = $("#tblJEDetailsHeader").DataTable();
        if (this.checked == true){
            table.column(2).search("(^0$)", true, false).draw();
        }
        else if (this.checked == false) {
            table.column(2).search('', true, false).draw();
        }
    });
    //----------------------------------------------------------
    //---------------------SAVE---------------------------------
    $('#btnSave_WS').on('click', function () {

        if (getBool(AllowAdd) == false) {
            toastr.info("Access Denied!", "Notification");
            return;
        }


        var branch = $("#cboBranch_WS").val();
        var month = $("#cboMonth_WS").val();
        var year = $("#txtyear_WS").val();
        var Post = 0;
        if (month == 13) {Post = 1;}
       
        var TBData = [];
        var data = $("#TBWorksheetHeader").DataTable().rows().data();
        data.each(function (value, index) {

            if (value[0] != "-")
            {
                TBData.push({
                    "Branch": branch,
                    "FormatCode": value[0],
                    "Month": month,
                    "Year": year,
                    "Post": Post,
                    "BegAmt": numeral(value[3]).value() - numeral(value[4]).value(),
                    "NetAmt": numeral(value[5]).value() - numeral(value[6]).value(),
                    "EndDr": numeral(value[7]).value(),
                    "EndCr": numeral(value[8]).value(),
                    "VarianceDr": numeral(value[11]).value(),
                    "VarianceCr": numeral(value[12]).value(),
                    "TransID": value[13]
                });
            }
        });
     
        if ((parseFloat(TBData[TBData.length - 1].EndDr) - parseFloat(TBData[TBData.length - 1].EndCr)) != 0)
        {
            toastr.info("Unbalanced Transactions. Please check.", "Notification");
        }
        else if ((parseFloat(TBData[TBData.length - 1].VarianceDr) + parseFloat(TBData[TBData.length - 1].VarianceCr)) > 0)
        {
            toastr.info("Variance exists. Please check.", "Notification");
        }
        else
        {
            $.confirm({
                title: "Confirmation",
                content: "Save Records?",
                buttons: {
                    yes: function () {
                        $.post("/CBS/TrialBalance/ValidateBeforeSaving", { Branch: branch, Month: month, Year: year })
                            .done(function (data) {
                                data = JSON.parse(data);
                                

                                if (data == "4")
                                {
                                    $.confirm({
                                        title: "Confirmation",
                                        content: "Posted record/s already exists. If you overwrite the record/s, Posted Financial Statement will be deleted. Would you like to continue?",
                                        buttons: {
                                            yes: function () {
                                                $(".preloader-it").fadeIn(); //show
                                                $.post("/CBS/TrialBalance/SaveWorkSheet", { TB: TBData, Branch: branch, Month: month, Year: year, isExist: true })
                                                .done(function (data) {
                                                    data = JSON.parse(data);
                                                    $(".preloader-it").fadeOut("slow");
                                                    toastr.success("Record Successfully Saved!.", "Notification");
                                                })
                                                .fail(function (stat, msg, custom) {
                                                    $(".preloader-it").fadeOut("slow");
                                                    toastr.info(stat.status + ": " + custom)
                                                })

                                            },
                                            cancel: function () { }
                                        }
                                    });
                                }
                                else
                                {
                                    $(".preloader-it").fadeIn(); //show
                                    $.post("/CBS/TrialBalance/SaveWorkSheet", { TB: TBData, Branch: branch, Month: month, Year: year, isExist: false })
                                    .done(function (data) {
                                        data = JSON.parse(data);
                                        $(".preloader-it").fadeOut("slow");
                                        toastr.success("Record Successfully Saved!.", "Notification");
                                    })
                                    .fail(function (stat, msg, custom) {
                                        $(".preloader-it").fadeOut("slow");
                                        toastr.info(stat.status + ": " + custom)
                                    })
                                }
                                
                            })
                            .fail(function (stat, msg, custom) {
                                toastr.info(stat.status + ": " + custom)
                            })
                    },
                    cancel: function () {
                        
                    }

                }


            })
        }


    })
    //---------------------EXPORT-------------------------------
    $("#btnExport_WS").on('click', function () {
        if (getBool(AllowExport) == false) {
            toastr.info("Access Denied!", "Notification");
            return;
        }


        $.confirm({
            title: "Confirmation",
            content: "Extract Record/s?",
            buttons: {
                yes: function () {
                    $(".preloader-it").fadeIn(); //show
                    var branchCode = $("#cboBranch_WS").val();
                    
                    var cbo = document.getElementById("cboBranch_WS");
                    var BranchName = cbo.options[cbo.selectedIndex].text;
                    
                    var month = $("#cboMonth_WS").val();
                    var year = $("#txtyear_WS").val();
                    var posted = document.getElementById("ChkPosted_WS").checked;

                    $.post("/CBS/TrialBalance/ExtractWS", { BranchName: BranchName, BranchCode: branchCode, Month: month, Year: year, Posted: posted })
                    .done(function(data){
                        window.location = '/CBS/TrialBalance/Download?fileGuid=' + data.FileGuid + '&filename=' + data.FileName;
                            $(".preloader-it").fadeOut("slow");
                            toastr.success("Record successfully Exported.", "Notification");
                    })
                    .fail(function (stat, msg, custom) {
                        $(".preloader-it").fadeOut("slow");
                        toastr.info(stat.status + ": " + custom)
                    })
                },
                cancel: function(){}
                
            }


        })

    })
    //----------ADD BEGINNING AMOUNT IMPORT---------------------
    $("#btnAddbegAmt_WS").on('click', function () {

        if (getBool(AllowAdd) == false) {
            toastr.info("Access Denied!", "Notification");
            return;
        }

        var branchCode = $("#cboBranch_WS").val();

        var cbo = document.getElementById("cboBranch_WS");
        var BranchName = cbo.options[cbo.selectedIndex].text;

        var month = document.getElementById("cboMonth_WS");
        var MonthName = month.options[month.selectedIndex].text;

        var month = $("#cboMonth_WS").val();
        var year = $("#txtyear_WS").val();
        var posted = document.getElementById("ChkPosted_WS").checked;


        if (branchCode == "")
        {
            toastr.info("Branch is required", "Notification")
        }
        else if (month == "")
        {
            toastr.info("Month is required", "Notification")
        }
        else if (year == "") {
            toastr.info("Year is required", "Notification")
        }
        else if (year.length != 4) {
             toastr.error("Invalid Year", "Notification");
            }
        else {
            $.confirm({
                title: "Confirmation",
                content: "Add Beginning Amount to " + BranchName + " for " + MonthName + " " +  year +  "?",
                buttons: {
                    yes: function () {
                        $("#tblWSAddbegAmnt_Header tbody tr").remove();
                        $("#tblWSAddbegAmnt_Header").DataTable().clear().draw();
                        $("#tblWSAddbegAmnt_Header").DataTable().destroy();

                        $('#txtImportFile_WS').val('');
                        $('.custom-file-label').text("Choose file...");
                        $('#mod-WSAddBegAmt').modal('show');
                       
                    },
                    cancel: function () { }
                }
            })
        }
        

    })
    //----------ADD BEGINNING AMOUNT IMPORT---------------------
    $('#txtImportFile_WS').on('change', function () {
        //get the file name
        var fileName = $(this).val();
        $(this).next('.custom-file-label').html(fileName.replace('C:\\fakepath\\', " "));
    })
     //----------ADD BEGINNING AMOUNT IMPORT---------------------
    $("#btnImportExcel_WS").on('click', function () {

        if (getBool(AllowImport) == false) {
            toastr.info("Access Denied!", "Notification");
            return;
        }

        var formData = new FormData()
        var fileInput = document.getElementById('txtImportFile_WS')
        
        for (i = 0; i < fileInput.files.length; i++) {
            formData.append(fileInput.files[i].name, fileInput.files[i]);
        }

       
        $("#tblWSAddbegAmnt_Body").html('');

        $.ajax({
            url: "/CBS/TrialBalance/ImportBegAmount",
            type: "POST",
            processData: false,
            contentType: false,
            data: formData,
            success: function (data) {
                $("#tblWSAddbegAmnt_Header tbody tr").remove();
                $("#tblWSAddbegAmnt_Header").DataTable().clear().draw();
                $("#tblWSAddbegAmnt_Header").DataTable().destroy();

                  var tblWSAddbegAmnt_Body = $("#tblWSAddbegAmnt_Body");
                  tblWSAddbegAmnt_Body.html('');

                  $(data).each(function (i, TrialBalance) {
                      tblWSAddbegAmnt_Body.append('<tr>' +
                          '<td>'+ TrialBalance.FormatCode +'</td>' + 
                          '<td>' + TrialBalance.AcctName +'</td>' + 
                          '<td class="text-right">' + numeral(TrialBalance.BegDr).format("0,0.00") + '</td>' + 
                          '<td class="text-right">' + numeral(TrialBalance.BegCr).format("0,0.00") + '</td>' +
                          '</tr >')
                  });
                 
                  $("#tblWSAddbegAmnt_Header").DataTable({
                      scrollX: true
                  }).draw();


            },
            error: function (stat, msg, custom) {
                
                $(".preloader-it").fadeOut('slow');
                toastr.info(stat.status + ": " + custom);
            }
        })


    })
    //---------- SAVE NEW BEGINNING AMOUNT--------------------
    $('#btnSave_WSAddBegAmnt').on('click', function () {
        var branchCode = $("#cboBranch_WS").val();

        var cbo = document.getElementById("cboBranch_WS");
        var BranchName = cbo.options[cbo.selectedIndex].text;

        var month = document.getElementById("cboMonth_WS");
        var MonthName = month.options[month.selectedIndex].text;

        var month = $("#cboMonth_WS").val();
        var year = $("#txtyear_WS").val();
        var posted = document.getElementById("ChkPosted_WS").checked;
        var excelfileName = $("#txtImportFile_WS").val();
        var fileName = excelfileName.replace('C:\\fakepath\\', " ");

        if (document.querySelectorAll('#tblWSAddbegAmnt_Header tbody tr').length == 0) {
            toastr.info("No Records to Save, Please Import first", "Notification")
        }
        else
        {
            $.confirm({
                title: "Confirmation",
                content: "Save Beginning Balance of " + BranchName + " for " + MonthName + " " + year + "?",
                buttons: {
                    yes: function () {
                        $(".preloader-it").fadeIn(); //show
                        var TBImport = [];
                        var data = $("#tblWSAddbegAmnt_Header").DataTable().rows().data();
                        data.each(function (value, index) {
                            TBImport.push({
                                "Branch": branchCode,
                                "FormatCode": value[0],
                                "TransAmount": numeral(value[2]).value() - numeral(value[3]).value()

                            })

                        })
                        $.post("/CBS/TrialBalance/SaveBegAmount", { TB: TBImport, branch: branchCode, month: month, year: year, filename: fileName })
                            .done(function () {
                                $(".preloader-it").fadeOut("slow");
                                toastr.success("Record successfully Saved.", "Notification");
                            })
                            .fail(function (stat, msg, custom) {
                                $(".preloader-it").fadeOut("slow");
                                toastr.info(stat.status + ": " + custom)
                            })


                    },
                    cancel: function () { }

                }
            })
        }



      

    })
    //---------------------------------------------------------
    
});



