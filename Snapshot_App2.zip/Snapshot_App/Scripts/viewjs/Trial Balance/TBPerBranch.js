﻿$(document).ready(function () {
    document.getElementById('dtsd').valueAsDate = new Date()
    document.getElementById('dted').valueAsDate = new Date()

    //----------------------------------------------------------------
    $.post("/CBS/Common/GetBranch", function (data) {
        data = JSON.parse(data);
        var cboBranch = $("#cboBranch");
        cboBranch.html('');
        $(data).each(function (index, br) {
            cboBranch.append('<option value="' + br.Whscode + '">' + br.whsName + '</option>');
        });
    });

    //----------------------------------------------------------------
    $("#btnGenerate").on("click", function () {

        var branch = $("#cboBranch").val();
        var Dtfrm = $("#dtsd").val();
        var Dtto = $("#dted").val();
              
        if(Dtfrm == "")
        {
            toastr.info("From Date is required","Notification")
            document.getElementById("dtsd").focus();
        }
        else if(Dtto == ""){
            toastr.info("To Date is required", "Notification")
            document.getElementById("dted").focus();
        }

        else
        {  $(".preloader-it").fadeIn(); //show
            $("#tblTBPerBranch_Header tbody tr").remove();
            $("#tblTBPerBranch_Header").DataTable().clear().draw();
            $("#tblTBPerBranch_Header").DataTable().destroy();


            $.post("/CBS/TrialBalance/TBPerBranch", { branch: branch, frm: Dtfrm, to: Dtto })
            .done(function (data) {
                data = JSON.parse(data);
                var tblTBPerBranch_Body = $("#tblTBPerBranch_Body");
                tblTBPerBranch_Body.html('');

                
                $(data).each(function (i, TrialBalance) {

                    tblTBPerBranch_Body.append('<tr>' +
                              '<td>' + TrialBalance.FormatCode + '</td>' +
                              '<td>' + TrialBalance.AcctName + '</td>' +
                              '<td class="text-right">' + numeral(TrialBalance.BegDr).format("0,0.00") + '</td>' +
                              '<td class="text-right">' + numeral(TrialBalance.BegCr).format("0,0.00") + '</td>' +
                              '<td class="text-right">' + numeral(TrialBalance.NetDr).format("0,0.00") + '</td>' +
                              '<td class="text-right">' + numeral(TrialBalance.NetCr).format("0,0.00") + '</td>' +
                              '<td class="text-right">' + numeral(TrialBalance.EndDr).format("0,0.00") + '</td>' +
                              '<td class="text-right">' + numeral(TrialBalance.EndCr).format("0,0.00") + '</td>' +
                              '</tr>')
                });
                $("#tblTBPerBranch_Header").DataTable().draw();
                $(".preloader-it").fadeOut("slow");
            })

               .fail(function (stat, msg, custom) {
                   $(".preloader-it").fadeOut("slow");
                   toastr.warning(stat.status + ": " + custom)
               });
            }

      
    });
    //----------------------------------------------------------------
    $("#btnExtract").on("click", function () {
    
       
        var BranchCode = $("#cboBranch").val();

        var cbobranch = document.getElementById("cboBranch")
        var branch = cbobranch.options[cbobranch.selectedIndex].text;

        var Dtfrm = $("#dtsd").val();
        var Dtto = $("#dted").val();
        
        if (Dtfrm == "") {
            toastr.info("From Date is required", "Notification")
            document.getElementById("dtsd").focus();
        }
        else if (Dtto == "") {
            toastr.info("To Date is required", "Notification")
            document.getElementById("dted").focus();
        }

        else{
                $.confirm({
                    title: "Confirmation",
                    content: "Extract Records?",
                    buttons: {
                        yes: function () {
                            var isfromgrid = false;
                            var GridData = [];
                            var TBData = $("#tblTBPerBranch_Header").DataTable().rows().data();
                            if (TBData.length > 0)
                            {
                                isfromgrid = true;
                                TBData.each(function (value, index) {
                                    GridData.push({
                                        "FormatCode": value[0],
                                        "AcctName": value[1],
                                        "BegDr": numeral(value[2]).value(),
                                        "BegCr": numeral(value[3]).value(),
                                        "NetDr": numeral(value[4]).value(),
                                        "NetCr": numeral(value[5]).value(),
                                        "EndDr": numeral(value[6]).value(),
                                        "EndCr": numeral(value[7]).value()
                                    })

                                })
                            }
                           
                           
                            $(".preloader-it").fadeIn(); //show
                            $.post("/CBS/TrialBalance/ExtractTBPerBranch", { GridData: GridData, BranchName: branch, BranchCode: BranchCode, dtfrm: Dtfrm, dtto: Dtto, isfromGrid: isfromgrid })
                            .done(function (data) {
                                window.location = '/CBS/TrialBalance/Download?fileGuid=' + data.FileGuid + '&filename=' + data.FileName;
                                $(".preloader-it").fadeOut("slow");
                                toastr.success("Record successfully Exported.", "Notification");
                            })
                             .fail(function (stat, msg, custom) {
                                 $(".preloader-it").fadeOut("slow");
                                 toastr.warning(stat.status + ": " + custom)
                             });
                        },
                        cancel: function () { }

                    }

                })
          }

    })

});