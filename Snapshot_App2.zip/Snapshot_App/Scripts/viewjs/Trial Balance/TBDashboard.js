﻿$(document).ready(function () {

    var AllowAdd;
    var AllowEdit;
    var AllowDelete;
    var AllowView;
    var AllowPrint;
    var AllowImport
    var AllowExport;
    var AllowPost;
    var AllowUnpost;
    var AllowApprove;
    
    $.ajax({
        type: "POST",
        url: "/CBS/Common/Permissions",
        success: function (data) {
            data = JSON.parse(data)
                AllowAdd = data[0]["Add"]
                AllowEdit = data[0]["Edit"];
                AllowDelete = data[0]["Delete"];
                AllowView = data[0]["View"];
                AllowPrint = data[0]["Print"];
                AllowImport = data[0]["Import"];
                AllowExport = data[0]["Export"];
                AllowPost = data[0]["Post"];
                AllowUnpost = data[0]["Unpost"];
                AllowApprove = data[0]["Approve"];
        },
        async: false 

    })
    //-------------------------------
    function getBool(val) {
        return !!JSON.parse(String(val).toLowerCase());
    }

 //--------------------------------------
    function LoadDashboard(year) {
       // $(".preloader-it").fadeIn(); //show
        if (typeof year == "undefined")
        {
            var today = new Date();
            year = today.getFullYear();
        }

        //year = 2019;

        $('#TBDashboardPeriod').text(year);

        $.post("/CBS/TBDashboard/Dash", { year: year })
                        .done(function (data) {
                            
                            data = JSON.parse(data);
                         //   console.log(data)
                        
                            $("#tblNewAcc_Header tbody tr").remove();
                            $("#tblNewAcc_Header").DataTable().clear().draw();
                            $("#tblNewAcc_Header").DataTable().destroy();
                            
                            $("#tblPending_Header tbody tr").remove();
                            $("#tblPending_Header").DataTable().clear().draw();
                            $("#tblPending_Header").DataTable().destroy();

                            $("#tabtblSetup_Header tbody tr").remove();
                            $("#tabtblSetup_Header").DataTable().clear().draw();
                            $("#tabtblSetup_Header").DataTable().destroy();

                            $("#tabtblWS_Header tbody tr").remove();
                            $("#tabtblWS_Header").DataTable().clear().draw();
                            $("#tabtblWS_Header").DataTable().destroy();

                            $("#tabtblFS_Header tbody tr").remove();
                            $("#tabtblFS_Header").DataTable().clear().draw();
                            $("#tabtblFS_Header").DataTable().destroy();

                            //-------------------------------------NEW ACCOUNTS----------------------
                            var tblNewAcc_Body = $("#tblNewAcc_Body");
                            tblNewAcc_Body.html('');
                            $(data.NewAccounts).each(function (i, TrialBalance) {
                                tblNewAcc_Body.append('<tr>' +
                                    '<td>' + TrialBalance.FormatCode + '</td>' +
                                    '<td>' + TrialBalance.AcctName + '</td>' +
                                    '<td align="middle"><span id="DashTagNewAccnt" class="badge badge-light badge-xs" title="Click to Tag New Account" '+
                                      'data-FormatCode ="' + TrialBalance.FormatCode + '"' +
                                      'data-AcctName ="' + TrialBalance.AcctName + '">Tag</span></td>' + // 'data-toggle="modal" data-target="#Modal-NewAccTagging" '+
                                    '</tr>')
                            });
                            $("#tblNewAcc_Header").DataTable({
                                scrollX: true
                            }).draw();
                            //------------------------------------PENDING----------------------
                            var tblPending_Body = $("#tblPending_Body");
                            tblPending_Body.html('');
                            $(data.Pending).each(function (i, TrialBalance) {
                                tblPending_Body.append('<tr>' +
                                    '<td>' + TrialBalance.Branch + '</td>' +
                                    '<td>' + TrialBalance.setup + '</td>' +
                                    '<td>' + TrialBalance.TBStatus + '</td>' +
                                    '<td>' + TrialBalance.FSStatus + '</td>' +
                                    '</tr>')
                            });
                            $("#tblPending_Header").DataTable({
                                scrollX: true
                            }).draw();

                            //-----------------------------------SETUP---------------------- <a href="javascript:void(0)">Avatar</a>
                            var tabtblSetup_Body = $('#tabtblSetup_Body');
                            tabtblSetup_Body.html('');
                            $(data.Setup).each(function (i, TrialBalance) {
                                tabtblSetup_Body.append('<tr>' +
                                    '<td>' + TrialBalance.BranchCode + '</td>' +
                                    '<td>' + TrialBalance.Branch + '</td>' +
                                    '<td data-Setup="Setup" data-BranchName="' + TrialBalance.Branch + '"  data-Branch="' + TrialBalance.BranchCode + '" title="Click to delete" >' + TrialBalance.setup + '</td>' +
                                    '<td data-Setup="TB" data-BranchName="' + TrialBalance.Branch + '"  data-Branch="' + TrialBalance.BranchCode + '" title="Click to delete">' + TrialBalance.TBStatus + '</td>' +
                                    '<td data-Setup="FS" data-BranchName="' + TrialBalance.Branch + '"  data-Branch="' + TrialBalance.BranchCode + '" title="Click to delete">' + TrialBalance.FSStatus + '</td>' +
                                    '</tr>')
                            });
                            $("#tabtblSetup_Header").DataTable().draw();
                            //-----------------------TB---------------------------------
                            console.log(data.WS)

                            var tabtblWS_Body = $('#tabtblWS_Body');
                            tabtblWS_Body.html('');
                            $(data.WS).each(function (i, TrialBalance) {
                                tabtblWS_Body.append('<tr>' +
                                    '<td>' + TrialBalance.BranchCode_WS + '</td>' +
                                    '<td>' + TrialBalance.Branch_WS + '</td>' +
                                    '<td style="text-align: center;" data-month="1" data-BranchName="' + TrialBalance.Branch_WS + '"  data-Branch="' + TrialBalance.BranchCode_WS + '" title="Click to delete">' + TrialBalance.Jan_WS + '</td>' +
                                    '<td style="text-align: center;" data-month="2" data-BranchName="' + TrialBalance.Branch_WS + '"  data-Branch="' + TrialBalance.BranchCode_WS + '" title="Click to delete">' + TrialBalance.Feb_WS + '</td>' +
                                    '<td style="text-align: center;" data-month="3" data-BranchName="' + TrialBalance.Branch_WS + '"  data-Branch="' + TrialBalance.BranchCode_WS + '" title="Click to delete">' + TrialBalance.Mar_WS + '</td>' +
                                    '<td style="text-align: center;" data-month="4" data-BranchName="' + TrialBalance.Branch_WS + '"  data-Branch="' + TrialBalance.BranchCode_WS + '" title="Click to delete">' + TrialBalance.Apr_WS + '</td>' +
                                    '<td style="text-align: center;" data-month="5" data-BranchName="' + TrialBalance.Branch_WS + '"  data-Branch="' + TrialBalance.BranchCode_WS + '" title="Click to delete">' + TrialBalance.May_WS + '</td>' +
                                    '<td style="text-align: center;" data-month="6" data-BranchName="' + TrialBalance.Branch_WS + '"  data-Branch="' + TrialBalance.BranchCode_WS + '" title="Click to delete">' + TrialBalance.Jun_WS + '</td>' +
                                    '<td style="text-align: center;" data-month="7" data-BranchName="' + TrialBalance.Branch_WS + '"  data-Branch="' + TrialBalance.BranchCode_WS + '" title="Click to delete">' + TrialBalance.Jul_WS + '</td>' +
                                    '<td style="text-align: center;" data-month="8" data-BranchName="' + TrialBalance.Branch_WS + '"  data-Branch="' + TrialBalance.BranchCode_WS + '" title="Click to delete">' + TrialBalance.Aug_WS + '</td>' +
                                    '<td style="text-align: center;" data-month="9" data-BranchName="' + TrialBalance.Branch_WS + '"  data-Branch="' + TrialBalance.BranchCode_WS + '" title="Click to delete">' + TrialBalance.Sep_WS + '</td>' +
                                    '<td style="text-align: center;" data-month="10" data-BranchName="' + TrialBalance.Branch_WS + '"  data-Branch="' + TrialBalance.BranchCode_WS + '" title="Click to delete">' + TrialBalance.Oct_WS + '</td>' +
                                    '<td style="text-align: center;" data-month="11" data-BranchName="' + TrialBalance.Branch_WS + '"  data-Branch="' + TrialBalance.BranchCode_WS + '" title="Click to delete">' + TrialBalance.Nov_WS + '</td>' +
                                    '<td style="text-align: center;" data-month="12" data-BranchName="' + TrialBalance.Branch_WS + '"  data-Branch="' + TrialBalance.BranchCode_WS + '" title="Click to delete">' + TrialBalance.Dec_WS + '</td>' +
                                    '<td style="text-align: center;" data-month="13" data-BranchName="' + TrialBalance.Branch_WS + '"  data-Branch="' + TrialBalance.BranchCode_WS + '" title="Click to delete" hidden>' + TrialBalance.Posted_WS + '</td>' +
                                    '</tr>')
                            });
                            $("#tabtblWS_Header").DataTable({
                                scrollX: true
                            }).draw();
                            ////-----------------------WS---------------------------------
                            var tabtblFS_Body = $('#tabtblFS_Body');
                            tabtblFS_Body.html('');
                            $(data.FS).each(function (i, TBFS) {
                                tabtblFS_Body.append('<tr>' +
                                    '<td>' + TBFS.BranchCode_FS + '</td>' +
                                    '<td>' + TBFS.Branch_FS + '</td>' +
                                    '<td style="text-align: center;" data-month="1"  data-BranchName="' + TBFS.Branch_FS + '"  data-Branch="' + TBFS.BranchCode_FS + '" title="Click to delete">' + TBFS.Jan_FS + '</td>' +
                                    '<td style="text-align: center;" data-month="2" data-BranchName="' + TBFS.Branch_FS + '"  data-Branch="' + TBFS.BranchCode_FS + '" title="Click to delete">' + TBFS.Feb_FS + '</td>' +
                                    '<td style="text-align: center;" data-month="3" data-BranchName="' + TBFS.Branch_FS + '"  data-Branch="' + TBFS.BranchCode_FS + '" title="Click to delete">' + TBFS.Mar_FS + '</td>' +
                                    '<td style="text-align: center;" data-month="4" data-BranchName="' + TBFS.Branch_FS + '"  data-Branch="' + TBFS.BranchCode_FS + '" title="Click to delete">' + TBFS.Apr_FS + '</td>' +
                                    '<td style="text-align: center;" data-month="5" data-BranchName="' + TBFS.Branch_FS + '"  data-Branch="' + TBFS.BranchCode_FS + '" title="Click to delete">' + TBFS.May_FS + '</td>' +
                                    '<td style="text-align: center;" data-month="6" data-BranchName="' + TBFS.Branch_FS + '"  data-Branch="' + TBFS.BranchCode_FS + '" title="Click to delete">' + TBFS.Jun_FS + '</td>' +
                                    '<td style="text-align: center;" data-month="7" data-BranchName="' + TBFS.Branch_FS + '"  data-Branch="' + TBFS.BranchCode_FS + '" title="Click to delete">' + TBFS.Jul_FS + '</td>' +
                                    '<td style="text-align: center;" data-month="8" data-BranchName="' + TBFS.Branch_FS + '"  data-Branch="' + TBFS.BranchCode_FS + '" title="Click to delete">' + TBFS.Aug_FS + '</td>' +
                                    '<td style="text-align: center;" data-month="9" data-BranchName="' + TBFS.Branch_FS + '"  data-Branch="' + TBFS.BranchCode_FS + '" title="Click to delete">' + TBFS.Sep_FS + '</td>' +
                                    '<td style="text-align: center;" data-month="10" data-BranchName="' + TBFS.Branch_FS + '"  data-Branch="' + TBFS.BranchCode_FS + '" title="Click to delete">' + TBFS.Oct_FS + '</td>' +
                                    '<td style="text-align: center;" data-month="11" data-BranchName="' + TBFS.Branch_FS + '"  data-Branch="' + TBFS.BranchCode_FS + '" title="Click to delete">' + TBFS.Nov_FS + '</td>' +
                                    '<td style="text-align: center;" data-month="12" data-BranchName="' + TBFS.Branch_FS + '"  data-Branch="' + TBFS.BranchCode_FS + '" title="Click to delete">' + TBFS.Dec_FS + '</td>' +
                                    '<td style="text-align: center;" data-month="13" data-BranchName="' + TBFS.Branch_FS + '"  data-Branch="' + TBFS.BranchCode_FS + '" title="Click to delete" >' + TBFS.Posted_FS + '</td>' +
                                    '</tr>')
                            });
                            $("#tabtblFS_Header").DataTable({
                                scrollX: true
                            }).draw();

                            $(".preloader-it").fadeOut("slow");
                        })
                        .fail(function (stat, msg, custom) {
                            console.log(custom)
                            toastr.warning(stat.status + ": " + custom)
                        });
    }
    //--------------------------------
    function GetMonth(monthno) {
        var month = new Array();
        month[1] = "January";
        month[2] = "February";
        month[3] = "March";
        month[4] = "April";
        month[5] = "May";
        month[6] = "June";
        month[7] = "July";
        month[8] = "August";
        month[9] = "September";
        month[10] = "October";
        month[11] = "November";
        month[12] = "December";

        return month[monthno];
    }
    //--------------------------------
    function LoadLowerDashboardData(year)
    {
       // $(".preloader-it").fadeIn(); //show
        $('#TBDashboardPeriod').text(year);

        $.post("/CBS/TBDashboard/Dash", { year: year })
                 .done(function (data) {
                     data = JSON.parse(data);

                     $("#tabtblWS_Header tbody tr").remove();
                     $("#tabtblWS_Header").DataTable().clear().draw();
                     $("#tabtblWS_Header").DataTable().destroy();

                     $("#tabtblFS_Header tbody tr").remove();
                     $("#tabtblFS_Header").DataTable().clear().draw();
                     $("#tabtblFS_Header").DataTable().destroy();

                     $("#tabtblSetup_Header tbody tr").remove();
                     $("#tabtblSetup_Header").DataTable().clear().draw();
                     $("#tabtblSetup_Header").DataTable().destroy();

                     //-----------------------------------SETUP---------------------- 
                     var tabtblSetup_Body = $('#tabtblSetup_Body');
                     tabtblSetup_Body.html('');
                     $(data.Setup).each(function (i, TrialBalance) {
                         tabtblSetup_Body.append('<tr>' +
                             '<td>' + TrialBalance.BranchCode + '</td>' +
                             '<td>' + TrialBalance.Branch + '</td>' +
                             '<td data-Setup="Setup" data-BranchName="' + TrialBalance.Branch + '"  data-Branch="' + TrialBalance.BranchCode + '" title="Click to delete" >' + TrialBalance.setup + '</td>' +
                             '<td data-Setup="TB" data-BranchName="' + TrialBalance.Branch + '"  data-Branch="' + TrialBalance.BranchCode + '" title="Click to delete">' + TrialBalance.TBStatus + '</td>' +
                             '<td data-Setup="FS" data-BranchName="' + TrialBalance.Branch + '"  data-Branch="' + TrialBalance.BranchCode + '" title="Click to delete">' + TrialBalance.FSStatus + '</td>' +
                             '</tr>')
                     });
                     $("#tabtblSetup_Header").DataTable().draw();


                     //-----------------------TB---------------------------------
                     var tabtblWS_Body = $('#tabtblWS_Body');
                     tabtblWS_Body.html('');
                     $(data.WS).each(function (i, TrialBalance) {
                         tabtblWS_Body.append('<tr>' +
                             '<td>' + TrialBalance.BranchCode_WS + '</td>' +
                             '<td>' + TrialBalance.Branch_WS + '</td>' +
                             '<td style="text-align: center;" data-month="1" data-BranchName="' + TrialBalance.Branch_WS + '"  data-Branch="' + TrialBalance.BranchCode_WS + '" title="Click to delete">' + TrialBalance.Jan_WS + '</td>' +
                             '<td style="text-align: center;" data-month="2" data-BranchName="' + TrialBalance.Branch_WS + '"  data-Branch="' + TrialBalance.BranchCode_WS + '" title="Click to delete">' + TrialBalance.Feb_WS + '</td>' +
                             '<td style="text-align: center;" data-month="3" data-BranchName="' + TrialBalance.Branch_WS + '"  data-Branch="' + TrialBalance.BranchCode_WS + '" title="Click to delete">' + TrialBalance.Mar_WS + '</td>' +
                             '<td style="text-align: center;" data-month="4" data-BranchName="' + TrialBalance.Branch_WS + '"  data-Branch="' + TrialBalance.BranchCode_WS + '" title="Click to delete">' + TrialBalance.Apr_WS + '</td>' +
                             '<td style="text-align: center;" data-month="5" data-BranchName="' + TrialBalance.Branch_WS + '"  data-Branch="' + TrialBalance.BranchCode_WS + '" title="Click to delete">' + TrialBalance.May_WS + '</td>' +
                             '<td style="text-align: center;" data-month="6" data-BranchName="' + TrialBalance.Branch_WS + '"  data-Branch="' + TrialBalance.BranchCode_WS + '" title="Click to delete">' + TrialBalance.Jun_WS + '</td>' +
                             '<td style="text-align: center;" data-month="7" data-BranchName="' + TrialBalance.Branch_WS + '"  data-Branch="' + TrialBalance.BranchCode_WS + '" title="Click to delete">' + TrialBalance.Jul_WS + '</td>' +
                             '<td style="text-align: center;" data-month="8" data-BranchName="' + TrialBalance.Branch_WS + '"  data-Branch="' + TrialBalance.BranchCode_WS + '" title="Click to delete">' + TrialBalance.Aug_WS + '</td>' +
                             '<td style="text-align: center;" data-month="9" data-BranchName="' + TrialBalance.Branch_WS + '"  data-Branch="' + TrialBalance.BranchCode_WS + '" title="Click to delete">' + TrialBalance.Sep_WS + '</td>' +
                             '<td style="text-align: center;" data-month="10" data-BranchName="' + TrialBalance.Branch_WS + '"  data-Branch="' + TrialBalance.BranchCode_WS + '" title="Click to delete">' + TrialBalance.Oct_WS + '</td>' +
                             '<td style="text-align: center;" data-month="11" data-BranchName="' + TrialBalance.Branch_WS + '"  data-Branch="' + TrialBalance.BranchCode_WS + '" title="Click to delete">' + TrialBalance.Nov_WS + '</td>' +
                             '<td style="text-align: center;" data-month="12" data-BranchName="' + TrialBalance.Branch_WS + '"  data-Branch="' + TrialBalance.BranchCode_WS + '" title="Click to delete">' + TrialBalance.Dec_WS + '</td>' +
                             '<td style="text-align: center;" data-month="13" data-BranchName="' + TrialBalance.Branch_WS + '"  data-Branch="' + TrialBalance.BranchCode_WS + '" title="Click to delete">' + TrialBalance.Posted_WS + '</td>' +
                             '</tr>')
                     });
                     $("#tabtblWS_Header").DataTable({
                         scrollX: true
                     }).draw();
                     //-----------------------WS---------------------------------
                     var tabtblFS_Body = $('#tabtblFS_Body');
                     tabtblFS_Body.html('');
                     $(data.FS).each(function (i, TBFS) {
                         tabtblFS_Body.append('<tr>' +
                             '<td>' + TBFS.BranchCode_FS + '</td>' +
                             '<td>' + TBFS.Branch_FS + '</td>' +
                             '<td style="text-align: center;" data-month="1"  data-BranchName="' + TBFS.Branch_FS + '"  data-Branch="' + TBFS.BranchCode_FS + '" title="Click to delete">' + TBFS.Jan_FS + '</td>' +
                             '<td style="text-align: center;" data-month="2" data-BranchName="' + TBFS.Branch_FS + '"  data-Branch="' + TBFS.BranchCode_FS + '" title="Click to delete">' + TBFS.Feb_FS + '</td>' +
                             '<td style="text-align: center;" data-month="3" data-BranchName="' + TBFS.Branch_FS + '"  data-Branch="' + TBFS.BranchCode_FS + '" title="Click to delete">' + TBFS.Mar_FS + '</td>' +
                             '<td style="text-align: center;" data-month="4" data-BranchName="' + TBFS.Branch_FS + '"  data-Branch="' + TBFS.BranchCode_FS + '" title="Click to delete">' + TBFS.Apr_FS + '</td>' +
                             '<td style="text-align: center;" data-month="5" data-BranchName="' + TBFS.Branch_FS + '"  data-Branch="' + TBFS.BranchCode_FS + '" title="Click to delete">' + TBFS.May_FS + '</td>' +
                             '<td style="text-align: center;" data-month="6" data-BranchName="' + TBFS.Branch_FS + '"  data-Branch="' + TBFS.BranchCode_FS + '" title="Click to delete">' + TBFS.Jun_FS + '</td>' +
                             '<td style="text-align: center;" data-month="7" data-BranchName="' + TBFS.Branch_FS + '"  data-Branch="' + TBFS.BranchCode_FS + '" title="Click to delete">' + TBFS.Jul_FS + '</td>' +
                             '<td style="text-align: center;" data-month="8" data-BranchName="' + TBFS.Branch_FS + '"  data-Branch="' + TBFS.BranchCode_FS + '" title="Click to delete">' + TBFS.Aug_FS + '</td>' +
                             '<td style="text-align: center;" data-month="9" data-BranchName="' + TBFS.Branch_FS + '"  data-Branch="' + TBFS.BranchCode_FS + '" title="Click to delete">' + TBFS.Sep_FS + '</td>' +
                             '<td style="text-align: center;" data-month="10" data-BranchName="' + TBFS.Branch_FS + '"  data-Branch="' + TBFS.BranchCode_FS + '" title="Click to delete">' + TBFS.Oct_FS + '</td>' +
                             '<td style="text-align: center;" data-month="11" data-BranchName="' + TBFS.Branch_FS + '"  data-Branch="' + TBFS.BranchCode_FS + '" title="Click to delete">' + TBFS.Nov_FS + '</td>' +
                             '<td style="text-align: center;" data-month="12" data-BranchName="' + TBFS.Branch_FS + '"  data-Branch="' + TBFS.BranchCode_FS + '" title="Click to delete">' + TBFS.Dec_FS + '</td>' +
                             '<td style="text-align: center;" data-month="13" data-BranchName="' + TBFS.Branch_FS + '"  data-Branch="' + TBFS.BranchCode_FS + '" title="Click to delete">' + TBFS.Posted_FS + '</td>' +
                             '</tr>')
                     });
                     $("#tabtblFS_Header").DataTable({
                         scrollX: true
                     }).draw();

                     //$(".preloader-it").fadeOut("slow");
                 })
                     .fail(function (stat, msg, custom) {
                         toastr.warning(stat.status + ": " + custom)
                     });
    }
    //-------------------------------
    function ViewNewAcc(whsCode) {
        $("#tblNewAccTagging_Header tbody tr").remove();
        $("#tblNewAccTagging_Header").DataTable().clear().draw();
        $("#tblNewAccTagging_Header").DataTable().destroy();

        $.post("/CBS/TBDashboard/NewAccLoadMaps", { Whscode: whsCode })
        .done(function (data) {
            data = JSON.parse(data);
            var tblNewAccTagging_Body = $("#tblNewAccTagging_Body");
            tblNewAccTagging_Body.html('');

            $(data).each(function (i, Dashboard) {
                tblNewAccTagging_Body.append('<tr>' +
                    '<td>' + Dashboard.DocEntry + '</td>' +
                    '<td>' + Dashboard.Desc + '</td>' +
                    '<td>' + Dashboard.TBType + '</td>' +
                    '<td>' + Dashboard.RowNo + '</td>' +
                    '<td>' + Dashboard.tagCount + '</td>' +
                    '<td align="center">' +
                      ' <div class="btn-group btn-group-rounded" role="group"> ' +
                          '  <button id="btnViewNewAccDetail" type="button" class="btn btn-outline-primary btn-xs"  title="click to view" '+
                               'data-DocEntry="' + Dashboard.DocEntry + '"' +
                               'data-whsCode="' + whsCode + '"' +
                               'data-Desc="' + Dashboard.Desc + '"' +
                                '> ' +
                          '     <i class="fa fa-folder-open mr-5"></i> View ' +
                          '  </button> '+
                          '  <button id="btnInsertNewAcc" type="button" class="btn btn-outline-primary btn-xs" title="click to insert" ' +
                                   'data-DocEntry="' + Dashboard.DocEntry + '"' +
                                   'data-whsCode="' + whsCode + '"' +
                                   'data-Desc="' + Dashboard.Desc + '"' +
                                   'data-TBType="' + Dashboard.TBType + '"' +
                                   'data-RowNo="' + Dashboard.RowNo + '"' +
                                '> ' +
                          '     <i class="fa fa-plus-circle mr-5"></i> Insert ' +
                          '  </button> ' +
                             '  <button id="btnDeleteNewAcc" type="button" class="btn btn-outline-primary btn-xs" title="click to Delete" ' +
                                   'data-DocEntry="' + Dashboard.DocEntry + '"' +
                                   'data-whsCode="' + whsCode + '"' +
                                   'data-Desc="' + Dashboard.Desc + '"' +
                                   'data-TBType="' + Dashboard.TBType + '"' +
                                   'data-RowNo="' + Dashboard.RowNo + '"' +
                                '> ' +
                          '     <i class="fa fa-trash mr-5"></i> Delete ' +
                          '  </button> ' +
                      '  </div> ' +
                       '</td>'+
                     '</tr>');
            });
            $("#tblNewAccTagging_Header").DataTable().draw();
            
            if (data.length > 0) {
                $("#txtNewAcctwhsCode").val(whsCode);
                $("#Modal-NewAccTagging").modal("show");
            }
        })
          .fail(function (stat, msg, custom) {
              toastr.warning(stat.status + ": " + custom)
          })
    };
 
    //--------------------------------------

    LoadDashboard();
    //--------------------------------
    $('#tabtblSetup_Header tbody').on('click', 'td', function () {

        var table = $('#tabtblSetup_Header').DataTable();
        var setup = $(this).attr("data-Setup");
        var setup_param = $(this).attr("data-Setup");
        var Branch =  $(this).attr("data-Branch");
        var BranchName = $(this).attr("data-BranchName");

        if (setup == "TB"){setup = "Trial Balance"}
        else if (setup == "FS"){setup = "Financial Statement"}
         
      
        if (table.cell(this).data() == "OK")
        {
            if (getBool(AllowDelete) == false) {
                toastr.info("Access Denied!", "Notification");
                return;
            }

            $.confirm({
                title: "Confirmation",
                content: "Are you sure you want to delete " + setup + " of " + " " + BranchName + "?",
                buttons: {
                    yes: function () {

                        $.post("/CBS/TBDashboard/DeleteSetup", { Whscode: Branch, setuptype: setup_param })
                        .done(function () {
                            var year = $('#TBDashboardPeriod').text();
                            LoadLowerDashboardData(year);
                            toastr.success(setup + " for " + BranchName + " is sucessfully deleted.", "Notification");
                            
                            
                        })
                          .fail(function (stat, msg, custom) {
                              toastr.warning(stat.status + ": " + custom)
                          });
                    },
                    cancel: function () {
                    }
                }

            });
        }
       
    })
    //--------------------------------
    $('#tabtblWS_Header tbody').on('click', 'td', function () {
        

        var table = $('#tabtblWS_Header').DataTable();
        var month = $(this).attr("data-month");
        var Branch = $(this).attr("data-Branch");
        var BranchName = $(this).attr("data-BranchName");
        var year = $('#TBDashboardPeriod').text();
       
        if (table.cell(this).data() == "OK")
        {
            if (getBool(AllowDelete) == false) {
                toastr.info("Access Denied!", "Notification");
                return;
            }
            $.confirm({
                title: "Confirmation",
                content: "Are you sure you want to delete the Trial Balance of " + BranchName + " for " + GetMonth(month).toUpperCase() + " " + year + "?<br/> <br/>  Note: ALL POSTED Trial balance and Financial statements will also be deleted.",
                buttons:{
                    yes: function () {
                        var year = $('#TBDashboardPeriod').text();
                        $.post("/CBS/TBDashboard/Delete", { Whscode: Branch, month: month, year: year, mode: "DeleteTB" })
                          .done(function () {
                              LoadLowerDashboardData(year);
                              toastr.success("Trial Balance of " + BranchName + " for " + GetMonth(month).toUpperCase() + " " + year + " is sucessfully deleted.", "Notification");
                              
                          })
                          .fail(function (stat, msg, custom) {
                              toastr.warning(stat.status + ": " + custom)
                          });
                    },
                    cancel: function(){}
                }


            })
        }
       

    })
    //--------------------------------
    $('#tabtblFS_Header tbody').on('click', 'td', function () {

        var table = $('#tabtblFS_Header').DataTable();
        var month = $(this).attr("data-month");
        var Branch = $(this).attr("data-Branch");
        var BranchName = $(this).attr("data-BranchName");
        var year = $('#TBDashboardPeriod').text();

        console.log(Branch)
        console.log(month)
        console.log(year)
    

        if (table.cell(this).data() == "OK") {

            if (getBool(AllowDelete) == false) {
                toastr.info("Access Denied!", "Notification");
                return;
            }

            $.confirm({
                title: "Confirmation",
                content: "Are you sure you want to delete the Financial Statement of " + BranchName + " for " + GetMonth(month).toUpperCase() + " " + year + "?<br/> <br/> Note: ALL POSTED Financial Statement will also be deleted.",
                buttons: {
                    yes: function () {
                       
                        $.post("/CBS/TBDashboard/Delete", { Whscode: Branch, month: month, year: year, mode: "DeleteFS" })
                          .done(function () {
                              var year = $('#TBDashboardPeriod').text();
                              toastr.success("Financial Statement of " + BranchName + " for " + GetMonth(month).toUpperCase() + " " + year + " is sucessfully deleted.", "Notification");
                              LoadLowerDashboardData(year);
                          })
                          .fail(function (stat, msg, custom) {
                              toastr.warning(stat.status + ": " + custom)
                          });
                    },
                    cancel: function () { }
                }


            })
        }
    })
    //--------------------------------
    $("#Modal-GenerateTBDashboard").on('click', '#btnTBDashGenerate', function () {
        var year = $('#TBDashtxtyear').val()

        if (year.length != 4) {
            toastr.error("Invalid Year", "Notification");
        }
        else
        {
            LoadLowerDashboardData(year);
      
        }



       
    })
    //--------------------------------
    $("#tblNewAcc_Header tbody").on('click', "#DashTagNewAccnt", function () {

        if (getBool(AllowView) == false) {
            toastr.info("Access Denied!", "Notification");
            return;
        }


        var FormatCode = $(this).attr("data-FormatCode");
        var AccntName = $(this).attr("data-AcctName");
        var whsCode = FormatCode.substring(8, 5);
        ViewNewAcc(whsCode);

    })
    //--------------------------------
    $("#Modal-NewAccTagging").on("click", "#btnNewAccDuplicate", function () {

        if (getBool(AllowAdd) == false) {
            toastr.info("Access Denied!", "Notification");
            return;
        }

        $("#Modal-NewAccTagging").modal('hide');
        $("#txtDuplicateNewAcctwhsCode").val($("#txtNewAcctwhsCode").val());

        $.post("/CBS/Common/GetBranch", function (data) {
            data = JSON.parse(data);
            var cboNewAccDupWhs = $("#Modal-NewAccDuplicate #cboNewAccDupWhs");
            cboNewAccDupWhs.html("");
            $(data).each(function (index, br) {
                cboNewAccDupWhs.append('<option value="' + br.Whscode + '">' + br.whsName + '</option>');
            });
        });



        $("#Modal-NewAccDuplicate").modal('show');
    });
    //--------------------------------
    $("#Modal-NewAccDuplicate").on("click", "#btnCloseNEwAccCopy", function () {
       

        $("#Modal-NewAccDuplicate").modal('hide');
        var whsCode = $("#txtDuplicateNewAcctwhsCode").val();
        ViewNewAcc(whsCode);
    })
    //--------------------------------
    $("#Modal-NewAccDuplicate").on("click", "#btnCloseNEwAccCopy2", function () {
        $("#Modal-NewAccDuplicate").modal('hide');
        var whsCode = $("#txtDuplicateNewAcctwhsCode").val();
        ViewNewAcc(whsCode);
    })
    //------------------------------
    $("#Modal-NewAccDuplicate").on("click", "#btnNEwAccCopy", function () {
        $.confirm({
            title: "Confirmation",
            content: "Are you sure you want to copy?",
            buttons:{
                yes: function(){
                    $(".preloader-it").fadeIn(); //show
                    var WhsCode_Source = $("#txtDuplicateNewAcctwhsCode").val();
                    var WhsCode_To = $("#cboNewAccDupWhs").val();

                    //console.log(WhsCode_Source);
                    //console.log(WhsCode_To);
                    $.post("/CBS/TBDashboard/Duplicate", { WhsCode_Source: WhsCode_Source, WhsCode_To: WhsCode_To })
                    .done(function () {
                        $(".preloader-it").fadeOut("slow");
                        toastr.success("Record successfully Copied.", "Notification");
                        $("#Modal-NewAccDuplicate").modal('hide');
                        var whsCode = $("#txtDuplicateNewAcctwhsCode").val();
                        ViewNewAcc(whsCode);
                    })
                     .fail(function (stat, msg, custom) {
                         $(".preloader-it").fadeOut("slow");
                         toastr.warning(stat.status + ": " + custom)
                     });

                    

                },
                cancel: function () {
                  
                }
            }
        })
    });
    //--------------------------------
    $("#Modal-NewAccTagging").on("click", "#btnViewNewAccDetail", function () {
         
        if (getBool(AllowView) == false)
        {
            toastr.info("Access Denied!", "Notification");
            return;
        }

        var whsCode = $(this).attr("data-whsCode");
        var DocEntry = $(this).attr("data-DocEntry");

        $("#Modal-NewAccViewDetail #txtNewAccDescription").val($(this).attr("data-Desc"));
        $("#Modal-NewAccViewDetail #txtNewDocEntry").val(DocEntry);
        $("#Modal-NewAccViewDetail #txtNewWhsCode").val(whsCode);
        document.getElementById("txtNewAccDescription").readOnly = true;
        $("#chkDescControl").prop("checked", false);

        $("#tblNewAccDetail_Header tbody tr").remove();
        $("#tblNewAccDetail_Header").DataTable().clear().draw();
        $("#tblNewAccDetail_Header").DataTable().destroy();
  
        $.post("/CBS/TBDashboard/LoadTagged", { WhsCode: whsCode, DocEntry: DocEntry })
        .done(function (data) {
            data = JSON.parse(data);
            
            var checkstate;
            var tblNewAccDetail_Body = $("#tblNewAccDetail_Body");
            tblNewAccDetail_Body.html("");
            $(data).each(function (i, Dashboard) {

                if (Dashboard.Tagged == true){checkstate = "checked";}
                else{checkstate = "";}

                tblNewAccDetail_Body.append('<tr>' +
                   '<td  style="text-align: center;vertical-align: middle;">' +
                   '   <div class="checkbox">' +
                   '     <input type="checkbox" id="chkTagged" class="chkTagged" ' + checkstate + ' />' +
                   '     <label for="chkTagged"></label>' +
                   '   </div>' +
                   '</td>' +
                    '<td>' + Dashboard.DocEntry + '</td>' +
                    '<td>' + Dashboard.FormatCode + '</td>' +
                    '<td>' + Dashboard.AcctName + '</td>' +
                    '</tr>');

            })

            $("#tblNewAccDetail_Header").DataTable().draw();

            $("#Modal-NewAccTagging").modal("hide");

            $("#Modal-NewAccViewDetail").modal("show");
        })
         .fail(function (stat, msg, custom) {
             toastr.warning(stat.status + ": " + custom)
         });

        
    });
    //--------------------------------
    $("#Modal-NewAccViewDetail").on("click", "#btnCloseNEwAccDetail", function () {
        $("#Modal-NewAccViewDetail").modal("hide");
        $("#Modal-NewAccTagging").modal("show");
    })
    //--------------------------------
    $("#Modal-NewAccViewDetail").on("click", "#btnCloseNEwAccDetail2", function () {
        $("#Modal-NewAccViewDetail").modal("hide");
        $("#Modal-NewAccTagging").modal("show");
    })
    //--------------------------------
    $("#Modal-NewAccViewDetail").on("click", "#btnSaveNEwAccDetail", function () {

        var whsCode = $("#txtNewWhsCode").val();
        var DocEntry = $("#txtNewDocEntry").val();
        var Desc = $("#txtNewAccDescription").val();
        var UpdateDesc = $("#chkDescControl").prop('checked');

        var NewTagged = [];
        var oTable = $('#tblNewAccDetail_Header').DataTable();
        oTable.rows().every(function (index, element) {
            var row = $(this.nodes());
            var statusElement = row.find('td:first-child input[type="checkbox"]');
            var isChecked = statusElement.prop('checked');
            var data = this.data();
            if (isChecked == true ) {
                NewTagged.push({
                    "FormatCode": data[2]
                })
            }
        })
      
        //  if (NewTagged.length > 0 )
        //{
            $.confirm({
                title: "Confirmation", 
                content: "Save/Update Tagging?",
                buttons: {
                    yes: function () {
                        $(".preloader-it").fadeIn(); //show
                        $.post("/CBS/TBDashboard/SaveNewTagging", { NewTagging: NewTagged, WhsCode: whsCode, DocEntry: DocEntry, UpdateDesc: UpdateDesc, Dscpt: Desc })
                        .done(function () {
                            $(".preloader-it").fadeOut("slow");
                            toastr.success("Record successfully Saved.", "Notification");
                            $("#Modal-NewAccViewDetail").modal("hide");
                            ViewNewAcc(whsCode)
                        })
                       .fail(function (stat, msg, custom) {
                           $(".preloader-it").fadeOut("slow");
                            toastr.warning(stat.status + ": " + custom)
                        });

                    },
                    cancel: function () { }
                }
            });
      //  }
        //else
        //{
        //    toastr.info("No Records to Save.","Notification");
        //}
    })
    //--------------------------------
    $("#Modal-NewAccViewDetail").on("change", "#chkDescControl", function () {
    
        if ($(this).prop('checked') == true)
        {
            document.getElementById("txtNewAccDescription").readOnly = false;
        }
        else if ($(this).prop('checked') == false)
        {
            document.getElementById("txtNewAccDescription").readOnly = true;
        }



    })
    //--------------------------------
    $("#Modal-NewAccTagging").on("click", "#btnInsertNewAcc", function () {

        if (getBool(AllowAdd) == false) {
            toastr.info("Access Denied!", "Notification");
            return;
        }


        var whscode = $(this).attr("data-whsCode");
        var TbType = $(this).attr("data-TBType");
        var Desc = $(this).attr("data-Desc");
        var RowNo = $(this).attr("data-RowNo");

        $("#modal-NewAccInsert #txtNewAccInsertWhs").val(whscode);
        $("#modal-NewAccInsert #txtNewAccInsertTBType").val(TbType);
        $("#modal-NewAccInsert #txtNewAccInsertRowNo").val(RowNo);
        $("#modal-NewAccInsert #NewAccInsertHeader").text("Insert (" + Desc + ")");

        $("#Modal-NewAccTagging").modal('hide');
        $("#modal-NewAccInsert").modal('show');
    })
    //--------------------------------
    $("#modal-NewAccInsert").on("click", "#btnCloseNewAccInsert", function () {
        $("#modal-NewAccInsert").modal('hide');
        $("#Modal-NewAccTagging").modal('show');
    })
    //--------------------------------
    $("#modal-NewAccInsert").on("click", "#btnCloseNewAccInsert2", function () {
        $("#modal-NewAccInsert").modal('hide');
        $("#Modal-NewAccTagging").modal('show');
        })
    //--------------------------------
    $("#modal-NewAccInsert").on("click", "#btnSaveNewAccInsert", function () {
        var Loc = $("#CboNewAccInsertLoc").val();
        var Desc = $("#txtNewAccInsertDesc").val();
        var Whs = $("#txtNewAccInsertWhs").val();
        var TbType = $("#txtNewAccInsertTBType").val();
        var RowNo = $("#txtNewAccInsertRowNo").val();


        if(Loc == "0")
        {
            toastr.info("Please select location", "Notification");
        }
        else if (Desc == "") {
            toastr.info("Description is required", "Notification");
            
        }
        else {

            $.confirm({
                title: "Confirmation",
                content: "Insert Record?",
                buttons: {
                    yes: function () {
                        $(".preloader-it").fadeIn(); //show
                        $.post("/CBS/TBDashboard/InsertNewAcc", { WhsCode: Whs, Loc: Loc, RowNo: RowNo, TBType: TbType, Desc: Desc })
                        .done(function () {
                            $(".preloader-it").fadeOut("slow");
                            toastr.success("Record successfully Saved.", "Notification");
                            $("#modal-NewAccInsert").modal("hide");
                            ViewNewAcc(Whs)
                        
                        })
                        .fail(function (stat, msg, custom) {
                               $(".preloader-it").fadeOut("slow");
                               toastr.warning(stat.status + ": " + custom)
                           });



                    },
                    cancel: function () { }
                }

            })

           
        }
        
        })
    //--------------------------------
    $("#Modal-NewAccTagging").on("click", "#btnDeleteNewAcc", function () {

        if (getBool(AllowDelete) == false) {
            toastr.info("Access Denied!", "Notification");
            return;
        }

        var whs = $(this).attr("data-whsCode");
        var DocEntry = $(this).attr("data-DocEntry");
        var TBType = $(this).attr("data-TBType");
        var RowNo = $(this).attr("data-RowNo");
        var Desc = $(this).attr("data-Desc");
         
        $.confirm({
            title: "Confirmation",
            content: "Are you sure you want to delete " + Desc + "?",
            buttons: {
                yes: function () {
                    $(".preloader-it").fadeIn(); //show
                   
                    $.post("/CBS/TBDashboard/DeleteNewAccRow", { WhsCode: whs, RowNo: RowNo, TBType: TBType, DocEntry: DocEntry })
                    .done(function () {
                        $(".preloader-it").fadeOut("slow");
                        $("#Modal-NewAccTagging").modal("hide");
                        toastr.success("Record successfully Deleted.", "Notification");
                        ViewNewAcc(whs)
                    })
                     .fail(function (stat, msg, custom) {
                         $(".preloader-it").fadeOut("slow");
                         toastr.warning(stat.status + ": " + custom)
                     })
                },
                cancel: function () { }

            }

        })

    })
});

