﻿$(document).ready(function () {

    document.getElementById('dtsd_LC').valueAsDate = new Date()
    document.getElementById('dted_LC').valueAsDate = new Date()
    document.getElementById('btnExport_LC').disabled = true;
    
    //-----------------------------------------------------------------
    var AllowAdd;
    var AllowEdit;
    var AllowDelete;
    var AllowView;
    var AllowPrint;
    var AllowImport
    var AllowExport;
    var AllowPost;
    var AllowUnpost;
    var AllowApprove;
    //-----------------------------------------------------------------
    $.ajax({
        type: "POST",
        url: "/CBS/Common/Permissions",
        success: function (data) {
            data = JSON.parse(data)
            AllowAdd = data[0]["Add"]
            AllowEdit = data[0]["Edit"];
            AllowDelete = data[0]["Delete"];
            AllowView = data[0]["View"];
            AllowPrint = data[0]["Print"];
            AllowImport = data[0]["Import"];
            AllowExport = data[0]["Export"];
            AllowPost = data[0]["Post"];
            AllowUnpost = data[0]["Unpost"];
            AllowApprove = data[0]["Approve"];
        },
        async: false

    })
    //-------------------------------

    function getBool(val) {
        return !!JSON.parse(String(val).toLowerCase());
    }
    //-----------------------------------------------------------------

    //-------------------------------------------------
    $("#btnGenerate_LC").on("click", function () {
 
        var tc = $("#txtTestCode_LC").val();
        var sd = $("#dtsd_LC").val();
        var ed = $("#dted_LC").val();
         
        if (tc == "")
            {
                toastr.info("Test Code is required", "Notification")
                return;
            }
        $(".preloader-it").fadeIn(); //show
    
        $("#tblLabCorp_header tbody tr").remove();
        $("#tblLabCorp_header").DataTable().clear().draw();
        $("#tblLabCorp_header").DataTable().destroy();
        $.post("/CBS/LabCorp/Generate", { TestCode: tc, StartDate: sd, EndDate: ed })
        .done(function (data) {
            data = JSON.parse(data);
            var tblLabCorp_Body = $("#tblLabCorp_Body");
            tblLabCorp_Body.html("");
            $(data).each(function (i,lc) {
                tblLabCorp_Body.append('<tr>' +
                        '<td>' + lc.cardcode + '</td>' +
                        '<td>' + lc.cardname + '</td>' +
                        '<td>' + moment(lc.docdate).format("YYYY-MM-DD") + '</td >' +
                        '<td>' + lc.labno + '</td>' +
                        '<td>' + lc.patient + '</td>' +
                        '<td>' + lc.whscode + '</td>' +
                        '<td>' + lc.whsname + '</td>' +
                        '<td>' + lc.itemcode + '</td>' +
                        '<td>' + lc.itemname + '</td>' +
                        '<td>' + lc.quantity + '</td>' +
                        '<td class="text-right">' + numeral(lc.price).format("0,0.00") + '</td>' +
                        '<td class="text-right">' + numeral(lc.linetotal).format("0,0.00") + '</td>' +
                    '</tr>');
            })

            document.getElementById('btnExport_LC').disabled = false;
            $("#tblLabCorp_header").DataTable({
                scrollX: true
            }).draw();
            $(".preloader-it").fadeOut("slow");
            })
            .fail(function (stat, msg, custom) {
                document.getElementById('btnExport_LC').disabled = true;
               
                $(".preloader-it").fadeOut("slow");
                toastr.info(stat.status + ": " + custom)
            })



    })
    //-------------------------------------------------
    $("#btnExport_LC").on("click", function () {

        if (getBool(AllowExport) == false) {
            toastr.info("Access Denied!", "Notification");
            return;
        }

        $.confirm({
            title: "Confirmation",
            content: "Extract Records?",
            buttons: {
                yes: function () {
                    $(".preloader-it").fadeIn(); //show
                    var Generated = [];
                    var data = $("#tblLabCorp_header").DataTable().rows().data();
                    data.each(function (value, index) {
                        Generated.push({
                            "cardcode": value[0], 
                            "cardname": value[1], 
                            "docdate": value[2], 
                            "labno": value[3], 
                            "patient": value[4], 
                            "whscode": value[5], 
                            "whsname": value[6], 
                            "itemcode": value[7], 
                            "itemname": value[8], 
                            "quantity": value[9], 
                            "price": numeral(value[10]).value(),
                            "linetotal": numeral(value[11]).value()
                        })

                    })


                    $.post("/CBS/LabCorp/Extract", { Data: Generated})
                     .done(function (data) {
                         window.location = '/CBS/Asset/Download?fileGuid=' + data.FileGuid + '&filename=' + data.FileName;
                         $(".preloader-it").fadeOut("slow");
                         toastr.success("Record successfully Exported.", "Notification");
                     })
                     .fail(function (stat, msg, custom) {
                         $(".preloader-it").fadeOut("slow");
                         toastr.info(stat.status + ": " + custom)
                     })

                    
                },
                cancel: function () { }

            }
        })

    })





})