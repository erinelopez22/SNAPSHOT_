﻿$(document).ready(function () {
    document.getElementById('btnExport_Emplist').disabled = true;

    //-----------------------------------------------------------------
    var AllowAdd;
    var AllowEdit;
    var AllowDelete;
    var AllowView;
    var AllowPrint;
    var AllowImport
    var AllowExport;
    var AllowPost;
    var AllowUnpost;
    var AllowApprove;
    //-----------------------------------------------------------------
    $.ajax({
        type: "POST",
        url: "/CBS/Common/Permissions",
        success: function (data) {
            data = JSON.parse(data)
            AllowAdd = data[0]["Add"]
            AllowEdit = data[0]["Edit"];
            AllowDelete = data[0]["Delete"];
            AllowView = data[0]["View"];
            AllowPrint = data[0]["Print"];
            AllowImport = data[0]["Import"];
            AllowExport = data[0]["Export"];
            AllowPost = data[0]["Post"];
            AllowUnpost = data[0]["Unpost"];
            AllowApprove = data[0]["Approve"];
        },
        async: false

    })
    //-------------------------------

    function getBool(val) {
        return !!JSON.parse(String(val).toLowerCase());
    }
    //-----------------------------------------------------------------


    function GetEmplist() {
        $(".preloader-it").fadeIn(); //show
        $("#tblEmplist_Header tbody tr").remove();
        $("#tblEmplist_Header").DataTable().clear().draw();
        $("#tblEmplist_Header").DataTable().destroy();

        $.post("/CBS/Emplist/EmplistData")
            .done(function (data) {
                document.getElementById('btnExport_Emplist').disabled = false;
                data = JSON.parse(data);
                var tblEmplist_Body = $("#tblEmplist_Body");
                tblEmplist_Body.html("");
                
                $(data).each(function (i, Emplist) {
                    tblEmplist_Body.append('<tr>' +
                        '<td>' + Emplist.EmpCode    + '</td>' +
                        '<td>' + Emplist.EmpName    + '</td>' +
                        '<td>' + Emplist.Position   + '</td>' +
                        '<td>' + Emplist.BranchCode + '</td>' +
                        '<td>' + Emplist.DeptName   + '</td>' +
                        '<td>' + Emplist.SecName    + '</td>' +
                        '<td>' + moment(Emplist.DateHired).format("YYYY-MM-DD")  + '</td>' +
                        '<td>' + moment(Emplist.BirthDate).format("YYYY-MM-DD")  + '</td>' +
                        '<td>' + Emplist.Gender + '</td>' +
                        '<td>' + Emplist.CivilStat + '</td>' +
                        '</tr>')
                        });
               
                
                $("#tblEmplist_Header").DataTable({
                    "scrollX": true
                }).draw();
                
                $(".preloader-it").fadeOut("slow");
            })
            .fail(function (stat, msg, custom) {
                document.getElementById('btnExport_Emplist').disabled = true;
                $(".preloader-it").fadeOut("slow");
                toastr.warning(stat.status + ": " + custom)
            });
    }
    //------------------------------------------------------
    $("#btnGenerate_Emplist").on("click", function () {
        GetEmplist();
    })
    //------------------------------------------------------
    $("#btnExport_Emplist").on("click", function () {

        if (getBool(AllowExport) == false) {
            toastr.info("Access Denied!", "Notification");
            return;
        }


        $.confirm({
            title: "Confirmation",
            content: "Export Data?",
            buttons: {
                yes: function () {
                    $(".preloader-it").fadeIn(); //show
                    var data = [];
                    var tblEmplist_Header = $("#tblEmplist_Header").DataTable().rows().data();
                    tblEmplist_Header.each(function (value, index) {
                        data.push({
                            "EmpCode": value[0],
                            "EmpName": value[1],
                            "Position": value[2],
                            "BranchCode": value[3],
                            "DeptName": value[4],
                            "SecName": value[5],
                            "DateHired": value[6],
                            "BirthDate": value[7],
                            "Gender": value[8],
                            "CivilStat": value[9]
                        })
                    })


                    $.post("/CBS/Emplist/ExtractData", { Emplist: data })
                        .done(function (data) {
                            window.location = '/CBS/TrialBalance/Download?fileGuid=' + data.FileGuid + '&filename=' + data.FileName;
                            $(".preloader-it").fadeOut("slow");
                            toastr.success("Record successfully Exported.", "Notification");



                        })
                        .fail(function (stat, msg, custom) {
                            $(".preloader-it").fadeOut("slow");
                            toastr.warning(stat.status + ": " + custom)
                        });



                  
                },
                cancel: function () { }
            }

        })

    })
})