﻿$(document).ready(function () {
    document.getElementById('dtsd').valueAsDate = new Date()
    document.getElementById('dted').valueAsDate = new Date()
    document.getElementById('btnExport').disabled = true;


    //-----------------------------------------------------------------
    var AllowAdd;
    var AllowEdit;
    var AllowDelete;
    var AllowView;
    var AllowPrint;
    var AllowImport
    var AllowExport;
    var AllowPost;
    var AllowUnpost;
    var AllowApprove;
    //-----------------------------------------------------------------
    $.ajax({
        type: "POST",
        url: "/CBS/Common/Permissions",
        success: function (data) {
            data = JSON.parse(data)
            AllowAdd = data[0]["Add"]
            AllowEdit = data[0]["Edit"];
            AllowDelete = data[0]["Delete"];
            AllowView = data[0]["View"];
            AllowPrint = data[0]["Print"];
            AllowImport = data[0]["Import"];
            AllowExport = data[0]["Export"];
            AllowPost = data[0]["Post"];
            AllowUnpost = data[0]["Unpost"];
            AllowApprove = data[0]["Approve"];
        },
        async: false

    })
    //-------------------------------

    function getBool(val) {
        return !!JSON.parse(String(val).toLowerCase());
    }
    //-----------------------------------------------------------------
        
    //------------------------------------------------
    $("#btnGenerate").on("click", function () {
        $(".preloader-it").fadeIn(); //show
        var SD = $("#dtsd").val();
        var ED = $("#dted").val();
        
        $("#tblSalDetail_Header tbody tr").remove();
        $("#tblSalDetail_Header").DataTable().clear().draw();
        $("#tblSalDetail_Header").DataTable().destroy();

        $.post("/CBS/Salaries/GenerateDetail", { SD: SD, ED: ED })
            .done(function (data) {
                data = JSON.parse(data);
                var tblSalDetail_Body = $("#tblSalDetail_Body");
                tblSalDetail_Body.html("");

                $(data).each(function (i, Detail) {
                    tblSalDetail_Body.append('<tr>'+
                        '<td>' + Detail.TransID +'</td>'+
                        '<td>' + Detail.BranchCode + '</td>' +
                        '<td>' + Detail.FormatCode + '</td>' +
                        '<td>' + Detail.AccountName + '</td>' +
                        '<td>' + Detail.LineMemo + '</td>' +
                        '<td>' + moment(Detail.RefDate).format("YYYY-MM-DD") + '</td >' +
                        '<td>' + Detail.BaseRef + '</td>' +
                        '<td class="text-right">' + numeral(Detail.Debit).format("0,0.00") + '</td>' +
                        '<td class="text-right">' + numeral(Detail.Credit).format("0,0.00") + '</td>' +
                        '</tr>')
                    
                })

                if (data.length > 0)
                    {
                        document.getElementById('btnExport').disabled = false;
                    }
                
                $(".preloader-it").fadeOut("slow");
                $("#tblSalDetail_Header").DataTable({
                    "scrollX": true
                }).draw();
            })
                 .fail(function (stat, msg, custom) {
                     document.getElementById('btnExport').disabled = true;
                     $(".preloader-it").fadeOut("slow");
                     toastr.warning(stat.status + ": " + custom)
                 });

    })
    //------------------------------------------------

    $("#btnExport").on("click", function () {

        if (getBool(AllowExport) == false) {
            toastr.info("Access Denied!", "Notification");
            return;
        }


        $.confirm({
            title: "Confirmation",
            content: "Extract Record/s to Excel?",
            buttons: {
                yes: function () {
                    $(".preloader-it").fadeIn(); //show
                    var SD = $("#dtsd").val();
                    var ED = $("#dted").val();
                    var data = [];
                    var tblSalDetail_Header = $("#tblSalDetail_Header").DataTable().rows().data();
                    tblSalDetail_Header.each(function (value, index) {
                        data.push({
                            "TransID": value[0],
                            "BranchCode": value[1],
                            "FormatCode": value[2],
                            "AccountName": value[3],
                            "LineMemo": value[4],
                            "RefDate": value[5],
                            "BaseRef": value[6],
                            "Debit": numeral(value[7]).value(),
                            "Credit": numeral(value[8]).value()
                        })
                    })
                    

                    $.post("/CBS/Salaries/ExtractDetail", { Details: data, From: SD, To: ED })
                    .done(function (data) {
                        window.location = '/CBS/TrialBalance/Download?fileGuid=' + data.FileGuid + '&filename=' + data.FileName;
                        $(".preloader-it").fadeOut("slow");
                        toastr.success("Record successfully Exported.", "Notification");
                    })
                     .fail(function (stat, msg, custom) {
                      $(".preloader-it").fadeOut("slow");
                       toastr.warning(stat.status + ": " + custom)
                         });

                },
                cancel: function () { }
            }


        })


    })


});