﻿$(document).ready(function () {

    document.getElementById('dtsd_VL').valueAsDate = new Date()
    document.getElementById('dted_VL').valueAsDate = new Date()
    document.getElementById('btnExport_VL').disabled = true;

    //-----------------------------------------------------------------
    var AllowAdd;
    var AllowEdit;
    var AllowDelete;
    var AllowView;
    var AllowPrint;
    var AllowImport
    var AllowExport;
    var AllowPost;
    var AllowUnpost;
    var AllowApprove;
    //-----------------------------------------------------------------
    $.ajax({
        type: "POST",
        url: "/CBS/Common/Permissions",
        success: function (data) {
            data = JSON.parse(data)
            AllowAdd = data[0]["Add"]
            AllowEdit = data[0]["Edit"];
            AllowDelete = data[0]["Delete"];
            AllowView = data[0]["View"];
            AllowPrint = data[0]["Print"];
            AllowImport = data[0]["Import"];
            AllowExport = data[0]["Export"];
            AllowPost = data[0]["Post"];
            AllowUnpost = data[0]["Unpost"];
            AllowApprove = data[0]["Approve"];
        },
        async: false

    })
    //-------------------------------

    function getBool(val) {
        return !!JSON.parse(String(val).toLowerCase());
    }
    //-----------------------------------------------------------------
    
    $.post("/CBS/Common/GetBranch", function (data) {
        data = JSON.parse(data);
        var cboBranch = $("#modGenVList #cboBranch_VL");
        cboBranch.html("");
        $(data).each(function (index, br) {
            cboBranch.append('<option value="' + br.Whscode + '">' + br.whsName + '</option>');
        });
    });
    //-------------------------------------------------

    $("#modGenVList").on("click", "#btnGenerate_VLmod", function () {
        $(".preloader-it").fadeIn(); //show
        var brachCode = $("#cboBranch_VL").val();
        var Sdate = $("#dtsd_VL").val();
        var Edate = $("#dted_VL").val();
        
        $("#tblVL_Header tbody tr").remove();
        $("#tblVL_Header").DataTable().clear().draw();
        $("#tblVL_Header").DataTable().destroy();
        
        $.post("/CBS/VoucherList/Generate", { whscode: brachCode, StartDate: Sdate, EndDate: Edate })
        .done(function (data) {
            data = JSON.parse(data);
            var tblVL_Body = $("#tblVL_Body");
            tblVL_Body.html('');
            $(data).each(function (i, vl) {
                tblVL_Body.append('<tr>' +
                    '<td>' + vl.DocNum  + '</td>' + 
                    '<td>' + moment(vl.DocDate).format("YYYY-MM-DD") + '</td >' +
                    '<td>' + vl.CardName + '</td>' +
                    '<td>' + vl.Comments + '</td>' +
                    '<td class="text-right">' + numeral(vl.DocTotal).format("0,0.00") + '</td>' +
                    '<td>' + vl.ChkNum + '</td>' +
                    '<td>' + vl.VoucherNo + '</td>' +
                    '</tr>');
                })

            $("#tblVL_Header").DataTable({
                scrollX: true
            }).draw();

            document.getElementById('btnExport_VL').disabled = false;
            $("#modGenVList").modal('hide');
            $(".preloader-it").fadeOut("slow");
        })
        .fail(function (stat, msg, custom) {
            document.getElementById('btnExport_VL').disabled = true;
            $(".preloader-it").fadeOut("slow");
            toastr.info(stat.status + ": " + custom)
        })
    })

    //-------------------------------------------------
    $("#btnExport_VL").on("click", function () {

        if (getBool(AllowExport) == false) {
            toastr.info("Access Denied!", "Notification");
            return;
        }

        $.confirm({
            title: "Confirmation",
            content: "Extract Record/s?",
            buttons: {
                yes: function () {
                    $(".preloader-it").fadeIn(); //show
                    var Generated = [];
                    var data = $("#tblVL_Header").DataTable().rows().data();
                    data.each(function (value, index) {
                        Generated.push({
                            "DocNum": value[0],
                            "DocDate": value[1],
                            "CardName": value[2],
                            "Comments": value[3],
                            "DocTotal": numeral(value[4]).value(),
                            "ChkNum": value[5],
                            "VoucherNo": value[6]
                        })
                    })


                    $.post("/CBS/VoucherList/Extract", { Data: Generated })
                        .done(function (data) {
                            window.location = '/CBS/Asset/Download?fileGuid=' + data.FileGuid + '&filename=' + data.FileName;
                            $(".preloader-it").fadeOut("slow");
                            toastr.success("Record successfully Exported.", "Notification");
                        })
                         .fail(function (stat, msg, custom) {
                             document.getElementById('btnExport_VL').disabled = true;
                             $(".preloader-it").fadeOut("slow");
                             toastr.info(stat.status + ": " + custom)
                         })

                },
                cancel: function () { }
            }
        })


    })
})