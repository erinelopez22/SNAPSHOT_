﻿$(document).ready(function () {
    document.getElementById('dtsd_GL').valueAsDate = new Date()
    document.getElementById('dted_GL').valueAsDate = new Date()
    document.getElementById('btnExport_GL').disabled = true;

    //-----------------------------------------------------------------
    var AllowAdd;
    var AllowEdit;
    var AllowDelete;
    var AllowView;
    var AllowPrint;
    var AllowImport
    var AllowExport;
    var AllowPost;
    var AllowUnpost;
    var AllowApprove;
    //-----------------------------------------------------------------
    $.ajax({
        type: "POST",
        url: "/CBS/Common/Permissions",
        success: function (data) {
            data = JSON.parse(data)
            AllowAdd = data[0]["Add"]
            AllowEdit = data[0]["Edit"];
            AllowDelete = data[0]["Delete"];
            AllowView = data[0]["View"];
            AllowPrint = data[0]["Print"];
            AllowImport = data[0]["Import"];
            AllowExport = data[0]["Export"];
            AllowPost = data[0]["Post"];
            AllowUnpost = data[0]["Unpost"];
            AllowApprove = data[0]["Approve"];
        },
        async: false

    })
    //-------------------------------

    function getBool(val) {
        return !!JSON.parse(String(val).toLowerCase());
    }
    //-----------------------------------------------------------------
        
    $("#btnGenerate_GL").on("click", function () {

        var gl = $("#txtGLCode_GL").val();
        var sd = $("#dtsd_GL").val();
        var ed = $("#dted_GL").val();


        if (gl == "") {
            toastr.info("GL Code is required", "Notification")
            return;
        }

        $(".preloader-it").fadeIn(); //show

        $("#tblGLTransac_header tbody tr").remove();
        $("#tblGLTransac_header").DataTable().clear().draw();
        $("#tblGLTransac_header").DataTable().destroy();
        $.post("/CBS/GLTransac/Generate", { GLCode: gl, StartDate: sd, EndDate: ed })
             .done(function (data) {
                   data = JSON.parse(data);
                   var tblGLTransac_Body = $("#tblGLTransac_Body");
                   tblGLTransac_Body.html("");
                 $(data).each(function(i, gl){
                     tblGLTransac_Body.append('<tr>' +
                     '<td>'+gl.FormatCode+'</td>' +
                     '<td>'+gl.AcctName+'</td>' +
                     '<td>' + moment(gl.RefDate).format("YYYY-MM-DD") + '</td >' +
                     '<td>'+gl.TransId+'</td>' +
                     '<td>'+gl.BaseRef+'</td>' +
                     '<td>'+gl.LineMemo+'</td>' +
                     '<td class="text-right">' + numeral(gl.Debit).format("0,0.00") + '</td>' +
                     '<td class="text-right">' + numeral(gl.Credit).format("0,0.00") + '</td>' +
                     '<td>'+ gl.Branch + '</td>' +
                     '</tr>')
                  })

                 document.getElementById('btnExport_GL').disabled = false;
                 $("#tblGLTransac_header").DataTable({
                     scrollX: true
                 }).draw();
                 $(".preloader-it").fadeOut("slow");


                })
            .fail(function (stat, msg, custom) {
                document.getElementById('btnExport_GL').disabled = true;
                $(".preloader-it").fadeOut("slow");
                toastr.info(stat.status + ": " + custom)
            })


    })

    //-----------------------------------------------------------------
    $("#btnExport_GL").on("click", function () {

        if (getBool(AllowExport) == false) {
            toastr.info("Access Denied!", "Notification");
            return;
        }

        $.confirm({
            title: "Confirmation",
            content: "Extract Records?",
            buttons: {
                yes: function () {
                    $(".preloader-it").fadeIn(); //show
                    var Generated = [];
                    var data = $("#tblGLTransac_header").DataTable().rows().data();
                    data.each(function (value, index) {
                        Generated.push({
                            "FormatCode": value[0],
                            "AcctName": value[1],
                            "RefDate": value[2],
                            "TransId": value[3],
                            "BaseRef": value[4],
                            "LineMemo": value[5],
                            "Debit": numeral(value[6]).value(),
                            "Credit": numeral(value[7]).value(),
                            "Branch": value[8]
                        })

                    })
                    

                    $.post("/CBS/GLTransac/Extract", { Data: Generated })
                    .done(function (data) {
                        window.location = '/CBS/Asset/Download?fileGuid=' + data.FileGuid + '&filename=' + data.FileName;
                        $(".preloader-it").fadeOut("slow");
                        toastr.success("Record successfully Exported.", "Notification");
                    })
                    .fail(function (stat, msg, custom) {
                        $(".preloader-it").fadeOut("slow");
                        toastr.info(stat.status + ": " + custom)
                    })





                },
                cancel: function () { }
            }
        })

    })
})