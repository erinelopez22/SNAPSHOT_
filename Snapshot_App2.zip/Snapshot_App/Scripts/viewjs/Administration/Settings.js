﻿$(document).ready(function () {

    var AllowAdd;
    var AllowEdit;
    var AllowDelete;
    var AllowView;
    var AllowPrint;
    var AllowImport
    var AllowExport;
    var AllowPost;
    var AllowUnpost;
    var AllowApprove;

    $.ajax({
        type: "POST",
        url: "/CBS/Common/Permissions",
        success: function (data) {
            data = JSON.parse(data)
            AllowAdd = data[0]["Add"]
            AllowEdit = data[0]["Edit"];
            AllowDelete = data[0]["Delete"];
            AllowView = data[0]["View"];
            AllowPrint = data[0]["Print"];
            AllowImport = data[0]["Import"];
            AllowExport = data[0]["Export"];
            AllowPost = data[0]["Post"];
            AllowUnpost = data[0]["Unpost"];
            AllowApprove = data[0]["Approve"];
        },
        async: false

    })
    //-------------------------------

    function getBool(val) {
        return !!JSON.parse(String(val).toLowerCase());
    }
    //-----------------------------------------------------------------
    function Generate() {
      //  $(".preloader-it").fadeIn(); //show
        $("#tblSettings_header tbody tr").remove();
        $("#tblSettings_header").DataTable().clear().draw();
        $("#tblSettings_header").DataTable().destroy();
        $.post("/CBS/Settings/LoadSettings")
            .done(function (data) {
                data = JSON.parse(data);
                var tblSettings_Body = $("#tblSettings_Body");
                tblSettings_Body.html("");
                var isActive = "";
                $(data).each(function (i, settings) {

                    if (settings.IsActive == false) { isActive = "hidden"; } else { isActive = ""; }


                    tblSettings_Body.append('<tr>' +
                        '<td>' + settings.SettingsID + '</td>' +
                        '<td>' + settings.Key + '</td>' +
                        '<td>' + settings.Value + '</td>' +
                        '<td style="text-align: center;vertical-align: middle;"><span style="font- size:100px;"' + isActive + '>&#10004;</span></td>' +
                        '<td>' + settings.Remarks + '</td>' +
                        '<td align="center">' +
                      ' <div class="btn-group btn-group-rounded" role="group"> ' +
                          '  <button id="btnEdit" type="button" class="btn btn-outline-primary btn-xs"  title="click to Edit" ' +
                               'data-SettingsID="' + settings.SettingsID + '"' +
                               'data-Key="' + settings.Key + '"' +
                               'data-Value="' + settings.Value + '"' +
                               'data-IsActive="' + settings.IsActive + '"' +
                               'data-Remarks="' + settings.Remarks + '"' +
                                '> ' +
                          '     <i class="fa fa-edit mr-5"></i> Edit ' +
                          '  </button> ' +
                          '  <button id="btnDelete" type="button" class="btn btn-outline-primary btn-xs" title="click to Delete" ' +
                                     'data-SettingsID="' + settings.SettingsID + '"' +
                                '> ' +
                          '     <i class="fa fa-trash mr-5"></i> Delete ' +
                          '  </button> ' +
                      '  </div> ' +
                       '</td>' +
                     '</tr>')
                });
                $("#tblSettings_header").DataTable().draw();
                $(".preloader-it").fadeOut("slow");

              })
              .fail(function (stat, msg, custom) {
                 
                  $(".preloader-it").fadeOut("slow");
                  toastr.warning(stat.status + ": " + custom)
              });
        }

    Generate()
    //-------------------------
    $("#btnNew").on("click", function () {

        if (getBool(AllowAdd) == false) {
            toastr.info("Access Denied!", "Notification");
            return;
        }

        $("#modDetail").modal("show");
        $("#SettingID").val("---");
        $("#Key").val("");
        $("#settingValue").val("");
        $("#Remarks").val("");
        $("#ChkActive").prop('checked', true);
    })
    //-------------------------
    $("#tblSettings_header").on("click", "#btnEdit", function () {

        if (getBool(AllowEdit) == false) {
            toastr.info("Access Denied!", "Notification");
            return;
        }

        $("#modDetail").modal("show");
        $("#SettingID").val($(this).attr("data-SettingsID"));
        $("#Key").val($(this).attr("data-Key"));
        $("#settingValue").val($(this).attr("data-Value"));
        $("#Remarks").val($(this).attr("data-Remarks"));
        $("#ChkActive").prop('checked', true);
    })

    //-------------------------

    $("#tblSettings_header").on("click", "#btnDelete", function () {

        if (getBool(AllowDelete) == false) {
            toastr.info("Access Denied!", "Notification");
            return;
        }


        var SettingID = $(this).attr("data-SettingsID");
        $.confirm({
            title: "Confirmation",
            content: "Delete record?",
            buttons: {
                yes: function () {
                    $(".preloader-it").fadeIn(); //show
                    $.post("/CBS/Settings/DeleteSettingbyID", { SettingID: SettingID })
                    .done(function () {
                        $(".preloader-it").fadeOut("slow");
                        toastr.success("Record successfully deleted.")
                        Generate()
                    })
                     .fail(function (stat, msg, custom) {

                         $(".preloader-it").fadeOut("slow");
                         toastr.warning(stat.status + ": " + custom)
                     });
                },
                cancel: function () { }
            }

        })


    })

    //-------------------------

    $("#modDetail").on("click", "#btnSave", function () {
        var settingID = $("#SettingID").val();
        var key = $("#Key").val();
        var settingvalue = $("#settingValue").val();
        var remakrs = $("#Remarks").val();
        var active = document.getElementById("ChkActive").checked;

        active = 0;
        if (document.getElementById("ChkActive").checked == true)
        {
            active = 1;
        }

        console.log(settingID)
        console.log(key)
        console.log(settingvalue)
        console.log(remakrs)
        console.log(active)
        

        var msg = "";
        var aftersaved = "";
        
        if (settingID == "---")
            {
                msg = "Save Setting?"
                aftersaved = "Record successfully Saved.";
                
            }
        else
            {
                msg = "Update Setting";
                aftersaved = "Record successfully Updated.";
            }

        $.confirm({
            title: "Confirmation",
            content: msg,
            buttons: {
                yes: function () {
                    $(".preloader-it").fadeIn(); 
                    $("#modDetail").modal("hide");
                    if (settingID == "---")
                        {  
                            $.post("/CBS/Settings/InsertNewSettings", { key: key, value: settingvalue, remarks: remakrs })
                                 .done(function () {
                                     $(".preloader-it").fadeOut("slow");
                                     Generate()
                                     toastr.success(aftersaved)
                                    })
                                 .fail(function (stat, msg, custom) {
                                     $(".preloader-it").fadeOut("slow");
                                     toastr.warning(stat.status + ": " + custom)
                                   });
                        }
                    else
                    {
                        $.post("/CBS/Settings/UpdateSettingbyID", { key: key, value: settingvalue, remarks: remakrs, isActive: active, SettingID: settingID })
                            .done(function () {
                                $(".preloader-it").fadeOut("slow");
                                Generate()
                                toastr.success(aftersaved)
                            })
                                 .fail(function (stat, msg, custom) {
                                     $(".preloader-it").fadeOut("slow");
                                     toastr.warning(stat.status + ": " + custom)
                                 });


                        }
                    
                   
                },
                cancel: function () { }

            }
        })

       


    })
})

