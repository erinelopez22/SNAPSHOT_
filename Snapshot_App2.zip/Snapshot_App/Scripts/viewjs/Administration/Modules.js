﻿$(document).ready(function () {
    var moduleid = 0;

    var AllowAdd;
    var AllowEdit;
    var AllowDelete;
    var AllowView;
    var AllowPrint;
    var AllowImport
    var AllowExport;
    var AllowPost;
    var AllowUnpost;
    var AllowApprove;

    $.ajax({
        type: "POST",
        url: "/CBS/Common/Permissions",
        success: function (data) {
            data = JSON.parse(data)
            AllowAdd = data[0]["Add"]
            AllowEdit = data[0]["Edit"];
            AllowDelete = data[0]["Delete"];
            AllowView = data[0]["View"];
            AllowPrint = data[0]["Print"];
            AllowImport = data[0]["Import"];
            AllowExport = data[0]["Export"];
            AllowPost = data[0]["Post"];
            AllowUnpost = data[0]["Unpost"];
            AllowApprove = data[0]["Approve"];
        },
        async: false

    })
    //-----------------------------------------------------------------------
    function getBool(val) {
        return !!JSON.parse(String(val).toLowerCase());
    }
    //-----------------------------------------------------------------------
    $.post("/CBS/UserModule/GetMenu", function (data) {
        data = JSON.parse(data);
        var cboMenu = $("#mod-NewModule #cboMenu");
        cboMenu.html("");
        $(data).each(function (index, br) {
            cboMenu.append('<option value="' + br.MenuID + '">' + br.Menu + '</option>');
        });
    });
    //-----------------------------------------------------------------------
    function LoadModules() {

        $("#tblModules_Header tbody tr").remove();
        $("#tblModules_Header").DataTable().clear().draw();
        $("#tblModules_Header").DataTable().destroy();
        $.post("/CBS/UserModule/GetModules")
        .done(function (data) {
            data = JSON.parse(data);
            var tblModules_Body = $("#tblModules_Body");
            tblModules_Body.html("");

            $(data).each(function (i, Modules) {

                var checkst = "";
                if (Modules.Active == 1)
                    {
                        checkst = "checked"
                    }

                tblModules_Body.append('<tr>' +
                    '<td>' + Modules.ModuleID + '</td>' +
                    '<td>' + Modules.Menu + '</td>' +
                    '<td>' + Modules.ModuleName + '</td>' +
                    '<td>' + Modules.HtmlID + '</td>' +
                    '<td>' + Modules.HtmlTabID + '</td>' +
                     '<td  style="text-align: center;vertical-align: middle;">' +
                   '   <div class="checkbox" >' +
                   '     <input type="checkbox" disabled class="chkstat_modules"' + checkst + '/>' +
                   '     <label for="checkbox" ></label>' +
                   '   </div>' +
                   '</td>' +
                    '<td align="right">' +
                      ' <div class="btn-group btn-group-rounded" role="group"> ' +
                          '<button id="btnEditModule" type="button" class="btn btn-outline-primary btn-xs"  title="click to Edit"' +
                                     'data-ModuleID= "' + Modules.ModuleID + '"' +
                                     'data-Menu ="' + Modules.Menu + '"' +
                                     'data-ModuleName ="' + Modules.ModuleName + '"' +
                                     'data-HtmlID ="' + Modules.HtmlID + '"' +
                                     'data-HtmlTabID ="' + Modules.HtmlTabID + '"' +
                                    '><i class="fa fa-edit mr-5"></i> Edit  </button> ' +
                          '<button id="btnDeleteModule" type="button" class="btn btn-outline-primary btn-xs" title="click to Delete"'+
                                    'data-ModuleID= "' + Modules.ModuleID + '"' +
                                    '> <i class="fa fa-trash mr-5"></i> Delete </button> ' +
                      '  </div> ' +
                       '</td>' +
                    '</tr>')
                

            });


            $("#tblModules_Header").DataTable().draw();

        })
           .fail(function (stat, msg, custom) {
               toastr.warning(stat.status + ": " + custom)

           });


    }
    //-----------------------------------------------------------------------
    LoadModules();
    //-----------------------------------------------------------------------
    $("#btnNew").on("click", function () {

        if (getBool(AllowAdd) == false) {
            toastr.info("Access Denied!", "Notification");
            return;
        }

        
        moduleid = 0;
         $("#mod-NewModule").modal("show");
         $("#txtModuleName").val("");
         $("#txtHtmlID").val("");
         $("#txtHtmlTabID").val("");
         $("#chkModuleStatus").prop("checked", true );
    })
    //-----------------------------------------------------------------------
    $("#mod-NewModule").on("click", "#btnSaveModule", function () {
   
        var menuID = $("#cboMenu").val();
        var modulename = $("#txtModuleName").val();
        var HtmlID = $("#txtHtmlID").val();
        var HtmlTabID = $("#txtHtmlTabID").val();
        var active = $("#chkModuleStatus").prop("checked");
        var msg = "";
       
        console.log(moduleid)
        console.log(menuID)

        if (moduleid == 0)
        {
            var mode = "SaveModule";
            moduleid = 0;
            msg = "Record Successsfully Saved";
        }
        else
        {
            var mode = "UpdateModule";
            msg = "Record Successsfully Updated";
        }
      
      
       

        if(modulename == "")
            {
                toastr.info("Module name is requried", "Notification");
            }
        else if(HtmlID == "")
            {
                toastr.info("Html ID is requried", "Notification");
            }
        else
            {
                $.confirm({
                    title: "Confirmation",
                    content: "Save Record?",
                    buttons: {
                        yes: function () {

                            
                            $.post("/CBS/UserModule/Upsert", { Menu: menuID, Modulename: modulename, htmlid: HtmlID, htmltabid: HtmlTabID, ModuleID: moduleid, Mode: mode, Active: active })
                             .done(function (data) {
                                 data = JSON.parse(data);
                                 $("#mod-NewModule").modal("hide");
                                 toastr.success(msg, "Notification");
                                 LoadModules();
                                 moduleid = 0;
                             })

                            .fail(function (stat, msg, custom) {
                                toastr.warning(stat.status + ": " + custom)
                            })

                         
                        },
                        cancel: function () { }
                    }
                })
            }
    })
    //-----------------------------------------------------------------------
    $("#tblModules_Header").on("click", "#btnEditModule", function () {

        if (getBool(AllowEdit) == false) {
            toastr.info("Access Denied!", "Notification");
            return;
        }


        moduleid = $(this).attr("data-ModuleID");
        var menu = $(this).attr("data-Menu");
        var ModuleName = $(this).attr("data-ModuleName");
        var HtmlID = $(this).attr("data-HtmlID");
        var HtmlTabID = $(this).attr("data-HtmlTabID");
        
       
        $("#cboMenu").selectedIndex = 0;

        console.log(menu);
        
        var dd = document.getElementById('cboMenu');
        for (var i = 0; i < dd.options.length; i++) {
            if (dd.options[i].text === menu) {
                console.log(i)
                dd.selectedIndex = i;
                break;
            }
        }
        
        $("#txtModuleName").val(ModuleName);
        $("#txtHtmlID").val(HtmlID);
        $("#txtHtmlTabID").val(HtmlTabID);
        $("#chkModuleStatus").prop("checked", true);
        
        $("#mod-NewModule").modal("show");
    });
    //-----------------------------------------------------------------------
    $("#tblModules_Header").on("click", "#btnDeleteModule", function () {

        if (getBool(AllowDelete) == false) {
            toastr.info("Access Denied!", "Notification");
            return;
        }

        var Moduleid = $(this).attr("data-ModuleID"); 
    
        $.confirm({ 
            title: "Confirmation",
            content: "Are you sure you want to delete this module?",
            buttons: {
                yes: function () {
                    $.post("/CBS/UserModule/Delete", { ModuleID: Moduleid })
                    .done(function (data) {
                        data = JSON.parse(data);
                        $("#mod-NewModule").modal("hide");
                        toastr.success("Record Successfully Deleted", "Notification");
                        LoadModules();

                    })
                      .fail(function (stat, msg, custom) {
                          toastr.warning(stat.status + ": " + custom)
                      })
                },
                cancel: function () { }
            }

        })

    })
    //-----------------------------------------------------------------------

})