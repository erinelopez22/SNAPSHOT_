﻿$(document).ready(function () {
    var SaveMode = "";
    var UserTypeID_Global = "";

    //-----------------------------------------------------------------------------
    var AllowAdd;
    var AllowEdit;
    var AllowDelete;
    var AllowView;
    var AllowPrint;
    var AllowImport
    var AllowExport;
    var AllowPost;
    var AllowUnpost;
    var AllowApprove;
    //-----------------------------------------------------------------------------
    $.ajax({
        type: "POST",
        url: "/CBS/Common/Permissions",
        success: function (data) {
            data = JSON.parse(data)
            AllowAdd = data[0]["Add"]
            AllowEdit = data[0]["Edit"];
            AllowDelete = data[0]["Delete"];
            AllowView = data[0]["View"];
            AllowPrint = data[0]["Print"];
            AllowImport = data[0]["Import"];
            AllowExport = data[0]["Export"];
            AllowPost = data[0]["Post"];
            AllowUnpost = data[0]["Unpost"];
            AllowApprove = data[0]["Approve"];
        },
        async: false

    })
    

    function getBool(val) {
        return !!JSON.parse(String(val).toLowerCase());
    }
    //-----------------------------------------------------------------------------
    function LoadList() {

        $("#tblUserType_Header tbody tr").remove();
        $("#tblUserType_Header").DataTable().clear().draw();
        $("#tblUserType_Header").DataTable().destroy();
        $.post("/CBS/UserModule/GetUserType")
        .done(function (data) {
            data = JSON.parse(data);
            var tblUserType_Body = $("#tblUserType_Body");
            tblUserType_Body.html("");
                var AllowAdd = "";
                var AllowEdit = "";
                var AllowDelete = "";
                var AllowView = "";
                var AllowPrint = "";
                var AllowImport = "";
                var AllowExport = "";
                var AllowPost = "";
                var AllowUnpost = "";
                var AllowApprove = "";
                var IsActive = "";

           

            $(data).each(function (i, UsersInfo) {
                
                if (UsersInfo.Add == "False") { AllowAdd = "hidden"; } else { AllowAdd = ""; }
                if (UsersInfo.Edit == "False") { AllowEdit = "hidden"; } else { AllowEdit = ""; }
                if (UsersInfo.Delete == "False") { AllowDelete = "hidden"; } else { AllowDelete = ""; }
                if (UsersInfo.View == "False") { AllowView = "hidden"; } else { AllowView = ""; }
                if (UsersInfo.Print == "False") { AllowPrint = "hidden"; } else { AllowPrint = ""; }
                if (UsersInfo.Import == "False") { AllowImport = "hidden"; } else { AllowImport = ""; }
                if (UsersInfo.Export == "False") { AllowExport = "hidden"; } else { AllowExport = ""; }
                if (UsersInfo.Post == "False") { AllowPost = "hidden"; } else { AllowPost = ""; }
                if (UsersInfo.Unpost == "False") { AllowUnpost = "hidden"; } else { AllowUnpost = ""; }
                if (UsersInfo.Approve == "False") { AllowApprove = "hidden"; } else { AllowApprove = ""; }
                if (UsersInfo.Active == "False") { IsActive = "hidden"; } else { IsActive = ""; }

             
              

                tblUserType_Body.append('<tr>' +
                    '<td>' + UsersInfo.UserTypeID + '</td>' +
                    '<td>' + UsersInfo.UserType + '</td>' +
                    '<td  style="text-align: center;vertical-align: middle;" ><span style="font- size:100px;" ' + AllowAdd+'>&#10004;</span></td>' +
                    '<td style="text-align: center;vertical-align: middle;"><span style="font- size:100px;"' + AllowEdit+'>&#10004;</span></td>' +
                    '<td style="text-align: center;vertical-align: middle;"><span style="font- size:100px;"' + AllowDelete+'>&#10004;</span></td>' +
                    '<td style="text-align: center;vertical-align: middle;"><span style="font- size:100px;"' + AllowView+'>&#10004;</span></td>' +
                    '<td style="text-align: center;vertical-align: middle;"><span style="font- size:100px;"' + AllowPrint+'>&#10004;</span></td>' +
                    '<td style="text-align: center;vertical-align: middle;"><span style="font- size:100px;"' + AllowImport+'>&#10004;</span></td>' +
                    '<td style="text-align: center;vertical-align: middle;"><span style="font- size:100px;"' + AllowExport+'>&#10004;</span></td>' +
                    '<td style="text-align: center;vertical-align: middle;"><span style="font- size:100px;"' + AllowPost+'>&#10004;</span></td>' +
                    '<td style="text-align: center;vertical-align: middle;"><span style="font- size:100px;"' + AllowUnpost+'>&#10004;</span></td>' +
                    '<td style="text-align: center;vertical-align: middle;"><span style="font- size:100px;"' + AllowApprove+'>&#10004;</span></td>' +
                    //'<td hidden>' + UsersInfo.CreatedBy + '</td>' +
                    //'<td hidden>' + moment(UsersInfo.DateCreated).format("YYYY-MM-DD") + '</td>' +
                    //'<td hidden>' + UsersInfo.ModifiedBy + '</td>' +
                    //'<td hidden>' + DateMod + '</td>' +
                    //'<td>' + UsersInfo.Active + '</td>' +
                    '<td style="text-align: center;vertical-align: middle;"><span style="font- size:100px;"' + IsActive + '>&#10004;</span></td>' +
                    
                    //'<td hidden>' + UsersInfo.DeletedBy + '</td>' +
                    //'<td hidden>' + DelDate + '</td>' +
                     '<td align="right">' +
                         ' <div class="btn-group btn-group-rounded" role="group"> ' +
                            '<button id="btnEditModule" type="button" class="btn btn-outline-primary btn-xs"  title="click to Edit"' +
                            ' data-UserTypeID ="' + UsersInfo.UserTypeID + '"' +
                            ' data-UserType ="' + UsersInfo.UserType + '"' +
                            ' data-Add ="' +     UsersInfo.Add   + '"' +
                            ' data-Edit ="' +    UsersInfo.Edit  + '"' +
                            ' data-Delete ="' +  UsersInfo.Delete  + '"' +
                            ' data-View ="' +    UsersInfo.View  + '"' +
                            ' data-Print ="' +   UsersInfo.Print  + '"' +
                            ' data-Import ="' +  UsersInfo.Import  + '"' +
                            ' data-Export ="' +  UsersInfo.Export  + '"' +
                            ' data-Post ="' +    UsersInfo.Post + '"' +
                            ' data-Unpost ="' +  UsersInfo.Unpost  + '"' +
                            ' data-Approve ="' + UsersInfo.Approve + '"' +
                            ' data-Active ="' + UsersInfo.Active + '"' +

                                '><i class="fa fa-edit mr-5"></i> Edit' +
                            '</button> ' +

                           '<button id="btnDeleteModule" type="button" class="btn btn-outline-primary btn-xs" title="click to Delete"' +
                                ' data-UserTypeName ="' + UsersInfo.UserType + '"' +
                                ' data-UserTypeID ="' + UsersInfo.UserTypeID + '"' +
                                '><i class="fa fa-trash mr-5"></i> Delete ' +
                          '</button > ' +
                          '</div> ' +
                      '</td>' +
                    '</tr>')

            });

            $("#tblUserType_Header").DataTable().draw();
        })
           .fail(function (stat, msg, custom) {
               toastr.warning(stat.status + ": " + custom)

           });
    }
    //-----------------------------------------------------------------------------
    function LoadModules(UserTypeID)
    {
        $("#tblUserTypeModule_Header tbody tr").remove();
        $("#tblUserTypeModule_Header").DataTable().clear().draw();
        $("#tblUserTypeModule_Header").DataTable().destroy();

        $.post("/CBS/UserModule/LoadModules", { UserTypeID: UserTypeID })
            .done(function (data) {
                data = JSON.parse(data);
                var tblUserTypeModule_Body = $("#tblUserTypeModule_Body");
                tblUserTypeModule_Body.html("");
                var checkstate;
                $(data).each(function (i, Modules) {

                    if (Modules.chk == true) { checkstate = "checked"; }
                    else { checkstate = ""; }


                    tblUserTypeModule_Body.append('<tr>' +
                        '<td  style="text-align: center;vertical-align: middle;">' +
                        '   <div class="checkbox">' +
                        '     <input type="checkbox" id="chkSelected" class="chkSelected" ' + checkstate + ' />' +
                        '     <label for="chkSelected"></label>' +
                        '   </div>' +
                        '</td>' +
                        '<td>' + Modules.ModuleID + '</td>' +
                        '<td>' + Modules.ModuleName + '</td>' +
                        '</tr > ')

                })

                $("#tblUserTypeModule_Header").DataTable().draw();
                
            })
            .fail(function (stat, msg, custom) {
                toastr.warning(stat.status + ": " + custom)

            });
    }
    //-----------------------------------------------------------------------------
    LoadList();
    //-----------------------------------------------------------------------------
    $("#btnNew").on("click", function () {

        if (getBool(AllowAdd) == false) {
            toastr.info("Access Denied!", "Notification");
            return;
        }

        SaveMode = "Insert";
        UserTypeID_Global = "0";
        $("#txtUserTypeName_UT").val("");
        $("#chkAdd_UT").prop('checked', false);
        $("#chkEdit_UT").prop('checked', false);
        $("#chkDelete_UT").prop('checked', false);
        $("#chkView_UT").prop('checked', false);
        $("#chkPrint_UT").prop('checked', false);
        $("#chkImport_UT").prop('checked', false);
        $("#chkExport_UT").prop('checked', false);
        $("#chkPost_UT").prop('checked', false);
        $("#chkUnPost_UT").prop('checked', false);
        $("#chkApprove_UT").prop('checked', false);
        $("#chkActive_UT").prop('checked', true);
        
        LoadModules(0);
        $("#mod-Usertype").modal("show");
    })
    //-----------------------------------------------------------------------------
    $('#mod-Usertype').on('click', '#Chkall_UT', function () {
        $('#tblUserTypeModule_Header').DataTable()
            .column(0)
            .nodes()
            .to$()
            .find(".chkSelected").prop('checked', this.checked);
        
    })
    //-----------------------------------------------------------------------------
    $('#mod-Usertype').on('click', '#btnCancelUserType', function () {
        SaveMode = "";
        UserTypeID_Global = "0";
        
    })
    //-----------------------------------------------------------------------------
    $('#mod-Usertype').on('click', '#Close_Usertype', function () {
        SaveMode = "";
        UserTypeID_Global = "0";
    })
    //-----------------------------------------------------------------------------
    $('#mod-Usertype').on('click', '#btnSaveUserType', function () {

        $.confirm({
            title: "Confirmation",
            content: SaveMode +  " User Type?",
            buttons: {
                yes: function () {
                    $(".preloader-it").fadeIn(); //show
                    var userType = $("#txtUserTypeName_UT").val();
                    var AllowAdd = document.getElementById("chkAdd_UT").checked;
                    var AllowEdit = document.getElementById("chkEdit_UT").checked;
                    var AllowDelete = document.getElementById("chkDelete_UT").checked;
                    var AllowView = document.getElementById("chkView_UT").checked;
                    var AllowPrint = document.getElementById("chkPrint_UT").checked;
                    var AllowImport = document.getElementById("chkImport_UT").checked;
                    var AllowExport = document.getElementById("chkExport_UT").checked;
                    var AllowPost = document.getElementById("chkPost_UT").checked;
                    var AllowUnpost = document.getElementById("chkUnPost_UT").checked;
                    var AllowApprove = document.getElementById("chkApprove_UT").checked;
                    var IsActive = document.getElementById("chkActive_UT").checked;

            

                    var ModuleIDs = [];
                    var oTable = $('#tblUserTypeModule_Header').DataTable();
                    oTable.rows().every(function (index, element) {
                        var row = $(this.nodes());
                        var statusElement = row.find('td:first-child input[type="checkbox"]');
                        var isChecked = statusElement.prop('checked');
                        var data = this.data();
                        if (isChecked == true) {
                            ModuleIDs.push({
                                "ModuleID": data[1]
                            })
                        }
                    })

                    if (ModuleIDs.length > 0) {
                        $.post("/CBS/UserModule/SaveUserType", {
                            UserTypeModule: ModuleIDs ,
                            UserType: userType,
                            AllowAdd: AllowAdd,
                            AllowEdit: AllowEdit,
                            AllowDelete: AllowDelete,
                            AllowView: AllowView,
                            AllowPrint: AllowPrint,
                            AllowImport: AllowImport,
                            AllowExport: AllowExport,
                            AllowPost: AllowPost,
                            AllowUnpost: AllowUnpost,
                            AllowApprove: AllowApprove,
                            SaveMode: SaveMode,
                            UserTypeID: UserTypeID_Global,
                            Active : IsActive
                        })
                            .done(function (data) {
                                data = JSON.parse(data);
                                $(".preloader-it").fadeOut("slow");
                                $("#mod-Usertype").modal("hide");
                                toastr.success("Record successfully Saved.", "Notification");
                                LoadList()
                                SaveMode = "";
                                UserTypeID_Global = "0";
                                
                            })
                            .fail(function (stat, msg, custom) {
                                $(".preloader-it").fadeOut("slow");
                                toastr.warning(stat.status + ": " + custom)
                            });


                    }
                    else {
                        $(".preloader-it").fadeOut("slow");
                        toastr.info("No Module(s) tagged for this UserType", "Notification");
                    }

                },
                cancel: function () { }
            }
        });
        
    })
    //-----------------------------------------------------------------------------
    $('#tblUserType_Header').on('click', '#btnDeleteModule', function () {

        if (getBool(AllowDelete) == false) {
            toastr.info("Access Denied!", "Notification");
            return;
        }

        var UserTypeName = $(this).attr("data-UserTypeName");
        var UserTypeID = $(this).attr("data-UserTypeID");
        SaveMode = "";  
        UserTypeID_Global = "0";
        $.confirm({
            title: "Confirmation",
            content: "Delete " + UserTypeName + "?",
            buttons: {
                yes: function () {
                    $(".preloader-it").fadeIn(); //show
                    $.post("/CBS/UserModule/DeleteUserType", { UserTypeID: UserTypeID })
                        .done(function () {
                            $(".preloader-it").fadeOut("slow");
                            toastr.success("Record successfully Deleted.", "Notification");
                            LoadList()
                        })
                        .fail(function (stat, msg, custom) {
                            $(".preloader-it").fadeOut("slow");
                            toastr.warning(stat.status + ": " + custom)
                        });
                },
                cancel: function () { }
            }

        })

    })
    //-----------------------------------------------------------------------------
    $('#tblUserType_Header').on('click', '#btnEditModule', function () {
        if (getBool(AllowEdit) == false) {
            toastr.info("Access Denied!", "Notification");
            return;
        }

        SaveMode = "Update";
        UserTypeID_Global = $(this).attr("data-UserTypeID");
        var UserTypeID = $(this).attr("data-UserTypeID");
        var UserType = $(this).attr("data-UserType");
        var AllowAdd_e = $(this).attr("data-Add");
        var AllowEdit_e = $(this).attr("data-Edit");
        var AllowDelete_e = $(this).attr("data-Delete");
        var AllowView_e = $(this).attr("data-View");
        var AllowPrint_e = $(this).attr("data-Print");
        var AllowImport_e = $(this).attr("data-Import");
        var AllowExport_e = $(this).attr("data-Export");
        var AllowPost_e = $(this).attr("data-Post");
        var AllowUnpost_e = $(this).attr("data-Unpost");
        var AllowApprove_e = $(this).attr("data-Approve");
        var Active = $(this).attr("data-Active");

             
        $("#txtUserTypeName_UT").val(UserType);
        $("#chkAdd_UT").prop('checked', getBool(AllowAdd_e));
        $("#chkEdit_UT").prop('checked', getBool(AllowEdit_e));
        $("#chkDelete_UT").prop('checked', getBool(AllowDelete_e) );
        $("#chkView_UT").prop('checked', getBool(AllowView_e) );
        $("#chkPrint_UT").prop('checked', getBool(AllowPrint_e));
        $("#chkImport_UT").prop('checked', getBool(AllowImport_e) );
        $("#chkExport_UT").prop('checked', getBool(AllowExport_e));
        $("#chkPost_UT").prop('checked', getBool(AllowPost_e));
        $("#chkUnPost_UT").prop('checked', getBool(AllowUnpost_e));
        $("#chkApprove_UT").prop('checked', getBool(AllowApprove_e));
        $("#chkActive_UT").prop('checked', getBool(Active));

        LoadModules(UserTypeID);
        $("#mod-Usertype").modal("show");
    })
    //-----------------------------------------------------------------------------
})



