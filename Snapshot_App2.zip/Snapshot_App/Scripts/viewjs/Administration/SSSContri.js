﻿$(document).ready(function () {
    
    function GetSSSContriTble(year)
    {

        var TextToDisplay = "As of " + year;
        $('#SSSContri_Year').text(TextToDisplay);


        $("#tblSSSContri_Header tbody tr").remove();
        $("#tblSSSContri_Header").DataTable().clear().draw();
        $("#tblSSSContri_Header").DataTable().destroy();

        $.post("/CBS/MasterData/GetSSSContriTble", { Year: year })
        .done(function (data) {
            data = JSON.parse(data);
            var tblSSSContri_Body = $("#tblSSSContri_Body");
            tblSSSContri_Body.html("");
            $(data).each(function (i, Contri) {

                tblSSSContri_Body.append('<tr>' +
                        '<td>' + Contri.ID + '</td>' +
                        '<td>' + numeral(Contri.SalRangeLB).format("0,0.00") + '</td>' +
                        '<td>' + numeral(Contri.SalRangeUP).format("0,0.00") + '</td>' +
                        '<td>' + numeral(Contri.EE).format("0,0.00") + '</td>' +
                        '<td>' + numeral(Contri.ER).format("0,0.00") + '</td>' +

                    '</tr>')

                
            });
            $("#tblSSSContri_Header").DataTable().draw();
        })
       .fail(function (stat, msg, custom) {
             toastr.warning(stat.status + ": " + custom)
            });

    }
    //------------------------------------------------------------
    var today = new Date();
    CurrentYear = today.getFullYear();
    var year;

    $.ajax({
        type: "POST",
        url: "/CBS/MasterData/GetLatestYear",
        data: { "year": CurrentYear },
        success: function (data) {
            data = JSON.parse(data)
            year = data
        },
        async: false
    })

    GetSSSContriTble(year);
    //------------------------------------------------------------
    $("#mod-LoadTable").on("click", "#btnGenerateSSSTable", function () {

        var year = $("#txtyear_SSS").val()

        if (year.length != 4)
            {
            toastr.error("Invalid Year", "Notification");
            $("#txtyear_SSS").val("");
            }
        else
            {
            GetSSSContriTble(year);
            $("#txtyear_SSS").val("");
            }
    })

})