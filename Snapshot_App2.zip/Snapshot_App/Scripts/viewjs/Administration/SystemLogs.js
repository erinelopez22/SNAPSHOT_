﻿$(document).ready(function () {
    document.getElementById('dtsd').valueAsDate = new Date()
    document.getElementById('dted').valueAsDate = new Date()

    function GetLogs(SD,ED)
    {
     
        $("#tblSysyemLogs_Header tbody tr").remove();
        $("#tblSysyemLogs_Header").DataTable().clear().draw();
        $("#tblSysyemLogs_Header").DataTable().destroy();
        $.post("/CBS/SystemLogs/GetLogs", { SD: SD, ED: ED })
        .done(function (data) {
            data = JSON.parse(data);
            var tblSysyemLogs_Body = $("#tblSysyemLogs_Body");
            tblSysyemLogs_Body.html("");
            $(data).each(function (i, SystemLogsModel) {
                tblSysyemLogs_Body.append('<tr>' +
                    '<td>' + SystemLogsModel.No + '</td>' +
                    '<td>' + SystemLogsModel.Module + '</td>' +
                    '<td>' + SystemLogsModel.Process + '</td>' +
                    '<td>' + SystemLogsModel.EmpName + '</td>' +
                    '<td>' + moment(SystemLogsModel.Logdate).format('MM-DD-YYYY HH:mm') + '</td>' +
                //    '<td>' + moment(SystemLogsModel.Logdate).format("YYYY-MM-DD HH:MM") + '</td>' +
                    '<td>' + SystemLogsModel.Remarks + '</td>' +
                    '</tr>')

            });
            $("#tblSysyemLogs_Header").DataTable().draw();
            
        })
           .fail(function (stat, msg, custom) {
               toastr.warning(stat.status + ": " + custom)
           
           });

    }

    GetLogs($("#dtsd").val(), $("#dted").val());

    $("#btnLoad").on("click", function () {

        $(".preloader-it").fadeIn(); //show
        $("#tblSysyemLogs_Header tbody tr").remove();
        $("#tblSysyemLogs_Header").DataTable().clear().draw();
        $("#tblSysyemLogs_Header").DataTable().destroy();
        $.post("/CBS/SystemLogs/GetLogs", { SD: $("#dtsd").val(), ED: $("#dted").val() })
        .done(function (data) {
            data = JSON.parse(data);
            var tblSysyemLogs_Body = $("#tblSysyemLogs_Body");
            tblSysyemLogs_Body.html("");
            $(data).each(function (i, SystemLogsModel) {
                tblSysyemLogs_Body.append('<tr>' +
                    '<td>' + SystemLogsModel.No + '</td>' +
                    '<td>' + SystemLogsModel.Module + '</td>' +
                    '<td>' + SystemLogsModel.Process + '</td>' +
                    '<td>' + SystemLogsModel.EmpName + '</td>' +
                    '<td>' + SystemLogsModel.Logdate + '</td>' +
                    '<td>' + SystemLogsModel.Remarks + '</td>' +
                    '</tr>')

            });
            $("#tblSysyemLogs_Header").DataTable().draw();
            $(".preloader-it").fadeOut("slow");
        })
           .fail(function (stat, msg, custom) {
               toastr.warning(stat.status + ": " + custom)
               $(".preloader-it").fadeOut("slow");
           });
    })


})