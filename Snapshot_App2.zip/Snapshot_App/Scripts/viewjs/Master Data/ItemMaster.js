﻿$(document).ready(function () {
    
    var Old_UOM;
    var Old_CONV;
    var ItemCodeGlobal;
    var ItemNameGlobal;
    var edit = 0;

    
    //----------------------------------------------
    $.post("/CBS/Common/GetBranchWithIP", function (data) {
        data = JSON.parse(data);
        var CboBranch = $("#mod-NewConv #CboBranch");
        CboBranch.html("");
        $(data).each(function (index, br) {
            CboBranch.append('<option value="' + br.Whscode + '">' + br.whsName + '</option>');
        });
        
       
    });
    $('#CboBranch').selectpicker();

    //----------------------------------------------
    function LoadItemMaster() {
        $("#tblItemMasterHeader tbody tr").remove();
        $("#tblItemMasterHeader").DataTable().clear().draw();
        $("#tblItemMasterHeader").DataTable().destroy();

        $.post("/CBS/ItemMaster/GetItemList")
        .done(function (data) {
            data = JSON.parse(data);
            var tblItemMasterbody = $("#tblItemMasterbody");
            tblItemMasterbody.html('');

            $(data).each(function (i,itemMaster) {
                tblItemMasterbody.append('<tr>' +
                    '<td>' + itemMaster.ItemCode + '</td>' +
                    '<td>' + itemMaster.ItemName + '</td>' + 
                    '<td align="middle">' +
                        '<span>' +
                            '<button id="btnViewConv" type="button" class="btn  btn-xs btn-outline-primary  btn-rounded" title="Click to view conversion/s"' +
                            ' data-ItemCode="' + itemMaster.ItemCode + '" ' +
                            ' data-ItemName="' + itemMaster.ItemName + '" ' +
                             '><i class="fa fa-folder-open" mr-15></i>View</button>' +
                            //'<button id="btnEditItem" type="button" class="btn btn-xs btn-outline-primary" title="Click to Edit Item" '+
                            //' data-ItemCode="' + itemMaster.ItemCode + '" ' +
                            //' data-ItemName="' + itemMaster.ItemName + '" ' +
                            //'><i class="fa fa-edit" mr-15></i>Edit</button>' +
                            //'<button id="btnDeleteItem" type="button" class="btn btn-xs btn-outline-danger" title="Click to Delete Item" ' +
                            //' data-ItemCode="' + itemMaster.ItemCode + '" ' +
                            //' data-ItemName="' + itemMaster.ItemName + '" ' +
                            //'><i class="fa fa-trash" mr-15></i>Delete</button>' +

                        '</span>' +  
                    '</td>' +
              
                    '</tr>')
            });
            $("#tblItemMasterHeader").DataTable().draw();
        })
        .fail(function (stat, msg, custom) {
            toastr.warning(stat.status + ": " + custom)
        });
        
    }
    //----------------------------------------------
    LoadItemMaster();
    //----------------------------------------------
    function ViewConv(ItemCode, itemname) {
      
        //$("#tblItemConvHeader tbody tr").remove();
        //$("#tblItemConvHeader").DataTable().clear().draw();
        //$("#tblItemConvHeader").DataTable().destroy();


        $.post("/CBS/ItemMaster/GetItemConvbyItemcode", { itemcode: ItemCode })
        .done(function (data) {
            data = JSON.parse(data);
            var tblItemConvbody = $("#tblItemConvbody");
            tblItemConvbody.html('');
            var datei;
            $(data).each(function (i, itemMaster) {

                if (itemMaster.Effectivitydate == "1900-01-01T00:00:00") {
                    datei = "---";
                }
                else {
                    datei = moment(itemMaster.Effectivitydate).format("YYYY-MM-DD");
                }

                tblItemConvbody.append('<tr>' +
                    '<td>' + itemMaster.Uom + '</td>' +
                    '<td>' + itemMaster.Conv + '</td>' +
                    '<td class="text-center">' + datei + '</td>' +
                    '<td align="middle">' +
                        '<span>' +
                            '<button id="btnEditItem_conv" type="button" class="btn btn-xs btn-outline-primary" title="Click to Edit Item" ' +
                            ' data-ItemCodeConv="' + ItemCode + '" ' +
                            ' data-ItemNameConv="' + itemname + '" ' +
                            ' data-UOM="' + itemMaster.Uom + '" ' +
                            ' data-CONV="' + itemMaster.Conv + '" ' +
                            ' data-EfDate="' + datei + '" ' +
                            '><i class="fa fa-edit" mr-15></i></button>' +
                            '<button id="btnDeleteItem_conv" type="button" class="btn btn-xs btn-outline-danger" title="Click to Delete Item" ' +
                            ' data-ItemCodeConv="' + ItemCode + '" ' +
                            ' data-ItemNameConv="' + itemname + '" ' +
                            ' data-UOM="' + itemMaster.Uom + '" ' +
                            ' data-CONV="' + itemMaster.Conv + '" ' +
                            ' data-EfDate="' + datei + '" ' +
                            '><i class="fa fa-trash" mr-15></i></button>' +

                        '</span>' +
                    '</td>' +
                    '</tr>')


            });

            ItemCodeGlobal = ItemCode;
            ItemNameGlobal = itemname;

            $('#ModalLabelItemCode').text("ITEM CODE: " + ItemCode);
            $('#ModalLabelItemName').text("ITEM NAME: " + itemname);
            $('#mod-ViewConv').modal('show');

        })
           .fail(function (stat, msg, custom) {
               toastr.warning(stat.status + ": " + custom)
           });


    }
    $("#tblItemMasterHeader").on("click", "#btnViewConv", function () {

        var itemname = $(this).attr("data-ItemName");
        var itemcode = $(this).attr("data-ItemCode");
        ViewConv(itemcode, itemname);
    });
    //---------------------------------------------
    $("#btnNewConv").on('click', function () {
        edit = 0;
        $("#txtNewUOM").val("");
        $("#txtNEWCONV").val("");
        document.getElementById('efDate').valueAsDate = new Date()

        $('#mod-ViewConv').modal('hide');
        $('#mod-NewConv').modal('show');
        
    })
    //---------------------------------------------
    $("#mod-NewConv").on("click", "#btnCloseNewUom", function () {
        edit = 0;
        $('#mod-NewConv').modal('hide');
        ViewConv(ItemCodeGlobal, ItemNameGlobal);
        $('#mod-ViewConv').modal('show');
        
    });
    //---------------------------------------------
    $("#mod-NewConv").on("click", "#btnCloseNewUom2", function () {
        edit = 0;
        $('#mod-NewConv').modal('hide');
        ViewConv(ItemCodeGlobal, ItemNameGlobal);
        $('#mod-ViewConv').modal('show');
        
    });
    //---------------------------------------------
    $("#mod-ViewConv").on("click", "#btnCloseViewConv", function () {
        var Old_UOM = "";
        var Old_CONV = "";
        var ItemCodeGlobal = "";
        var ItemNameGlobal = "";
        var edit = 0;
        
    })
    //---------------------------------------------
    $("#mod-NewConv").on("click", "#btnSaveNewUom", function () {
        

          var UOM = $("#txtNewUOM").val();
          var CONV = $("#txtNEWCONV").val();
          var EfDate = $("#efDate").val();
       
        $.confirm({
            title: "Confirmation",
            content: "Save Records?",
            buttons: {
                yes: function () {
                   
                    
                    if (edit == 0)
                    {
                        $.post("/CBS/ItemMaster/InsertNewItemConv", { ItemCode: ItemCodeGlobal, UOM: UOM, Conv: CONV, efDate: EfDate, edit: edit })
                           .done(function () {
                               $('#mod-NewConv').modal('hide');
                               ViewConv(ItemCodeGlobal, ItemNameGlobal);
                               $('#mod-ViewConv').modal('show');
                               toastr.success("Record Successfully Saved!", "Notification");
                               edit = 0;
                               Old_UOM = "";
                               Old_CONV = "";
                              })
                           .fail(function (stat, msg, custom) {
                               toastr.info(stat.status + ": " + custom)
                               $('#mod-NewConv').modal('hide');
                               ViewConv(ItemCodeGlobal, ItemNameGlobal);
                               $('#mod-ViewConv').modal('show');
                           })
                    }
                    else
                    {
                        $.post("/CBS/ItemMaster/UpdateItemConv", { ItemCode: ItemCodeGlobal, Old_UOM: Old_UOM, Old_Conv: Old_CONV, UOM: UOM, Conv: CONV, efDate: EfDate, edit: edit })
                        .done(function () {
                            $('#mod-NewConv').modal('hide');
                            ViewConv(ItemCodeGlobal, ItemNameGlobal);
                            $('#mod-ViewConv').modal('show');
                            toastr.success("Record Successfully Updated!", "Notification");
                            edit = 0;
                            Old_UOM = "";
                            Old_CONV = "";
                        })
                           .fail(function (stat, msg, custom) {
                               toastr.info(stat.status + ": " + custom)
                               $('#mod-NewConv').modal('hide');
                               ViewConv(ItemCodeGlobal, ItemNameGlobal);
                               $('#mod-ViewConv').modal('show');
                           })
                    }
                 },
                cancel: function () { }
            }
        })

    });
    //---------------------------------------------    
    $("#mod-ViewConv").on("click", "#btnEditItem_conv", function () {
        edit = 1;
        ItemCodeGlobal = $(this).attr("data-ItemCodeConv");
        $("#txtNewUOM").val($(this).attr("data-UOM"));
        $("#txtNEWCONV").val($(this).attr("data-CONV"));
        Old_UOM = $(this).attr("data-UOM");
        Old_CONV = $(this).attr("data-CONV");


        if ($(this).attr("data-EfDate") == "---") {
            document.getElementById('efDate').valueAsDate = new Date()
        }
        else {
            $("#efDate").val($(this).attr("data-EfDate"));
        }
        $('#mod-NewConv').modal('show');
        $('#mod-ViewConv').modal('hide');
        
        });
    //---------------------------------------------    
    $("#mod-ViewConv").on("click", "#btnDeleteItem_conv", function () {
      
        var Itemcode = $(this).attr("data-ItemCodeConv");
        var ItemName = $(this).attr("data-ItemNameConv");
        var UOM = $(this).attr("data-UOM");
        var Conv = $(this).attr("data-CONV");


        $.confirm({
            title: "Confirmation",
            content: "Delete Records?",
            buttons: {
                yes: function () {
                  

                    $.post("/CBS/ItemMaster/DeleteItemConv", { Itemcode: Itemcode, UOM: UOM, Conv: Conv })
                    .done(function () {
                            $('#mod-NewConv').modal('hide');
                            ViewConv(Itemcode, ItemName);
                            $('#mod-ViewConv').modal('show');
                            toastr.success("Record Successfully Deleted!", "Notification");
                    })
                     .fail(function (stat, msg, custom) {
                            toastr.info(stat.status + ": " + custom)
                            $('#mod-NewConv').modal('hide');
                            ViewConv(Itemcode, ItemName);
                            $('#mod-ViewConv').modal('show');
                    })


                },
                cancel: function () { }
            }
        })




           //.done(function () {
           //    $('#mod-NewConv').modal('hide');
           //    ViewConv(ItemCodeGlobal, ItemNameGlobal);
           //    $('#mod-ViewConv').modal('show');
           //    toastr.success("Record Successfully Saved!", "Notification");
           //    edit = 0;
           //    Old_UOM = "";
           //    Old_CONV = "";
           //})
           //                .fail(function (stat, msg, custom) {
           //                    toastr.info(stat.status + ": " + custom)
           //                    $('#mod-NewConv').modal('hide');
           //                    ViewConv(ItemCodeGlobal, ItemNameGlobal);
           //                    $('#mod-ViewConv').modal('show');
           //                })







    })

});
