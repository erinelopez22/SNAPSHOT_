﻿$(document).ready(function () {

    document.getElementById('btnSave_EO').disabled = true;
    document.getElementById('btnPost_EO').disabled = true;
    document.getElementById('btnExport_EO').disabled = true;

    //-----------------------------------------------------------------
    var AllowAdd;
    var AllowEdit;
    var AllowDelete;
    var AllowView;
    var AllowPrint;
    var AllowImport
    var AllowExport;
    var AllowPost;
    var AllowUnpost;
    var AllowApprove;
    //-----------------------------------------------------------------
    $.ajax({
        type: "POST",
        url: "/CBS/Common/Permissions",
        success: function (data) {
            data = JSON.parse(data)
            AllowAdd = data[0]["Add"]
            AllowEdit = data[0]["Edit"];
            AllowDelete = data[0]["Delete"];
            AllowView = data[0]["View"];
            AllowPrint = data[0]["Print"];
            AllowImport = data[0]["Import"];
            AllowExport = data[0]["Export"];
            AllowPost = data[0]["Post"];
            AllowUnpost = data[0]["Unpost"];
            AllowApprove = data[0]["Approve"];
        },
        async: false

    })
    //-----------------------------------------------------------------
    function getBool(val) {
        return !!JSON.parse(String(val).toLowerCase());
    }
    //-----------------------------------------------------------------
    var UserID = "";
    $.post("/CBS/Common/GetUserID", function (data) {
        data = JSON.parse(data);
        UserID = data;
    })
    //--------------------------------------------------------------------
    $.post("/CBS/Common/GetBranch", function (data) {
        data = JSON.parse(data);
        var cboBranch_EO = $("#cboBranch_EO");
        cboBranch_EO.html("");
        $(data).each(function (index, br) {
            cboBranch_EO.append('<option value="' + br.Whscode + '">' + br.whsName + '</option>');
        });
    });
    //--------------------------------------------------------------------
    $.post("/CBS/Common/GetMonths", function (data) {
        data = JSON.parse(data);
        var cboMonth_EO = $("#cboMonth_EO");
        cboMonth_EO.html("");
        $(data).each(function (index, br) {
            cboMonth_EO.append('<option value="' + br.MonthNum + '">' + br.MonthName + '</option>');
        });
    });
    //--------------------------------------------------------------------
    var Generate = function () {
        $(".preloader-it").fadeIn(); //show
        var branch = $("#cboBranch_EO").val();
        var Month = $("#cboMonth_EO").val();
        var Year = $("#txtyear_EO").val();

        $("#tblExOutrightHeader tbody tr").remove();
        $("#tblExOutrightHeader").DataTable().clear().draw();
        $("#tblExOutrightHeader").DataTable().destroy();

        $.post("/CBS/Common/GetGLPerBranch", { BranchCode: branch}, function (data) {
        data = JSON.parse(data);
        var cboGL_EO = $("#cboGL_EO", "#modalEdit_EO");
        cboGL_EO.html("");
        $(data).each(function (index, br) {
            cboGL_EO.append('<option value="' + br.GLCode + '">' + br.GLName + '</option>');
        });
    });


    

        $.post("/CBS/Asset/GenerateExpenseOutright", { branch: branch, Month: Month, Year: Year })
            .done(function (data) {
                data = JSON.parse(data);
                var tblExOutrightBody = $("#tblExOutrightBody");
                tblExOutrightBody.html("");

                $(data).each(function (i, Asset) {
                    var ED = "";
                    if (Asset.Entrydate != "")
                    {
                        ED = moment(Asset.Entrydate).format("YYYY-MM-DD");
                    }
             
                    
                    tblExOutrightBody.append('<tr>' +
                        '<td>' + Asset.DetailID + '</td>' +
                        '<td>' + Asset.DocEntry + '</td>' +
                        '<td>' + moment(Asset.Date).format("YYYY-MM-DD") + '</td>' +
                        '<td>' + Asset.PO + '</td>' +
                        '<td>' + Asset.AP + '</td>' +
                        '<td>' + Asset.Vendor + '</td>' +
                        '<td>' + Asset.GLAccount + '</td>' +
                        '<td>' + Asset.GLName + '</td>' +
                        '<td>' + Asset.ItemDescription + '</td>' +
                        '<td class="text-right">' + numeral(Asset.NetAmount).format("0,0.00") + '</td>' +
                        '<td>' + Asset.ExpenseAccount + '</td>' +
                        '<td>' + Asset.Remarks + '</td>' +
                        '<td>' + ED + '</td>' +
                       // '<td>' + Asset.Entrydate + '</td>' +
                        '<td>' + Asset.TransID + '</td>' +
                        '<td align="middle" ><button type="button" id="btnEdit_EO" class="btn btn-xs btn-outline-primary btn-rounded  " ' +
                        'data-RowIndex= "' + i + '"' +
                        'data-detailID= "' + Asset.DetailID + '"' +
                        'data-ExpenseAccount ="' + Asset.ExpenseAccount + '"' +
                        'data-Remarks ="' + Asset.Remarks + '"' +
                        'data-Entrydate ="' + Asset.Entrydate + '"' +
                        'data-TransID ="' + Asset.TransID + '"' +
                        ' title="Click to Edit"> <i class="fa fa-edit"></i></button >  </td > ' +
                        '</tr > ')
          
                });
        
                //$("#tblExOutrightHeader").DataTable({
                //    scrollX: true,
                //    fixedColumns: {
                //        leftColumns: 1 
                //    }
                //});

                $("table.pb-30").removeClass("pb-30")

                $("#tblExOutrightHeader").DataTable({
                    scrollX: true
                }).draw();
            
                if (document.querySelectorAll('#tblExOutrightHeader tbody tr').length >= 1) {
                    document.getElementById('btnSave_EO').disabled = false;
                    document.getElementById('btnPost_EO').disabled = false;
                    document.getElementById('btnExport_EO').disabled = false;
                }
                else {
                    document.getElementById('btnSave_EO').disabled = true;
                    document.getElementById('btnPost_EO').disabled = true;
                    document.getElementById('btnExport_EO').disabled = true;
                }

                $(".preloader-it").fadeOut("slow");     
            })
            .fail(function (stat, msg, custom) {
                $(".preloader-it").fadeOut("slow");
                toastr.warning(stat.status + ": " + custom)
            })

    };
    //---------------------------------------------------------------------
    $("#btnGenerate_EO").on("click", function () {
        var year = $("#txtyear_EO").val();

        if (year == "") {
            toastr.error("Year is Required", "Notification");
            $("#tblExOutrightHeader tbody tr").remove();
            $("#tblExOutrightHeader").DataTable().clear().draw();
            $("#tblExOutrightHeader").DataTable().destroy();
        }
        else if ($.isNumeric(year) == false) {
            toastr.error("Invalid Year", "Notification");
            $("#tblExOutrightHeader tbody tr").remove();
            $("#tblExOutrightHeader").DataTable().clear().draw();
            $("#tblExOutrightHeader").DataTable().destroy();
        }

        else if (year.length != 4) {
            toastr.error("Invalid Year", "Notification");
            $("#tblExOutrightHeader tbody tr").remove();
            $("#tblExOutrightHeader").DataTable().clear().draw();
            $("#tblExOutrightHeader").DataTable().destroy();

        }
        else {
            Generate();
        }
        

    });
    //---------------------------------------------------------------------
    $("#tblExOutrightHeader").on("click", "#btnEdit_EO", function () {
        if (getBool(AllowEdit) == false) {
            toastr.info("Access Denied!", "Notification");
            return;
        }

        if ($(this).attr("data-TransID") != 0) {
            toastr.info("Unable to edit, Record is already posted.", "Notification");
        }
        else
            {
                var table = $('#tblExOutrightHeader').DataTable()

                $("#rowindex_EO").val($(this).attr("data-RowIndex"))
                $("#DetailID_EO").val($(this).attr("data-detailID"));

                $("#cboGL_EO").val(table.cell($(this).attr("data-RowIndex"), 10).data());
                $("#Remarks_EO").val(table.cell($(this).attr("data-RowIndex"), 11).data());
                $("#EntryDate_EO").val(table.cell($(this).attr("data-RowIndex"), 12).data());

                $("#modalEdit_EO").modal("show");
            }
        })
    //---------------------------------------------------------------------
    $("#modalEdit_EO").on("click", "#btnUpdate_EO", function () {
      
        var table = $('#tblExOutrightHeader').DataTable()
        table.cell($("#rowindex_EO").val(), 10, { ExpenseAccount: 'applied' }).data($("#cboGL_EO").val());
        table.cell($("#rowindex_EO").val(), 11).data($("#Remarks_EO").val());
        table.cell($("#rowindex_EO").val(), 12, { Entrydate: 'applied' }).data($("#EntryDate_EO").val());

    })
    //---------------------------------------------------------------------
    $("#btnSave_EO").on("click", function () {
        
        if (getBool(AllowAdd) == false) {
            toastr.info("Access Denied!", "Notification");
            return;
        }
        
        if (document.querySelectorAll('#tblExOutrightHeader tbody tr').length == 0)
        {
        
            toastr.info("No Records to Save, Please generate first", "Notification")
        }
        else {

            $.confirm({
                title: "Confirmation",
                content: "Save Expense Outright of " + $("#cboBranch_EO option:selected").text() + " branch for " + $("#cboMonth_EO option:selected").text() + " " + $("#txtyear_EO").val() + " ?",
                buttons: {
                    yes: function () {
                        $(".preloader-it").fadeIn(); //show

                        var branch = $("#cboBranch_EO").val();
                        var mo = $("#cboMonth_EO").val();
                        var yr = $("#txtyear_EO").val();
                        var ExpenseOutright = [];

                        var data = $("#tblExOutrightHeader").DataTable().rows().data();
                        data.each(function (value, index) {
                            ExpenseOutright.push({

                                "DetailID": value[0],
                                "DocEntry": value[1],
                                "Date": value[2],
                                "PO": value[3],
                                "AP": value[4],
                                "Vendor": value[5],
                                "GLAccount": value[6],
                                "GLName": value[7],
                                "ItemDescription": value[8],
                                "NetAmount": value[9],
                                "ExpenseAccount": value[10],
                                "Remarks": value[11],
                                "Entrydate": value[12],
                                "TransID": value[13]
                            });

                        });
                        $.post("/CBS/Asset/SaveExpenseOutright", { ExpenseOutright: ExpenseOutright, Month: mo, year: yr, branch: branch })
                            .done(function () {
                                $(".preloader-it").fadeOut("slow");
                                toastr.success("Record successfully Saved.", "Notification");
                            })
                            .fail(function (stat, msg, custom) {
                                $(".preloader-it").fadeOut("slow");
                                toastr.info(stat.status + ": " + custom)
                            })

                    },
                    cancel: function () { }


                }

            });
        }
    });
    //---------------------------------------------------------------------
    $("#btnExport_EO").on("click", function () {

        if (getBool(AllowExport) == false) {
            toastr.info("Access Denied!", "Notification");
            return;
        }


        if (document.querySelectorAll('#tblExOutrightHeader tbody tr').length == 0)
        {
            toastr.info("No Records to Export, Please generate first", "Notification")
        }
        else
        {
            $.confirm({
                title: "Confirmation",
                content: "Export Expense Outright of " + $("#cboBranch_EO option:selected").text() + " branch for " + $("#cboMonth_EO option:selected").text() + " " + $("#txtyear_EO").val() + " ?",
                buttons: {
                    yes: function () {
                        $(".preloader-it").fadeIn(); //show

                        var branch = $("#cboBranch_EO").val();
                        var mo = $("#cboMonth_EO").val();
                        var yr = $("#txtyear_EO").val();
                        var ExpenseOutright = [];

                        var data = $("#tblExOutrightHeader").DataTable().rows().data();
                        data.each(function (value, index) {
                            ExpenseOutright.push({

                                "DetailID": value[0],
                                "DocEntry": value[1],
                                "Date": value[2],
                                "PO": value[3],
                                "AP": value[4],
                                "Vendor": value[5],
                                "GLAccount": value[6],
                                "GLName": value[7],
                                "ItemDescription": value[8],
                                "NetAmount": value[9],
                                "ExpenseAccount": value[10],
                                "Remarks": value[11],
                                "Entrydate": value[12],
                                "TransID": value[13]
                            });

                        });
                        $.post("/CBS/Asset/ExportExpenseOutright", { ExpenseOutright: ExpenseOutright, Month: mo, year: yr, branch: branch }, function (data) {
                            window.location = '/CBS/Asset/Download?fileGuid=' + data.FileGuid + '&filename=' + data.FileName;
                            $(".preloader-it").fadeOut("slow");
                            toastr.success("Record successfully Exported.", "Notification");
                        })
                            .fail(function (stat, msg, custom) {
                                $(".preloader-it").fadeOut("slow");
                                toastr.info(stat.status + ": " + custom)
                            })
                    },
                    cancel: function () { }
                }

            });
        }

    })
    //---------------------------------------------------------------------
    $("#btnPost_EO").on("click", function () {

        if (getBool(AllowPost) == false) {
            toastr.info("Access Denied!", "Notification");
            return;
        }


        $.post("/CBS/Common/GetUserID", function(data) {
            data = JSON.parse(data);
            UserID = data;
        })

        

        if (document.querySelectorAll('#tblExOutrightHeader tbody tr').length == 0) {
            toastr.info("No Records to Post, Please generate and save first", "Notification")
        }
        else {
            $.confirm({
                title: "Confirmation",
                content: "Post Expense Outright of " + $("#cboBranch_EO option:selected").text() + " branch for " + $("#cboMonth_EO option:selected").text() + " " + $("#txtyear_EO").val() + " ?",
                buttons: {
                    yes: function () {
                        $(".preloader-it").fadeIn(); //show

                        var branch = $("#cboBranch_EO").val();
                        var mo = $("#cboMonth_EO").val();
                        var yr = $("#txtyear_EO").val();
                        var ExpenseOutright = [];

                        var data = $("#tblExOutrightHeader").DataTable().rows().data();
                        data.each(function (value, index) {
                            ExpenseOutright.push({

                                "DetailID": value[0],
                                "DocEntry": value[1],
                                "Date": value[2],
                                "PO": value[3],
                                "AP": value[4],
                                "Vendor": value[5],
                                "GLAccount": value[6],
                                "GLName": value[7],
                                "ItemDescription": value[8],
                                "NetAmount": value[9],
                                "ExpenseAccount": value[10],
                                "Remarks": value[11],
                                "Entrydate": value[12],
                                "TransID": value[13]
                            });

                        });

                        

                       $.post("/CBS/Asset/SaveExpenseOutright", { ExpenseOutright: ExpenseOutright, Month: mo, year: yr, branch: branch })
                           .done(function () {

                               $.post("/CBS/Common/GetUserID", function(data) {
                                   data = JSON.parse(data);
                                   UserID = data;
                               })

                                var ExpenseOutright_Post = [];
                                var data_Post = $("#tblExOutrightHeader").DataTable().rows().data();
                                data.each(function (value, index) {

                                 if ((value[10] != "---") && (value[13] == "0") && (value[11] != "") && (value[11] != "---") && (value[12] != "")) {
                                   
                                     $.ajax({
                                         type: 'POST',
                                         url: 'http://192.171.3.29:84/CBS_API/api/Asset/PostAsset', // test local
                                         ContentType: 'application/json;charset=utf-8',
                                         data: {
                                             "DetailID": value[0],
                                             "GLCode": value[6],
                                             "Ref1": value[3] + "/" + value[4],
                                             "Ref2": value[8],
                                             "Ref3": value[2],
                                             "Amount": numeral(value[9]).value(),
                                             "ExpenseAccount": value[10],
                                             "Remarks": value[11],
                                             "PostingDate": value[12],
                                             "Postedby": UserID
                                             },
                                         dataType: 'json',
                                         statusCode: {
                                             200: function () {
                                                
                                                 $.post("/CBS/Asset/PostExpenseOutright", { branch: branch, month: mo, year: yr })
                                             },
                                             400: function (stat, msg, custom) {
                                                 console.log(stat)
                                                 $(".preloader-it").fadeOut("slow");
                                                 toastr.error(stat.Message, "notification");
                                             }
                                         }
                                     });

                                     
                                    }
                                });
                               //generate here
                                Generate(); 
                                $(".preloader-it").fadeOut("slow");
                                toastr.success("record successfully posted.", "notification");
                                
                        //---------------------------
                            })
                            .fail(function (stat, msg, custom) {
                                $(".preloader-it").fadeOut("slow");
                                toastr.info(stat.status + ": " + custom)
                            })
                   
                    },
                    cancel: function () { }
                }

            });

        }
    });
    //---------------------------------------------------------------------

});
