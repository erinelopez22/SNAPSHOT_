﻿
$(document).ready(function () {
    //DETAIL--------------------------------------------------------
    
    document.getElementById('dtsd').valueAsDate = new Date()
    document.getElementById('dted').valueAsDate = new Date()
    
    var AllowAdd;
    var AllowEdit;
    var AllowDelete;
    var AllowView;
    var AllowPrint;
    var AllowImport
    var AllowExport;
    var AllowPost;
    var AllowUnpost;
    var AllowApprove;

    $.ajax({
        type: "POST",
        url: "/CBS/Common/Permissions",
        success: function (data) {
            data = JSON.parse(data)
            AllowAdd = data[0]["Add"]
            AllowEdit = data[0]["Edit"];
            AllowDelete = data[0]["Delete"];
            AllowView = data[0]["View"];
            AllowPrint = data[0]["Print"];
            AllowImport = data[0]["Import"];
            AllowExport = data[0]["Export"];
            AllowPost = data[0]["Post"];
            AllowUnpost = data[0]["Unpost"];
            AllowApprove = data[0]["Approve"];
        },
        async: false

    })
    //-------------------------------

    function getBool(val) {
        return !!JSON.parse(String(val).toLowerCase());
    }
    //-----------------------------------------------------------------
    $.post("/CBS/Common/GetBranch", function (data) {
        data = JSON.parse(data);
        var cboBranch = $("#modGenerate #cboBranch");
        cboBranch.html("");
        $(data).each(function (index, br) {
            cboBranch.append('<option value="' + br.Whscode + '">' + br.whsName + '</option>');
        });
    });
    //-------------------------------------------------------------------------------------------
    $("#modGenerate").on("click", "#btnGenerate", function () {
        var br = $("#cboBranch").val();
        var sd = $("#dtsd").val();
        var ed = $("#dted").val();
        
        var AllowGenerate = true;
        if ($("#dtsd").val() == "") {
            toastr.error("Start Date is Required", "Notification")
            AllowGenerate = false;
        }
        else if ($("#dted").val() == "") {
            toastr.error("End Date is Required", "Notification")
            AllowGenerate = false;
        }
    
        if (AllowGenerate == true) {
            //function (br, sd, ed) {
            $("#modGenerate #tblassetGenerateHeader tbody tr").remove();
            $("#modGenerate #tblassetGenerateHeader").DataTable().clear().draw();
            $("#modGenerate #tblassetGenerateHeader").DataTable().destroy();

            $(".preloader-it").fadeIn(); //show
            $.post("/CBS/Asset/GetCategory", function (data) {
                data = JSON.parse(data);
                var cboAssCategory = "";
                $(data).each(function (index, br) {
                    cboAssCategory += '<option value="' + br.CategoryName + '">' + br.CategoryName + '</option>';
                });

                $.post("/CBS/Asset/GetAssetLists", { branch: br, startDate: sd, endDate: ed }, function (data) {
                    data = JSON.parse(data);
                    var tblassetGenerateBody = $("#modGenerate #tblassetGenerateBody");
                    tblassetGenerateBody.html("");
                    $(data).each(function (index, asset) {
                        tblassetGenerateBody.append('<tr>' +
                            '<td>' + asset.DetailID + '</td >' +
                            '<td > <select class="form-control custom-select custom-select-sm mr-15 cboAssCategory" data-detailID =' + asset.DetailID + ' >' + cboAssCategory + '</select> ' +
                              '<td ></td > ' +
                            '</td > ' +
                            '<td>' + asset.DocEntry + '</td >' +
                            '<td>' + moment(asset.Date).format("YYYY-MM-DD") + '</td >' +
                            '<td>' + asset.PO + '</td >' +
                            '<td>' + asset.AP + ' </td >' +
                            '<td>' + asset.Vendor + '</td >' +
                            '<td>' + asset.GLAccount + '</td >' +
                            '<td>' + asset.GLName + '</td >' +
                            '<td>' + asset.ItemDescription + '</td >' +
                            '<td>' + asset.Qty + '</td >' +
                            '<td class="text-right">' + numeral(asset.UnitPrice).format("0,0.00") + '</td >' +
                            '<td class="text-right">' + numeral(asset.GrossAmount).format("0,0.00") + '</td >' +
                            '<td class="text-right">' + numeral(asset.Discount).format("0,0.00") + '</td >' +
                            '<td class="text-right">' + numeral(asset.NetAmount).format("0,0.00") + '</td >' +
                            
                        
                            '</tr>');
                    });

                    $("#modGenerate #tblassetGenerateHeader").DataTable().draw();
                    $(".preloader-it").fadeOut("slow");
                });
            });

        }

    });
    //-------------------------------------------------------------------------------------------
    $("#modGenerate").on("change", ".cboAssCategory", function () {
        var table = $('#modGenerate #tblassetGenerateHeader').DataTable();
        table.cell($(this).attr("data-detailID") - 1, 2, { Category: 'applied' }).data($(this).val());

        //$('#container').css('display', 'block');
        //table.columns.adjust().draw();
    })
    //-------------------------------------------------------------------------------------------
    $("#modGenerate").on("click", "#btnSave", function () {
        var br = $("#cboBranch").val();
        var sd = $("#dtsd").val();
        var ed = $("#dted").val();


        var assetdet = [];
        var data = $("#modGenerate #tblassetGenerateHeader").DataTable().rows().data();
        data.each(function (value, index) {

            assetdet.push({
                "Category": value[2],
                "DocEntry": value[3],
                "Date": value[4],
                "PO": value[5],
                "AP": value[6],
                "Vendor": value[7],
                "GLAccount": value[8],
                "GLName": value[9],
                "ItemDescription": value[10],
                "Qty": value[11],
                "UnitPrice": value[12],
                "GrossAmount": value[13],
                "Discount": value[14],
                "NetAmount": value[15]
              

            })

          

        })

        if (assetdet.length == 0)
        {
            toastr.warning("No Record/s to Save, Please. Generate First.", "Notification")
        }
        else
            {
        $.confirm({
                title: "Confirmation",
                content: "Save Records?",
                buttons: {
                    yes: function () {
                        $(".preloader-it").fadeIn(); //show
                        $.post("/CBS/Asset/SaveAssetDet", { AssetDet: assetdet, Branch: br, StartDate: sd, EndDate: ed })
                            .done(function () {
                                $(".preloader-it").fadeOut("slow");

                                toastr.success("Record Successfully Saved!", "Notification");
                             
                                $("#modGenerate").modal('hide');
                                $("#modGenerate #tblassetGenerateHeader tbody tr").remove();
                                $("#modGenerate #tblassetGenerateHeader").DataTable().clear().draw();
                                $("#modGenerate #tblassetGenerateHeader").DataTable().destroy();
                                $("#modGenerate #tblassetGenerateHeader").DataTable().clear().draw();
                                LoadAsset();

                            })
                            .fail(function (stat, msg, custom) {
                                $(".preloader-it").fadeOut("slow");
                                toastr.info(stat.status + ": " + custom)
                            })

                    },
                    no: function () { }
                }

            })

        }

    });
    //-------------------------------------------------------------------------------------------
    $("#modGenerate").on("click", "#CloseModGenerate", function () {

        $("#modGenerate #tblassetGenerateHeader tbody tr").remove();
        $("#modGenerate #tblassetGenerateHeader").DataTable().clear().draw();
        $("#modGenerate #tblassetGenerateHeader").DataTable().destroy();
        $("#modGenerate #tblassetGenerateHeader").DataTable().clear().draw();
    })

    //-------------------------------------------------------------------------------------------
    //HEADER-------------------------------------------------------------------------------------
    function LoadAsset() {
        $("#tbleAssetHeader tbody tr").remove();
        $("#tbleAssetHeader").DataTable().clear().draw();
        $("#tbleAssetHeader").DataTable().destroy();

        $.post("/CBS/Asset/GetList", function (data) {
            data = JSON.parse(data);
            var tblassetHeaderbody = $("#tblassetHeaderbody");
            tblassetHeaderbody.html("");
            var isActive = "";

            $(data).each(function (i, asset) {
                
                //var active = "No";
                //if (asset.Active == true) { active = "Yes"; }
                if (asset.Active == false) { isActive = "hidden"; } else { isActive = ""; }

                tblassetHeaderbody.append('<tr>' +
                    '<td>' + asset.ID + '</td>' +
                    '<td>' + asset.Branch + '</td>' +
                    '<td>' + moment(asset.StartDate).format("YYYY-MM-DD") + '</td>' +
                    '<td>' + moment(asset.EndDate).format("YYYY-MM-DD") + '</td>' +
                    '<td>' + asset.Createdby + '</td>' +
                    '<td>' + moment(asset.DateCreated).format("YYYY-MM-DD") + '</td>' +
                    //'<td>' + active + '</td>' +
                    '<td style="text-align: center;vertical-align: middle;"><span style="font- size:100px;"' + isActive + '>&#10004;</span></td>' +


                    //'<td> ' + 
                    //'<button id="btnView" data-id="' + asset.ID + '" class="btn btn-sm btn-outline-primary btn-rounded   btnView" title="Click to view details" ><i class="fa fa-folder-open"></i></button ></td >' +
                    //'<td> <button id="btnDelete" data-id="' + asset.ID + '" class="btn btn-sm btn-outline-danger   btn-rounded   btnDelete" title="Click to delete details" ><i class="fa fa-minus-square"></i></button >' + 
                    //'</td >' +
                    
                    //'<td align="middle" width="5%">' +
                    //   //'<div class="btn-group" role="group">' +
                    //   '<button id="btnView" data-id="' + asset.ID + '" class="btn btn-xs  btn-outline-primary  btnView" title="Click to view details"><i class="fa fa-folder-open" mr-15></i></button > ' +
                    //   '<button id="btnDelete" data-id="' + asset.ID + '" class="btn btn-xs btn-outline-danger   btnDelete" title="Click to delete details"><i class="fa fa-trash"></i></button >' +
                    //   //'</div>' +
                    //'</td>' + 


                    '<td align="middle" width="5%">' +
                    ' <div class="btn-group btn-group-rounded" role="group"> ' +
                    '<button id="btnView" type="button" class="btn btn-outline-primary btn-xs"  title="Click to view details"' +
                    ' data-id ="' + asset.ID + '"' +
                    '><i class="fa fa-folder-open" mr-15></i> View' +
                    '</button> ' +

                    '<button id="btnDelete" type="button" class="btn btn-outline-primary btn-xs" title="click to Delete"' +
                    ' data-id ="' + asset.ID + '"' +
                    '><i class="fa fa-trash mr-5"></i> Delete ' +
                    '</button > ' +
                    '</div> ' +
                    '</td>' +
                    '</tr>');

            });
          
           // $("#tbleAssetHeader").DataTable().draw();
            
            var table = $('#tbleAssetHeader').DataTable({
                columnDefs: [
                    { width: '2%', targets: 0 },
                    { width: '10%', targets: 2 },
                    { width: '10%', targets: 3 },
                    { width: '10%', targets: 5 },
                    { width: '2%', targets: 6 }
                    
                ]
            });
            table.draw();
            
        });
    };
    //-------------------------------------------------------------------------------------------
    LoadAsset();
    //-------------------------------------------------------------------------------------------
    $("#btnNew").on("click", function () {
        if (getBool(AllowAdd) == false) {
            toastr.info("Access Denied!", "Notification");
            return;
        }

        $("#modGenerate").modal("show");
    })
    //----------------------------------------------------------------------
    $("#tblassetHeaderbody").on("click", "#btnView", function () {


        if (getBool(AllowView) == false) {
            toastr.info("Access Denied!", "Notification");
            return;
        }
        
        var headerid = $(this).attr("data-id");
        var Posted = "";
        $("#tblasset tbody tr").remove();
        $("#tblasset").DataTable().clear().draw();
        $("#tblasset").DataTable().destroy();

        $.post("/CBS/Asset/GetDetailbyHeaderId", { HeaderID: headerid }, function (data) {
            data = JSON.parse(data);
            
            var tblassetbody = $("#tblassetbody");
            tblassetbody.html("");

            $.post("/CBS/Asset/GetCategory", function (data) {
                data = JSON.parse(data);
                var cboAssCategory = $(".cboAssCategory");
                cboAssCategory.html("");
                $(data).each(function (index, br) {
                    cboAssCategory.append('<option value="' + br.CategoryName + '">' + br.CategoryName + '</option>');
                });
            });

//            console.log(data);

            $(data).each(function (i, asset) {

                if (asset.Posted == "False") { Posted = "hidden"; } else { Posted = ""; }

                tblassetbody.append('<tr>' +
                    '<td>' + asset.DetailID + '</td >' +
                    '<td>' + asset.Category + '</select >' +
                    '<td>' + asset.DocEntry + '</td >' +
                    '<td>' + moment(asset.Date).format("YYYY-MM-DD") + '</td >' +
                    '<td>' + asset.PO + '</td >' +
                    '<td>' + asset.AP + ' </td >' +
                    '<td>' + asset.Vendor + '</td >' +
                    '<td>' + asset.GLAccount + '</td >' +
                    '<td>' + asset.GLName + '</td >' +
                    '<td>' + asset.ItemDescription + '</td >' +
                    '<td>' + asset.Qty + '</td >' +
                    '<td class="text-right">' + numeral(asset.UnitPrice).format("0,0.00") + '</td >' +
                    '<td class="text-right">' + numeral(asset.GrossAmount).format("0,0.00") + '</td >' +
                    '<td class="text-right">' + numeral(asset.Discount).format("0,0.00") + '</td >' +
                    '<td class="text-right">' + numeral(asset.NetAmount).format("0,0.00") + '</td >' +
                    '<td style="text-align: center;vertical-align: middle;"><span style="font- size:100px;"' + Posted + '>&#10004;</span></td>' +
                    '</td > ' +
                    '</tr>');

            });
            $("#tblasset").DataTable().draw();
            $("#modAssetDetView").modal("show");
        });

    //    }

    });
    //----------------------------------------------------------------------
    $("#modAssetDetView").on("click", "#CloseModAssetDetView", function () {
        $("#tblasset tbody tr").remove();
        $("#tblasset").DataTable().clear().draw();
        $("#tblasset").DataTable().destroy();
    });
    //----------------------------------------------------------------------
    $("#tblassetHeaderbody").on("click", "#btnGenerate", function () {

        var headerid = $(this).attr("data-id");
        $("#tblasset tbody tr").remove();
        $("#tblasset").DataTable().clear().draw();
        $("#tblasset").DataTable().destroy();

        $.post("/CBS/Asset/GetDetailbyHeaderId", { HeaderID: headerid }, function (data) {
            data = JSON.parse(data);
            
            var tblassetbody = $("#tblassetbody");
            tblassetbody.html("");

            $.post("/CBS/Asset/GetCategory", function (data) {
                data = JSON.parse(data);
                var cboAssCategory = $(".cboAssCategory");
                cboAssCategory.html("");
                $(data).each(function (index, br) {
                    cboAssCategory.append('<option value="' + br.CategoryName + '">' + br.CategoryName + '</option>');
                });
            });

            $(data).each(function (i, asset) {
                tblassetbody.append('<tr>' +
                    '<td>' + asset.DetailID + '</td >' +
                    '<td>' + asset.DocEntry + '</td >' +
                    '<td>' + asset.Date + '</td >' +
                    '<td>' + asset.PO + '</td >' +
                    '<td>' + asset.AP + ' </td >' +
                    '<td>' + asset.Vendor + '</td >' +
                    '<td>' + asset.GLAccount + '</td >' +
                    '<td>' + asset.GLName + '</td >' +
                    '<td>' + asset.ItemDescription + '</td >' +
                    '<td>' + asset.Qty + '</td >' +
                    '<td class="text-right">' + asset.UnitPrice + '</td >' +  
                    '<td class="text-right">' + asset.GrossAmount + '</td >' +
                    '<td class="text-right">' + asset.Discount + '</td >' +
                    '<td class="text-right">' + asset.NetAmount + '</td >' +
                    '<td >' +
                    '<select class="form-control custom-select custom-select-sm mr-15 cboAssCategory"  value="' + asset.Category + '"> ' +
                    '<option style="width:100%"></option> ' +
                    '</select >' +
                    '</td > ' +
                    '</tr>');
                // '<td><button id="btnEdit" data-toggle="modal" data-target="#modalUpdateCategory" data-id="' + asset.DocEntry + '">Edit</button></td >' +
            });
            $("#tblasset").DataTable().draw();
            $("#modAssetDetNew").modal("toggle");
        });
    });
    //----------------------------------------------------------------------
    $("#tbleAssetHeader").on("click", "#btnDelete", function () {

        if (getBool(AllowDelete) == false) {
            toastr.info("Access Denied!", "Notification");
            return;
        }

        var headerid = $(this).attr("data-id")
      
        $.confirm({
            title: "Confirmation",
            content: "Are you sure you want to delete this record?",
            buttons: {
                yes: function () {
                    $.post("/CBS/Asset/DeleteAssetList", { HeaderID: headerid })
                        .done(function (data) {
                         LoadAsset();
                        toastr.success("Record successfully deleted.")
                        })
                        .fail(function (stat, msg, custom) {
                            $(".preloader-it").fadeOut("slow");
                            toastr.warning(stat.status + ": " + custom)
                        });
                    },
                cancel: function () {

                }
            }
        })
    })
  
});             



