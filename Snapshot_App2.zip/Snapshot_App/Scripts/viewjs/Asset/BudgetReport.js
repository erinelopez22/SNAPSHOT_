﻿
$(document).ready(function () {
    var x = document.getElementById('lblNEW_B');
    x.style.visibility = 'hidden';
    document.getElementById('btnSaveBR').disabled = true;
    document.getElementById('btnExportBR').disabled = true;

    var AllowAdd;
    var AllowEdit;
    var AllowDelete;
    var AllowView;
    var AllowPrint;
    var AllowImport
    var AllowExport;
    var AllowPost;
    var AllowUnpost;
    var AllowApprove;

    $.ajax({
        type: "POST",
        url: "/CBS/Common/Permissions",
        success: function (data) {
            data = JSON.parse(data)
            AllowAdd = data[0]["Add"]
            AllowEdit = data[0]["Edit"];
            AllowDelete = data[0]["Delete"];
            AllowView = data[0]["View"];
            AllowPrint = data[0]["Print"];
            AllowImport = data[0]["Import"];
            AllowExport = data[0]["Export"];
            AllowPost = data[0]["Post"];
            AllowUnpost = data[0]["Unpost"];
            AllowApprove = data[0]["Approve"];
        },
        async: false

    })
    //-------------------------------

    function getBool(val) {
        return !!JSON.parse(String(val).toLowerCase());
    }
    //-----------------------------------------------------------------

    

    //------------------------------------------------------------------------------------
    var LoadBudgetReport = function () {
        var year = $("#txtYear").val();

        if (year == "") {
            toastr.error("Year is Required", "Notification");
        }
        else if ($.isNumeric(year) == false) {
            toastr.error("Invalid Year", "Notification");
        }

        else if (year.length != 4) {
            toastr.error("Invalid Year", "Notification");

        }
        else {
            $(".preloader-it").fadeIn(); //show
            $("#tblBPReportHeader tbody tr").remove();
            $("#tblBPReportHeader").DataTable().clear().draw();
            $("#tblBPReportHeader").DataTable().destroy();

            var IsExist
            var stat;
            var vis;
            var totalrowcolor;
            $.post("/CBS/Asset/CheckBudgetifExist", { Year: year }, function (data) {

                IsExist = data.result;
                if (data.result == 0)
                {
                    stat = "disabled"
                }
            })
          

            $.post("/CBS/Asset/GenerateBudgetReport", { Year: year }, function (data) {
                data = JSON.parse(data);
                var tblBPReportBody = $("#tblBPReportBody");
                tblBPReportBody.html("");
                
                $(data).each(function (i, asset) {

                  
                    if (asset.Branch.match("TOTAL"))
                    {
                        vis = 'hidden';
                        totalrowcolor = "background-color: #61646094;color: white;font-size: 12px;font-weight: bold;"
                    }
                  
                    console.log(totalrowcolor);

                    tblBPReportBody.append('<tr style="' + totalrowcolor + '" >' +
                        '<td>' + asset.Branch + '</td>' +
                        '<td class="text-right">' + numeral(asset.FUAP).format("0,0.00") + '</td>' +
                        '<td class="text-right">' + numeral(asset.CSH).format("0,0.00") + '</td>' +
                        '<td class="text-right">' + numeral(asset.FF).format("0,0.00") + '</td>' +
                        '<td class="text-right">' + numeral(asset.TE).format("0,0.00") + '</td>' +
                        '<td class="text-right">' + numeral(asset.LIS).format("0,0.00") + '</td>' +
                        '<td class="text-right">' + numeral(asset.LIDE).format("0,0.00") + '</td>' +
                        '<td class="text-right">' + numeral(asset.BUILD).format("0,0.00") + '</td>' +
                        '<td class="text-right">' + numeral(asset.TotalBudget).format("0,0.00") + '</td>' +
                        '<td align="middle"> <button type="button" id="btnEditBR" class="btn btn-xs btn-outline-primary btn-rounded"  ' +
                        ' data-Branch ="' + asset.Branch + '"' +
                        ' data-FUAP ="' + asset.FUAP + '"' +
                        ' data-CSH ="' + asset.CSH + '"' +
                        ' data-FF ="' + asset.FF + '"' +
                        ' data-TE ="' + asset.TE + '"' +
                        ' data-LIS ="' + asset.LIS + '"' +
                        ' data-LIDE ="' + asset.LIDE + '"' +
                        ' data-BUILD ="' + asset.BUILD + '"' + stat + ' ' +  vis + 
                        ' title="Click to Edit" > <i class="fa fa-edit"></i> </button > </td > ' +
                        '</tr>'
                    );

                    



                });
             
               

                $("#tblBPReportHeader").DataTable({
                    scrollX: true,
                    ordering: false
                }).draw();
                
              


                if ($("#tblBPReportHeader").DataTable().rows().any() == true) {

                    if (IsExist == 0) {
                        document.getElementById('lblNEW_B').style.visibility = 'visible';
                        document.getElementById('btnSaveBR').disabled = false;
                        document.getElementById('btnExportBR').disabled = false;
                    }
                    else {
                        document.getElementById('lblNEW_B').style.visibility = 'hidden';
                        document.getElementById('btnSaveBR').disabled = true;
                        document.getElementById('btnExportBR').disabled = false;
                    }
                }
                else
                {
                    document.getElementById('btnSaveBR').disabled = true;
                    document.getElementById('btnExportBR').disabled = true;
                }
            });
            $(".preloader-it").fadeOut("slow");
        }
    };
    //------------------------------------------------------------------------------------
    $("#btnGenerateBR").on("click", function () {
        LoadBudgetReport();
    });
     //------------------------------------------------------------------------------------
    $("#btnSaveBR").on("click", function () {

        if (getBool(AllowAdd) == false) {
            toastr.info("Access Denied!", "Notification");
            return;
        }


        if (document.querySelectorAll('#tblBPReportHeader tbody tr').length == 0) {
            toastr.info("No Records to Save, Please generate first", "Notification")
        }
        else {
            var year = $("#txtYear").val();
            $.confirm({
                title: "Confirmation",
                content: "Save Records?",
                buttons: {
                    yes: function () {

                        $(".preloader-it").fadeIn(); //show
                        var BudgetReportDet = [];
                        var data = $("#tblBPReportHeader").DataTable().rows().data();
                            data.each(function (value, index) {

                                BudgetReportDet.push({
                                    "Branch": value[0],
                                    "FUAP": value[1],
                                    "CSH": value[2],
                                    "FF": value[3],
                                    "TE": value[4],
                                    "LIS": value[5],
                                    "LIDE": value[6],
                                    "BUILD": value[7],
                                    "TotalBudget": value[8]
                                });

                            });
                  
                            $.post("/CBS/Asset/SaveBudgetReport", { BudgetReport: BudgetReportDet, Year: year })
                                .done(function () {
                                    LoadBudgetReport();
                                    $(".preloader-it").fadeOut("slow");
                                    toastr.success("Record Successfully saved!", "Notification");
                                })
                                .fail(function (stat, msg, custom) {
                                    $(".preloader-it").fadeOut("slow");
                                    toastr.info(stat.status + ": " + custom)
                                })
                    },
                    cancel: function () { }
                }
            })
        }
    });
    //------------------------------------------------------------------------------------
    $("#btnExportBR").on("click", function () {

        if (getBool(AllowExport) == false) {
            toastr.info("Access Denied!", "Notification");
            return;
        }

        var year = $("#txtYear").val();
        var BudgetReportDet = [];

        var data = $("#tblBPReportHeader").DataTable().rows().data();
        data.each(function (value, index) {

            BudgetReportDet.push({
                "Branch": value[0],
                "FUAP": numeral(value[1]).value(),
                "CSH": numeral(value[2]).value(),
                "FF": numeral(value[3]).value(),
                "TE": numeral(value[4]).value(),
                "LIS": numeral(value[5]).value(),
                "LIDE": numeral(value[6]).value(),
                "BUILD": numeral(value[7]).value(),
                "TotalBudget": numeral(value[8]).value()
            });

        });

        if (BudgetReportDet == "[object Object]") {
            toastr.error("No Record/s to Export, Please. Generate First.", "Notification")
        }
        else if (BudgetReportDet == "") {
            toastr.error("No Record/s to Export, Please. Generate First.", "Notification")
        }
        else {

            $.confirm({
                title: "Confirmation",
                content: "Extract Records?",
                buttons: {
                    yes: function () {
                        $(".preloader-it").fadeIn(); //show
                        $.post("/CBS/Asset/ExtractBudgetReport", { BudgetReport: BudgetReportDet, year: year })
                            .done(function (data) {
                                window.location = '/CBS/Asset/Download?fileGuid=' + data.FileGuid + '&filename=' + data.FileName;
                                $(".preloader-it").fadeOut("slow");
                                toastr.success("Record successfully Exported.", "Notification");
                            })
                             .fail(function (stat, msg, custom) {
                                toastr.warning(stat.status + ": " + custom)
                            })
                    },
                    cancel: function () {

                    }
                }
            })

        }



    });
    //------------------------------------------------------------------------------------
    $("#tblBPReportBody").on("click", "#btnEditBR", function () {

        if (getBool(AllowEdit) == false) {
            toastr.info("Access Denied!", "Notification");
            return;
        }
        
        $("#txtYear-Update").val($("#txtYear").val());
            $("#txtBranch").val($(this).attr("data-Branch"));
            $("#txtFUAP").val(numeral($(this).attr("data-FUAP")).format("0,0.00"));
            $("#txtCSH").val(numeral($(this).attr("data-CSH")).format("0,0.00"));
            $("#txtFF").val(numeral($(this).attr("data-FF")).format("0,0.00"));
            $("#txtTE").val(numeral($(this).attr("data-TE")).format("0,0.00"));
            $("#txtLIS").val(numeral($(this).attr("data-LIS")).format("0,0.00"));
            $("#txtLIDE").val(numeral($(this).attr("data-LIDE")).format("0,0.00"));
            $("#txtBUILD").val(numeral($(this).attr("data-BUILD")).format("0,0.00"));

            $("#Modal-UpdateBR").modal("show");
        });
    //------------------------------------------------------------------------------------
    $("#Modal-UpdateBR").on("click", "#btnUpdateBR", function () {

        $.confirm({
            title: "Confirmation",
            content: "Update Branch " + $("#txtBranch").val() + " For The Year " + $("#txtYear-Update").val() + " Budget Report?",
            buttons: {
                yes: function () {

                    $.ajax({
                        type: "POST",
                        dataType: "json",
                        url: "/CBS/Asset/UpdateBudgetReport",
                        data: {

                            FUAP: $("#txtFUAP").val(),
                            CSH: $("#txtCSH").val(),
                            FF: $("#txtFF").val(),
                            TE: $("#txtTE").val(),
                            LIS: $("#txtLIS").val(),
                            LIDE: $("#txtLIDE").val(),
                            BUILD: $("#txtBUILD").val(),
                            EO: $("#txtEO").val(),
                            Branch: $("#txtBranch").val(),
                            year: $("#txtYear-Update").val()


                        }

                    });

                    LoadBudgetReport();
                    $('#Modal-UpdateBR').modal('hide');
                    toastr.success("Record successfully Updated.", "Notification");


                },
                cancel: function () {

                }
            }

        });


    });
 
});    