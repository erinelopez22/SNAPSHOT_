﻿$(document).ready(function () {
    //------------------------------------------------------------------------------------
    var x = document.getElementById('lblNEW_AR');
    x.style.visibility = 'hidden';
    document.getElementById('btnSave_AL').disabled = true;
    document.getElementById('btnDelete_AL').disabled = true;
    document.getElementById('btnExport_AL').disabled = true;



    var AllowAdd;
    var AllowEdit;
    var AllowDelete;
    var AllowView;
    var AllowPrint;
    var AllowImport
    var AllowExport;
    var AllowPost;
    var AllowUnpost;
    var AllowApprove;

    $.ajax({
        type: "POST",
        url: "/CBS/Common/Permissions",
        success: function (data) {
            data = JSON.parse(data)
            AllowAdd = data[0]["Add"]
            AllowEdit = data[0]["Edit"];
            AllowDelete = data[0]["Delete"];
            AllowView = data[0]["View"];
            AllowPrint = data[0]["Print"];
            AllowImport = data[0]["Import"];
            AllowExport = data[0]["Export"];
            AllowPost = data[0]["Post"];
            AllowUnpost = data[0]["Unpost"];
            AllowApprove = data[0]["Approve"];
        },
        async: false

    })
    //-------------------------------

    function getBool(val) {
        return !!JSON.parse(String(val).toLowerCase());
    }
    //-----------------------------------------------------------------





    $.post("/CBS/Asset/GetCategory", function (data) {
        data = JSON.parse(data);
        var cboCategory_AL = $("#cboCategory_AL");
        cboCategory_AL.html("");
        $(data).each(function (index, br) {
            cboCategory_AL.append('<option value="' + br.CategoryName + '">' + br.CategoryName + '</option>');
        });
    });
     //-----------------------------------------------------------------
    $.post("/CBS/Common/GetMonths", function (data) {
        data = JSON.parse(data);
        var cboMonth_AL = $("#cboMonth_AL");
        cboMonth_AL.html("");
        $(data).each(function (index, br) {
            cboMonth_AL.append('<option value="' + br.MonthNum + '">' + br.MonthName + '</option>');
        });
    });
    //------------------------------------------------------------------------------------
    var Load = function () {
        var Category = $("#cboCategory_AL").val();
        var Month = $("#cboMonth_AL").val();
        var Year = $("#txtyear_AL").val();
        var totalrowcolor;
        var dt;

        if (Year == "") {
            toastr.error("Year is Required", "Notification");
        }
        else if ($.isNumeric(Year) == false) {
            toastr.error("Invalid Year", "Notification");
        }
        else if (Year.length != 4) {
            toastr.error("Invalid Year", "Notification");
        }
        else {
            $(".preloader-it").fadeIn(); //show
            var IsExist
            $.post("/CBS/Asset/CheckAssetListReportIfExisit", { month: Month, year: Year, Category: Category }, function (data) {
                IsExist = data.result;
            })


            $("#tblAssetListHeader").DataTable().clear().draw().destroy();
            $.post("/CBS/Asset/GenerateAssetList", { month: Month, year: Year, Category: Category }, function (data) {
                data = JSON.parse(data);
                var tblAssetListBody = $("#tblAssetListBody");
                tblAssetListBody.html("");

                $(data).each(function (i, asset) {
                    dt = moment(asset.Date).format("YYYY-MM-DD")
                    if (asset.Branch.match("GRAND TOTAL")) {
                        totalrowcolor = "background-color: #616460;color: white;font-size: 12px;font-weight: bold;"
                        dt = "---";
                    }
                    else if (asset.Branch.match("TOTAL")) {
                        totalrowcolor = "background-color: #61646094;color: white;font-size: 12px;font-weight: bold;"
                        dt = "---";
                    }
                    else {
                        totalrowcolor = "";
                    }

                    tblAssetListBody.append('<tr style="' + totalrowcolor + '" >' +
                        '<td>' + asset.Branch + '</td>' +
                        '<td>' + dt + '</td>' +
                        '<td>' + asset.ItemDescription + '</td>' +
                        '<td class="text-right">' + numeral(asset.NetAmount).format("0,0.00") + '</td>' +
                        '</tr>')
                });
                $("#tblAssetListHeader").DataTable({
                    ordering: false
                })
                if ($("#tblAssetListHeader").DataTable().rows().any() == true) {
                    if (IsExist == 0) {
                        document.getElementById('lblNEW_AR').style.visibility = 'visible';
                        document.getElementById('btnSave_AL').disabled = false;
                        document.getElementById('btnDelete_AL').disabled = true;
                        document.getElementById('btnExport_AL').disabled = false;
                    }
                    else {
                        document.getElementById('lblNEW_AR').style.visibility = 'hidden';
                        document.getElementById('btnSave_AL').disabled = true;
                        document.getElementById('btnDelete_AL').disabled = false;
                        document.getElementById('btnExport_AL').disabled = false;
                    }
                }
                else {
                    document.getElementById('lblNEW_AR').style.visibility = 'hidden';
                    document.getElementById('btnSave_AL').disabled = true;
                    document.getElementById('btnDelete_AL').disabled = true;
                    document.getElementById('btnExport_AL').disabled = true;
                }

              
            });
            $(".preloader-it").fadeOut("slow");
        }
    };
    //------------------------------------------------------------------------------------
    $("#btnLoad_AL").on("click", function () {
        Load();
    });
    //------------------------------------------------------------------------------------
    $('#btnSave_AL').on("click", function () {

        if (getBool(AllowAdd) == false) {
            toastr.info("Access Denied!", "Notification");
            return;
        }

        var category = $("#cboCategory_AL").val();
        var month = $("#cboMonth_AL").val();
        var year = $("#txtyear_AL").val();
        
        var ReportList = [];
        $("#tblAssetListBody").find("tr").each(function () {
            var $td = $(this).find("td"),
                branch = $td.eq(0).text(),
                DateP = $td.eq(1).text(),
                ItemDesc = $td.eq(2).text(),
                NetAmount = $td.eq(3).text();
       
        })

        var datei;

        var data = $("#tblAssetListHeader").DataTable().rows().data();
        data.each(function (value, index) {

            if (value[1] == "---") {
                datei = '1900-01-01';
            }
            else {
                datei = value[1];
            }

            ReportList.push({
                "Branch": value[0],
                "Date": datei,
                "ItemDescription": value[2],
                "NetAmount": value[3]
            })
        })
            $.confirm({
                title: "Confirmation",
                content: "Save Records?",
                buttons: {
                    yes: function () {
                        $(".preloader-it").fadeIn(); //show
                        $.post("/CBS/Asset/SaveAssetListReport", { ReportList: ReportList, Month: month, Year: year, Category: category })
                            .done(function () {
                                Load();
                                $(".preloader-it").fadeOut("slow");
                                toastr.success("Record Successfully Saved!", "Notification");
                            })
                            .fail(function (stat, msg, custom) {
                                toastr.warning(stat.status + ": " + custom)
                            })
                        
                    },
                    no: function () { }
                }
                
            })
    });
    //------------------------------------------------------------------------------------
    $('#btnDelete_AL').on("click", function () {

        if (getBool(AllowDelete) == false) {
            toastr.info("Access Denied!", "Notification");
            return;
        }

        var category = $("#cboCategory_AL").val();
        var month = $("#cboMonth_AL").val();
        var year = $("#txtyear_AL").val();
        if (document.querySelectorAll('#tblAssetListHeader tbody tr').length == 0)
        {
            toastr.info("No Records to delete.","Notification")
        }
        else
        {
        $.confirm({
            title: "Confirmation",
            content: "Are you sure you want to delete this record?",
            buttons: {
                yes: function () {
                    $(".preloader-it").fadeIn(); //show
                    $.post("/CBS/Asset/DeleteAssetListReport", { month: month, year: year, category: category })
                        .done(function () {
                            
                            $("#tblAssetListHeader").DataTable().destroy();
                            var table = $('#tblAssetListHeader').DataTable();
                            table.rows().remove().draw();
                            $(".preloader-it").fadeOut("slow");
                            document.getElementById('btnSave_AL').disabled = false;
                            document.getElementById('btnDelete_AL').disabled = false;
                            toastr.success("Record Successfully Deleted!", "Notification");
                            
                        })
                        .fail(function (stat, msg, custom) {
                            toastr.warning(stat.status + ": " + custom)
                        })
                  
                },
                no: function(){}
            }
            })
        }
    });
    //------------------------------------------------------------------------------------
    $('#btnExport_AL').on("click", function(){

        if (getBool(AllowExport) == false) {
            toastr.info("Access Denied!", "Notification");
            return;
        }


        var category = $("#cboCategory_AL").val();

        
        if (document.querySelectorAll('#tblAssetListHeader tbody tr').length <= 1) {
            toastr.info("No Records to Export.", "Notification")
        }
        else {
          
            var AssetListReport = [];
            var data = $("#tblAssetListHeader").DataTable().rows().data();
            data.each(function (value, index) {
                AssetListReport.push({
                    "Branch": value[0],
                    "Date": value[1],
                    "ItemDescription": value[2],
                    "NetAmount": value[3]
                })
            })

                  $.confirm({
                    title: "Confirmation",
                    content: "Extract record/s?",
                    buttons: {
                        yes: function () {
                            $(".preloader-it").fadeIn(); //show
                            $.post("/CBS/Asset/ExtractAssetListReport", { ReportList: AssetListReport, Category: category })
                                .done(function (data) {
                                    window.location = '/CBS/Asset/Download?fileGuid=' + data.FileGuid + '&filename=' + data.FileName;
                                    $(".preloader-it").fadeOut("slow");
                                    toastr.success("Record successfully Exported.", "Notification");
                                })
                                .fail(function (stat, msg, custom) {
                                    toastr.warning(stat.status + ": " + custom)
                                })
                        },
                        cancel: function () { }
                    }

                })


     

        }
    });

    
});