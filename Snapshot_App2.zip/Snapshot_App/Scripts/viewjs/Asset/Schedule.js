﻿$(document).ready(function () {
    document.getElementById('btnExport').disabled = true;



    var AllowAdd;
    var AllowEdit;
    var AllowDelete;
    var AllowView;
    var AllowPrint;
    var AllowImport
    var AllowExport;
    var AllowPost;
    var AllowUnpost;
    var AllowApprove;

    $.ajax({
        type: "POST",
        url: "/CBS/Common/Permissions",
        success: function (data) {
            data = JSON.parse(data)
            AllowAdd = data[0]["Add"]
            AllowEdit = data[0]["Edit"];
            AllowDelete = data[0]["Delete"];
            AllowView = data[0]["View"];
            AllowPrint = data[0]["Print"];
            AllowImport = data[0]["Import"];
            AllowExport = data[0]["Export"];
            AllowPost = data[0]["Post"];
            AllowUnpost = data[0]["Unpost"];
            AllowApprove = data[0]["Approve"];
        },
        async: false

    })
    //-------------------------------

    function getBool(val) {
        return !!JSON.parse(String(val).toLowerCase());
    }
    //-----------------------------------------------------------------
       
    $.post("/CBS/Common/GetBranch", function (data) {
        data = JSON.parse(data);
        var cboBranchsched = $("#cboBranchsched");
        cboBranchsched.html("");
        $(data).each(function (index, br) {
            cboBranchsched.append('<option value="' + br.Whscode + '">' + br.whsName + '</option>');
        });
    });
    //-----------------------------------------------------------------
    $.post("/CBS/Asset/GetCategory", function (data) {
        data = JSON.parse(data);
        var cboCategorysched = $("#cboCategorysched");
        cboCategorysched.html("");
        $(data).each(function (index, br) {
            cboCategorysched.append('<option value="' + br.CategoryName + '">' + br.CategoryName + '</option>');
        });
        

        var cboCategoryschedEdit = $("#cboCategoryschedEdit", "#Mod-EditSchedule");
        cboCategoryschedEdit.html("");
        $(data).each(function (index, br) {
            cboCategoryschedEdit.append('<option value="' + br.CategoryName + '">' + br.CategoryName + '</option>');
        });

    });
    //-----------------------------------------------------------------
    $.post("/CBS/Common/GetGL", function (data) {
        data = JSON.parse(data);
        var cboGL = $("#cboGL", "#Mod-EditSchedule");
        cboGL.html("");
        $(data).each(function (index, br) {
            cboGL.append('<option value="' + br.GLCode + '">' + br.GLName + '</option>');
        });
    });
    //-----------------------------------------------------------------
    $("#btnLoad").on("click", function () {
        $(".preloader-it").fadeIn(); //show
        $("#tblScheduleHeader tbody tr").remove();
         $("#tblScheduleHeader").DataTable().clear().draw();
         $("#tblScheduleHeader").DataTable().destroy();
         
         var branch = $("#cboBranchsched").val();
         var category = $("#cboCategorysched").val();

         $.post("/CBS/Asset/GetSchedule", { branch: branch, category: category }, function (data) {
             data = JSON.parse(data);
             var tblScheduleBody = $("#tblScheduleBody");
             tblScheduleBody.html("");
             $(data).each(function (i, Asset) {
                 tblScheduleBody.append('<tr>' +
                     '<td>' + Asset.DetailID +'</td>' +
                     '<td>' + Asset.DocEntry + '</td >' +
                     '<td>' + moment(Asset.Date).format("YYYY-MM-DD") + '</td >' +
                     '<td>' + Asset.PO + '</td >' +
                     '<td>' + Asset.AP + ' </td >' +
                     '<td>' + Asset.Vendor + '</td >' +
                     '<td>' + Asset.GLAccount + '</td >' +
                     '<td>' + Asset.GLName + '</td >' +
                     '<td>' + Asset.ItemDescription + '</td >' +
                     '<td>' + Asset.Qty + '</td >' +
                     '<td class="text-right">' + numeral(Asset.UnitPrice).format("0,0.00") + '</td >' +
                     '<td class="text-right">' + numeral(Asset.GrossAmount).format("0,0.00") + '</td >' +
                     '<td class="text-right">' + numeral(Asset.Discount).format("0,0.00") + '</td >' +
                     '<td class="text-right">' + numeral(Asset.NetAmount).format("0,0.00") + '</td >' +
                     '<td align="middle"><button type="button" id="btnEdit" class="btn btn-xs btn-outline-primary btn-rounded" data-id="' + Asset.DetailID + '" data-GLname="' + Asset.GLName + '" data-ItemDescription="' + Asset.ItemDescription + '" ' +
                     'data-ItemDescription="' + Asset.ItemDescription + '" data-Qty="' + Asset.Qty + '" title="Click to Edit" ><i class="fa fa-edit"></i></button >  </td > ' +
                     '</tr>'
                 );
                 
               });
             $("#tblScheduleHeader").DataTable({
                 scrollX: true
             }).draw();

             if (document.querySelectorAll('#tblScheduleHeader tbody tr').length > 1) {
                 document.getElementById('btnExport').disabled = false;
             }
             else
             {
                 document.getElementById('btnExport').disabled = true;
             }


             $(".preloader-it").fadeOut("slow");
         });
       
      });
    //-----------------------------------------------------------------
    $("#tblScheduleHeader").on("click", "#btnEdit", function () {

        if (getBool(AllowEdit) == false) {
            toastr.info("Access Denied!", "Notification");
            return;
        }
        //data-toggle="modal" data-target="#Mod-EditSchedule"
         $("#ID").val($(this).attr("Data-id"))
         $("#ItemDescription").val($(this).attr("data-ItemDescription"))
         $("#Quantity").val($(this).attr("data-Qty"))
         var GLname = $(this).attr("data-GLname");
         
         var cboCategoryschedEdit = $("#cboCategoryschedEdit", "#Mod-EditSchedule");
         cboCategoryschedEdit.val($("#lblCategory").val())
        
         var cboGL = $("#cboGL", "#Mod-EditSchedule");
         cboGL.val(GLname)
         $("#Mod-EditSchedule").modal("show");

      });
    //-----------------------------------------------------------------
    $("#Mod-EditSchedule").on("click", "#btnUpdateScheduleData", function () {
        
      
        var AllowUpdate = true;

        if ($("#ItemDescription").val() == "") {
            toastr.error("Item Description is Required", "Notification");
            AllowUpdate = false;
        }

        else if ($.isNumeric($("#Quantity").val()) == false )
            {
                toastr.error("Invalid Quantity", "Notification");
                AllowUpdate = false;
            }
    
        if (AllowUpdate == true)
            {
            $(".preloader-it").fadeIn(); //show
                var ID = $("#ID").val();
                 var GlName = $("#cboGL").val();
                 var ItemDesc = $("#ItemDescription").val();
                 var Qty = $("#Quantity").val();
                 var Category = $("#cboCategoryschedEdit").val();
               
                 $.post("/CBS/Asset/UpdateSchedule", { ID: ID, GlName: GlName, ItemDesc: ItemDesc, Qty: Qty, Category: Category}, function (data) {
                     data = JSON.parse(data);
                     ReloadSched();
                     $('#Mod-EditSchedule').modal('hide');
                     $(".preloader-it").fadeOut("slow");
                     toastr.success("Record successfully Updated.")
                   });
            }

    });
    //-----------------------------------------------------------------
    function ReloadSched() {
         $("#tblScheduleHeader tbody tr").remove();
         $("#tblScheduleHeader").DataTable().clear().draw();
         $("#tblScheduleHeader").DataTable().destroy();

         var branch = $("#cboBranchsched").val();
         var category = $("#cboCategorysched").val();

         $.post("/CBS/Asset/GetSchedule", { branch: branch, category: category }, function (data) {
             data = JSON.parse(data);
             var tblScheduleBody = $("#tblScheduleBody");
             tblScheduleBody.html("");
             $(data).each(function (i, Asset) {
                 tblScheduleBody.append('<tr>' +
                     '<td>' + Asset.DetailID + '</td>' +
                     '<td>' + Asset.DocEntry + '</td >' +
                     '<td>' + moment(Asset.Date).format("YYYY-MM-DD") + '</td >' +
                     '<td>' + Asset.PO + '</td >' +
                     '<td>' + Asset.AP + ' </td >' +
                     '<td>' + Asset.Vendor + '</td >' +
                     '<td>' + Asset.GLAccount + '</td >' +
                     '<td>' + Asset.GLName + '</td >' +
                     '<td>' + Asset.ItemDescription + '</td >' +
                     '<td>' + Asset.Qty + '</td >' +
                     '<td class="text-right">' + numeral(Asset.UnitPrice).format("0,0.00") + '</td >' +
                     '<td class="text-right">' + numeral(Asset.GrossAmount).format("0,0.00") + '</td >' +
                     '<td class="text-right">' + numeral(Asset.Discount).format("0,0.00") + '</td >' +
                     '<td class="text-right">' + numeral(Asset.NetAmount).format("0,0.00") + '</td >' +
                     '<td><button type="button" id="btnEdit" class="btn btn-xs btn-outline-primary btn-rounded"  data-toggle="modal" data-target="#Mod-EditSchedule" data-id="' + Asset.DetailID + '" data-GLname="' + Asset.GLName + '" data-ItemDescription="' + Asset.ItemDescription + '" ' +
                     'data-ItemDescription="' + Asset.ItemDescription + '" data-Qty="' + Asset.Qty + '" ><i class="fa fa-edit"></i></button >  </td > ' +
                     '</tr>');
             });
             $("#tblScheduleHeader").DataTable().draw();

             if (document.querySelectorAll('#tblScheduleHeader tbody tr').length > 1) {
                 document.getElementById('btnExport').disabled = false;
             }
             else {
                 document.getElementById('btnExport').disabled = true;
             }

         });


     };
    //-----------------------------------------------------------------
    $("#btnExport").on("click", function () {

        if (getBool(AllowExport) == false) {
            toastr.info("Access Denied!", "Notification");
            return;
        }
         var branch = $("#lblBranch").val();
         var category = $("#lblCategory").val();

         var assetdet = [];
         var data = $("#tblScheduleHeader").DataTable().rows().data();
         data.each(function (value, index) {

              assetdet.push({
                 "DocEntry": value[1],
                 "Date": value[2],
                 "PO": value[3],
                 "AP": value[4],
                 "Vendor": value[5],
                 "GLAccount": value[6],
                 "GLName": value[7],
                 "ItemDescription": value[8],
                 "Qty": value[9],
                 "UnitPrice": value[10],
                 "GrossAmount": value[11],
                 "Discount": value[12],
                 "NetAmount": value[13]
             });

         });

         if (assetdet == "[object Object]") {
             toastr.error("No Record/s to Export, Please. Generate First.", "Notification")
         }
         else if (assetdet == "") {
             toastr.error("No Record/s to Export, Please. Generate First.", "Notification")
         }
         else {

             $.confirm({
                 title: "Confirmation",
                 content: "Extract record/s?",
                 buttons: {
                     yes: function () {
                         $(".preloader-it").fadeIn(); //show
                         $.post("/CBS/Asset/Extract", { AssetList: assetdet, Branch: branch, Category: category }, function (data) {
                             window.location = '/CBS/Asset/Download?fileGuid=' + data.FileGuid + '&filename=' + data.FileName;
                             $(".preloader-it").fadeOut("slow");
                             toastr.success("Record successfully Exported.", "Notification");
                         })
                             .fail(function (stat, msg, custom) {
                                 $(".preloader-it").fadeOut("slow");
                                 toastr.warning(stat.status + ": " + custom)
                             })
                     },
                     cancel: function () {

                     }
                 }
             })
         }
     });
    //----
});

