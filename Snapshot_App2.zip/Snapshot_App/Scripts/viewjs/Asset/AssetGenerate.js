﻿$(document).ready(function () {
       $.post("/CBS/Common/GetBranch", function (data) {
            data = JSON.parse(data);
            var cboBranch = $("#cboBranch");
            cboBranch.html("");
            $(data).each(function (index, br) {
                cboBranch.append('<option value="' + br.Whscode + '">' + br.whsName + '</option>');
            });
    });

    
    //-------------------------------------
       $("#btnGenerate").on("click", function () {
           var br = $("#cboBranch").val();
           var sd = $("#dtsd").val();
           var ed = $("#dted").val();

           var AllowGenerate = true;
           if ($("#dtsd").val() == "")
               {
                   toastr.error("Start Date is Required","Notification")
                   AllowGenerate = false;
               }
           else if ($("#dted").val() == "")
               {
               toastr.error("End Date is Required", "Notification")
                   AllowGenerate = false;
               }
           
           if (AllowGenerate == true)
           {
           //function (br, sd, ed) {
           $("#tblasset tbody tr").remove();
           $("#tblasset").DataTable().clear().draw();
           $("#tblasset").DataTable().destroy();

           $(".preloader-it").fadeIn(); //show
           $.post("/CBS/Asset/GetCategory", function (data) {
               data = JSON.parse(data);
               var cboAssCategory="";
               $(data).each(function (index, br) {
                   cboAssCategory += '<option value="' + br.CategoryName + '">' + br.CategoryName + '</option>';
               });

               $.post("/CBS/Asset/GetAssetLists", { branch: br, startDate: sd, endDate: ed }, function (data) {
                   data = JSON.parse(data);
                   var tblassetbody = $("#tblassetbody");
                   tblassetbody.html("");
                   $(data).each(function (index, asset) {
                       tblassetbody.append('<tr>' +
                           '<td>' + asset.DetailID + '</td >' +
                           '<td>' + asset.DocEntry + '</td >' +
                           '<td>' + moment(asset.Date).format("YYYY-MM-DD") + '</td >' +
                           '<td>' + asset.PO + '</td >' +
                           '<td>' + asset.AP + ' </td >' +
                           '<td>' + asset.Vendor + '</td >' +
                           '<td>' + asset.GLAccount + '</td >' +
                           '<td>' + asset.GLName + '</td >' +
                           '<td>' + asset.ItemDescription + '</td >' +
                           '<td>' + asset.Qty + '</td >' +
                           '<td class="text-right">' + numeral(asset.UnitPrice).format("0,0.00") + '</td >' +
                           '<td class="text-right">' + numeral(asset.GrossAmount).format("0,0.00") + '</td >' +
                           '<td class="text-right">' + numeral(asset.Discount).format("0,0.00") + '</td >' +
                           '<td class="text-right">' + numeral(asset.NetAmount).format("0,0.00") + '</td >' +
                           '<td ></td > ' +
                           '<td >' +
                           '<select class="form-control custom-select custom-select-sm mr-15 cboAssCategory" data-detailID =' + asset.DetailID +' >' + cboAssCategory +'</select> ' + 
                           '</td > ' +
                           '</tr>');
                   });

                   $("#tblasset").DataTable().draw();
                   $(".preloader-it").fadeOut("slow");
               });
           });
               
           }
           
       });

       $("#tblassetbody").on("change", ".cboAssCategory", function () {
           var table = $('#tblasset').DataTable();
           table.cell($(this).attr("data-detailID") - 1 , 14, { Category: 'applied' }).data($(this).val());
       })
    
        //-------------------------------------
       $("#btnSave").on("click", function () {
           var br = $("#cboBranch").val();
           var sd = $("#dtsd").val();
           var ed = $("#dted").val();
      

           var assetdet = [];
           var data = $("#tblasset").DataTable().rows().data();
           data.each(function (value, index) {

               assetdet.push({
                   "DocEntry": value[1],
                   "Date": value[2],
                   "PO": value[3],
                   "AP": value[4],
                   "Vendor": value[5],
                   "GLAccount": value[6],
                   "GLName": value[7],
                   "ItemDescription": value[8],
                   "Qty": value[9],
                   "UnitPrice": value[10],
                   "GrossAmount": value[11],
                   "Discount": value[12],
                   "NetAmount": value[13],
                   "Category": value[14]
                   
               })
               
           })

           if (assetdet == "[object Object]") {
               toastr.warning("No Record/s to Save, Please. Generate First.", "Notification")
           }
           else if (assetdet == "") {
               toastr.warning("No Record/s to Save, Please. Generate First.", "Notification")
           }
           else
           {
               
               $.confirm({
                   title: "Confirmation",
                   content: "Save Records?",
                   buttons: {
                       yes: function () {
                           $(".preloader-it").fadeIn(); //show
                           $.post("/CBS/Asset/SaveAssetDet", { AssetDet: assetdet, Branch: br, StartDate: sd, EndDate: ed })
                               .done(function () {
                                  $(".preloader-it").fadeOut("slow"); 
                                   toastr.success("Record Successfully Saved!", "Notification");
                               })
                               .fail(function (stat, msg, custom) {
                                   $(".preloader-it").fadeOut("slow"); 
                                   toastr.info(stat.status + ": " + custom)
                               })

                       },
                       no: function () { }
                   }

               })
              
           }
           
       });
    
});
