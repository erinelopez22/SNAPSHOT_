﻿$(document).ready(function () {

    $.post("/CBS/Common/GetMonths", function (data) {
        data = JSON.parse(data);
        var cboMonth_D = $("#cboMonth_D");
        cboMonth_D.html("");
        $(data).each(function (index, br) {
            cboMonth_D.append('<option value="' + br.MonthNum + '">' + br.MonthName + '</option>');
        });
    });

    //-------------------------------------------------
        function GetMonth(monthno) {
            var month = new Array();
            month[0] = "January";
            month[1] = "February";
            month[2] = "March";
            month[3] = "April";
            month[4] = "May";
            month[5] = "June";
            month[6] = "July";
            month[7] = "August";
            month[8] = "September";
            month[9] = "October";
            month[10] = "November";
            month[11] = "December";
     
            return month[monthno];
    }
    
    //-------------------------------------------------
 
    //-------------------------------------------------
    
        function LoadDashboard(m, y) {

            $("#tblDashboardHeader tbody tr").remove();
            $("#tblDashboardHeader").DataTable().clear().draw();
            $("#tblDashboardHeader").DataTable().destroy();

            $.post("/CBS/Asset/LoadDashboard", { month: m, year: y }, function (data) {
                data = JSON.parse(data);
                var tblDashboardBody = $("#tblDashboardBody");
                tblDashboardBody.html("");

                var today = new Date();
                var year = today.getFullYear();
                var n; 
                if (m == 0) { n = today.getMonth(); } else { n = (m - 1); }
                if (y == 0) { year = today.getFullYear(); } else { year = y  }
                
                $('#DashboardPeriod').text(GetMonth(n).toUpperCase() + " " + year);
                              

                var badge_CSH;
                var badge_FF;
                var badge_TE;
                var badge_LIS;
                var badge_LIDE;
                var badge_BUILD;
                var badge_EO;


                $(data).each(function (i, asset) {

                    if (asset.CSH == "Ok") { badge_CSH = "badge badge-success"; } else { badge_CSH = ""; }
                    if (asset.FF == "Ok") { badge_FF = "badge badge-success"; } else { badge_FF = ""; }
                    if (asset.TE == "Ok") { badge_TE = "badge badge-success"; } else { badge_TE = ""; }
                    if (asset.LIS == "Ok") { badge_LIS = "badge badge-success"; } else { badge_LIS = ""; }
                    if (asset.LIDE == "Ok") { badge_LIDE = "badge badge-success"; } else { badge_LIDE = ""; }
                    if (asset.BUILD == "Ok") { badge_BUILD = "badge badge-success"; } else { badge_BUILD = ""; }
                    if (asset.EO == "Ok") { badge_EO = "badge badge-success"; } else { badge_EO = ""; }


                    tblDashboardBody.append('<tr>' +
                                 '<td >' + asset.Branch + '</td>' +
                                 '<td ><span class="' + badge_CSH + '">' + asset.CSH + '</span></td>' +
                                 '<td ><span class="' + badge_FF + '">' + asset.FF + '</span></td>' +
                                 '<td ><span class="' + badge_TE + '">' + asset.TE + '</span></td>' +
                                 '<td ><span class="' + badge_LIS + '">' + asset.LIS + '</span></td>' +
                                 '<td ><span class="' + badge_LIDE + '">' + asset.LIDE + '</span></td>' +
                                 '<td ><span class="' + badge_BUILD + '">' + asset.BUILD + '</span></td>' +
                                 '<td ><span class="' + badge_EO + '">' + asset.EO + '</span></td>' +
                                 '</tr>'
                        );

                });

                $("#tblDashboardHeader").DataTable().draw();
                
            });
        };
    //-------------------------------------------------
        LoadDashboard(0, 0);
    //-------------------------------------------------
         $("#Modal-GenerateDashboard").on("click", "#btnGenerate_D", function () {

             var Month = $("#cboMonth_D").val();
             var year = $("#txtyear_D").val();

             if (year == "")
             {
                 toastr.info("Year is Required","Notification")
             }
             else
             {
                 $('#DashboardPeriod').text(GetMonth(Month - 1).toUpperCase() + " " + year);
                 LoadDashboard(Month, year);
             }
          


         });
});
//function isNumberKey(evt) {
//    var charCode = (evt.which) ? evt.which : evt.keyCode;
//    if (charCode != 46 && charCode > 31
//        && (charCode < 48 || charCode > 57)) {
//        return false;
//    }
//    else {
//        return true;
//    }

//}