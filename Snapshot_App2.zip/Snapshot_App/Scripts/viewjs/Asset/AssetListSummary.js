﻿$(document).ready(function () {
    //------------------------------------------------------------------------------------
    var x = document.getElementById('lblNEW_AS');
    x.style.visibility = 'hidden';
    document.getElementById('btnSave_ALS').disabled = true;
    document.getElementById('btnExport_ALS').disabled = true;
    document.getElementById('btnConsolidate_ALS').disabled = true;

        //-----------------------------------------------------------------
    var AllowAdd;
    var AllowEdit;
    var AllowDelete;
    var AllowView;
    var AllowPrint;
    var AllowImport
    var AllowExport;
    var AllowPost;
    var AllowUnpost;
    var AllowApprove;
        //-----------------------------------------------------------------
    $.ajax({
        type: "POST",
        url: "/CBS/Common/Permissions",
        success: function (data) {
            data = JSON.parse(data)
            AllowAdd = data[0]["Add"]
            AllowEdit = data[0]["Edit"];
            AllowDelete = data[0]["Delete"];
            AllowView = data[0]["View"];
            AllowPrint = data[0]["Print"];
            AllowImport = data[0]["Import"];
            AllowExport = data[0]["Export"];
            AllowPost = data[0]["Post"];
            AllowUnpost = data[0]["Unpost"];
            AllowApprove = data[0]["Approve"];
        },
        async: false

    })
    //-------------------------------

    function getBool(val) {
        return !!JSON.parse(String(val).toLowerCase());
    }
    //-----------------------------------------------------------------
    
    $.post("/CBS/Common/GetMonths", function (data) {
        data = JSON.parse(data);
        var cboMonth_ALS = $("#cboMonth_ALS");
        cboMonth_ALS.html("");
        $(data).each(function (index, br) {
            cboMonth_ALS.append('<option value="' + br.MonthNum + '">' + br.MonthName + '</option>');
        });
    });
    //-----------------------------------------------------------------
    var Load = function () {
        var mo = $("#cboMonth_ALS").val();
        var yr = $("#txtyear_ALS").val();
        var totalrowcolor;

        if (yr == "") {
            toastr.error("Year is Required", "Notification");
        }
        else if ($.isNumeric(yr) == false) {
            toastr.error("Invalid Year", "Notification");
        }

        else if (yr.length != 4) {
            toastr.error("Invalid Year", "Notification");

        }
        else {

            $(".preloader-it").fadeIn(); //show
            var IsExist
            $.post("/CBS/Asset/checkActualPurchasesifExisit", { month: mo, year: yr}, function (data) {
                IsExist = data.result;
            })

            
            $("#tblALSHeader").DataTable().clear().draw().destroy();
            $.post("/CBS/Asset/GenerateActualPurchases", { month: mo, year: yr })
                .done(function (data) {
                    data = JSON.parse(data);
                    var tblALSBody = $("#tblALSBody");
                    tblALSBody.html("");

                    $(data).each(function (i, asset) {

                        if (asset.Branch.match("GRAND TOTAL")) {
                            totalrowcolor = "background-color: #616460;color: white;font-size: 12px;font-weight: bold;"
                        }
                        else if (asset.Branch.match("TOTAL")) {
                            totalrowcolor = "background-color: #61646094;color: white;font-size: 12px;font-weight: bold;"
                        }

                        tblALSBody.append('<tr style="' + totalrowcolor + '"  >' +
                            '<td>' + asset.Branch + '</td>' +
                            '<td class="text-right">' + numeral(asset.CSH).format("0,0.00") + '</td>' +
                            '<td class="text-right">' + numeral(asset.FF).format("0,0.00") + '</td>' +
                            '<td class="text-right">' + numeral(asset.TE).format("0,0.00") + '</td>' +
                            '<td class="text-right">' + numeral(asset.LIS).format("0,0.00") + '</td>' +
                            '<td class="text-right">' + numeral(asset.LIDE).format("0,0.00") + '</td>' +
                            '<td class="text-right">' + numeral(asset.BUILD).format("0,0.00") + '</td>' +
                            '<td class="text-right">' + numeral(asset.Total).format("0,0.00") + '</td>' +
                            '</tr>')

                    });

                    //console.log($("#tblALSHeader").DataTable().rows().any())

                    $("#tblALSHeader").DataTable({
                        ordering: false
                    }).draw();



                    //{
                    //    ordering: false
                    //}

                        if ($("#tblALSHeader").DataTable().rows().any() == true)
                        {
                        if (IsExist == 0) {
                          
                            document.getElementById('lblNEW_AS').style.visibility = 'visible';
                            document.getElementById('btnSave_ALS').disabled = false;
                            document.getElementById('btnExport_ALS').disabled = false;
                            document.getElementById('btnConsolidate_ALS').disabled = true;
                        }
                        else {
                            document.getElementById('lblNEW_AS').style.visibility = 'hidden';
                            document.getElementById('btnSave_ALS').disabled = true;
                            document.getElementById('btnExport_ALS').disabled = false;
                            document.getElementById('btnConsolidate_ALS').disabled = false;
                        }
                    }
                    else
                    {
                           document.getElementById('btnSave_ALS').disabled = true;
                           document.getElementById('btnExport_ALS').disabled = true;
                           document.getElementById('btnConsolidate_ALS').disabled = true;
                           document.getElementById('lblNEW_AS').style.visibility = 'hidden';
                           
                    }

                    $(".preloader-it").fadeOut("slow");
                })
                .fail(function (stat, msg, custom) {
                    document.getElementById('btnSave_ALS').disabled = true;
                    document.getElementById('btnExport_ALS').disabled = true;
                    document.getElementById('btnConsolidate_ALS').disabled = true;
                    document.getElementById('lblNEW_AS').style.visibility = 'hidden';
                    $(".preloader-it").fadeOut("slow");
                    toastr.warning(stat.status + ": " + custom)
                })

        }
    }
    //------------------------------------------------------------------------------------
    $("#btnLoad_ALS").on("click", function () {
        Load();
    });

    //--------Save
    $("#btnSave_ALS").on("click", function () {

        if (getBool(AllowAdd) == false) {
            toastr.info("Access Denied!", "Notification");
            return;
        }



        var mo = $("#cboMonth_ALS").val();
        var yr = $("#txtyear_ALS").val();

        $.confirm({
            title: "Confirmation",
            content: "Save Records?",
            buttons: {
                yes: function () {
                    $(".preloader-it").fadeIn(); 
                    var ActualPurchases = [];
                    var data = $("#tblALSHeader").DataTable().rows().data();
                    data.each(function (value,index) {
                           ActualPurchases.push({
                                "Branch": value[0],
                                "CSH": value[1],
                                "FF": value[2],
                                "TE": value[3],
                                "LIS": value[4],
                                "LIDE": value[5],
                                "BUILD": value[6],
                                "Total": value[7],
                            });
                        
                    });

                    $.post("/CBS/Asset/SaveActualPurchases", { ActualPurchases: ActualPurchases, month: mo, year:yr})
                        .done(function () {
                            Load();
                            $(".preloader-it").fadeOut("slow");
                            toastr.success("Record Successfully Saved!", "Notification");
                        })
                        .fail(function (stat, msg, custom) {
                            $(".preloader-it").fadeOut("slow");
                            toastr.info(stat.status + ": " + custom)
                        })
                            
                },
                no: function () { }

            }
            
        });


    });

    //--- Extract to Excel
    $("#btnExport_ALS").on("click", function () {

        if (getBool(AllowExport) == false) {
            toastr.info("Access Denied!", "Notification");
            return;
        }


        var mo = $("#cboMonth_ALS").val();
        var yr = $("#txtyear_ALS").val();
        var ActualPurchases = [];

        var data = $("#tblALSHeader").DataTable().rows().data();
        data.each(function (value, index) {

            ActualPurchases.push({
                "Branch": value[0],
                "CSH": value[1],
                "FF": value[2],
                "TE": value[3],
                "LIS": value[4],
                "LIDE": value[5],
                "BUILD": value[6],
                "Total": value[7]
            });

        });

        if (ActualPurchases == "[object Object]") {
            toastr.error("No Record/s to Export, Please. Generate First.", "Notification")
        }
        else if (ActualPurchases == "") {
            toastr.error("No Record/s to Export, Please. Generate First.", "Notification")
        }
        else {

            $.confirm({
                title: "Confirmation",
                content: "Extract Records?",
                buttons: {
                    yes: function () {
                        $(".preloader-it").fadeIn(); //show
                       
                        $.post("/CBS/Asset/ExtractActualPurchases", { ActualPurches: ActualPurchases, month: mo, year: yr })
                            .done(function (data) {
                                window.location = '/CBS/Asset/Download?fileGuid=' + data.FileGuid + '&filename=' + data.FileName;
                                $(".preloader-it").fadeOut("slow");
                                toastr.success("Record successfully Exported.", "Notification");
                            })
                            .fail(function (stat, msg, custom) {
                                $(".preloader-it").fadeOut("slow");
                                toastr.info(stat.status + ": " + custom)
                            })

                    },
                    no: function () { }

                }


            });

        }
        

    });

    $("#btnConsolidate_ALS").on("click", function () {

        if (getBool(AllowExport) == false) {
            toastr.info("Access Denied!", "Notification");
            return;
        }

        var mo = $("#cboMonth_ALS").val();
        var yr = $("#txtyear_ALS").val();

        $.confirm({
            title: "Confirmation",
            content: "Generate Consolidated?",
            buttons: {
                yes: function () {
                    $(".preloader-it").fadeIn(); //show
                    $.post("/CBS/Asset/GenerateCosolidated", { month: mo, year:yr })
                        .done(function (data) {
                            window.location = '/CBS/Asset/Download?fileGuid=' + data.FileGuid + '&filename=' + data.FileName;
                            $(".preloader-it").fadeOut("slow");
                            toastr.success("Record successfully Exported.", "Notification");
                        })
                        .fail(function (stat, msg, custom) {
                            $(".preloader-it").fadeOut("slow");
                            toastr.info(stat.status + ": " + custom)
                        })
                    
                },
                no: function(){}

            }

        })


    });

});