﻿function getBool(val) {
    return !!JSON.parse(String(val).toLowerCase());
}

    function AllowAdd(btnID)
    {
        console.log(btnID);
        $.post("/CBS/Common/AllowAdd")
         .done(function (data) {
             return getBool(data);
             
            })
            .fail(function (stat, msg, custom) {

                document.getElementById(btnID).addEventListener("click", function (event) {
                    event.preventDefault()
                });
                
            toastr.warning(stat.status + ": " + custom)

        });
    }
