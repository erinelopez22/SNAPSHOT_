﻿$(function () {
    console.log("awitdsadas");
   
        $(document).on("click", "#refff", function (e) {
            e.preventDefault()
            
            window.location.replace("/Login/Index");
            //window.location.replace("/NEW_TEMPLATE/main/Index")
          
        });
        //=======================================================
        function GetWebUser() {

           
            console.log("awitdsadas");
            $.post("/Snp_Report/GetWebUsers")
                .done(function (data) {
                    console.log(data);
                    var a = document.getElementById("UserFname");
                    a.value = data

                })
                .fail(function (stat, msg, custom) {
                    console.log("awitdsadas4");
                    toastr.warning(stat.status + ": " + custom)
                });
        }
        //-----------------------------------------------------------------
        GetWebUser();
    });


