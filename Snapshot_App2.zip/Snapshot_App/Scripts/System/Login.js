﻿
$(function () {

    $("#LogIn").on("click", function (e) {
        e.preventDefault()

        var user = $("#L_Uname").val();
        var pass = $("#L_Pass").val();
        console.log(user + "__" + pass)
        Login(user, pass)


    });

    //events------------------------
    function Login(user, pass) {
        console.log(user + "__" + pass)
        if (user == "") {
            toastr.info("Username is required", "Notification")
            document.getElementById("username").focus();
        }
        else if (pass == "") {
            toastr.info("Password is required", "Notification")
            document.getElementById("password").focus();
        }
        else {
            $.post("/Login/Login", { Username: user, Password: pass })
               .done(function (response) {
                   alert("Succesfuly Logged In");
                   $(".preloader-it").fadeIn(); //show
                   window.location.replace("/Snp_Report/Index");
                   $(".preloader-it").fadeOut("slow");
               })
               .fail(function (stat, msg, custom) {
                   //console.log("12312312");
                   //$(".preloader-it").fadeOut("slow");
                   //toastr.warning(stat.status + ": " + custom)
                   alert("Invalid Username or Password");
                   
               })
        }

    }
    
})


