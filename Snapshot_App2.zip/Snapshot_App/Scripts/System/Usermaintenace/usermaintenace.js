﻿$(document).ready(function () {

    GetWebUser();
function GetWebUser() {

    $("#tblUser_Header tbody tr").remove();
    $("#tblUser_Header").DataTable().clear().draw();
    $("#tblUser_Header").DataTable().destroy();
   

    $.post("/UserMain/GetWebUsers")
        .done(function (data) {
            
            data = JSON.parse(data);
            var tblUser_Body = $("#tblUser_Body");
            tblUser_Body.html("");
            var IsCheck = "";
            var IsCheck1 = "";
           
            $(data).each(function (i, UserInfo) {
                if (UserInfo.V_Rights == "True") { IsCheck = "checked"; } else { IsCheck= ""; }
                if (UserInfo.U_Rights == "True") { IsCheck1 = "checked"; } else { IsCheck1 = ""; }
                
                tblUser_Body.append('<tr>' +
                    '<td>' + UserInfo.EmpID + '</td>' +
                    '<td>' + UserInfo.EmpName + '</td>' +
                   
                    '<td align="left">' +
                     '<div class="blue-square-container">' +
                    '<div class="custom-control custom-checkbox blue-square">' +
                    '<input type="checkbox" class="custom-control-input" id="ViewRights_' + UserInfo.EmpID + '" ' + IsCheck + '>' +
                    '<label class="custom-control-label" for="ViewRights_' + UserInfo.EmpID + '">View</label>' +
                     '</div>' +
                    '</div>' +
                    '</td>' +

                    '<td align="center">' +
                    '<div class=" blue-square-container">' +
                    '<div class="custom-control custom-checkbox blue-square">' +
                    '<input type="checkbox" class="custom-control-input" id="UpdateRights_' + UserInfo.EmpID + '" ' + IsCheck1 + '>' +
                    '<label class="custom-control-label" for="UpdateRights_' + UserInfo.EmpID + '">Update</label>' +
                      '</div>' +
                    '</div>' +
                    '</td>' +
               '</tr>')
               
            });

            

        })
        .fail(function (stat, msg, custom) {
            console.log("awitdsadas4");
            toastr.warning(stat.status + ": " + custom)
        });
}
    //-----------------------------------------------------------------
UserAccess();
function UserAccess() {
    $.post("/UserMain/UserAccess")
        .done(function (data) {

            data = JSON.parse(data);
            

            $(data).each(function (i, UserInfo1) {
              
                $("#UserFname").html(UserInfo1.Empname);
                $("#UserType").html(UserInfo1.UserType);
            });
        })
        .fail(function (stat, msg, custom) {
          
        });
}
UserAccess2();
function UserAccess2() {
    $.post("/Snp_Report/UserAccess")
        .done(function (data) {

            data = JSON.parse(data);


            $(data).each(function (i, UserInfo1) {
               
                $("#UserFname").html(UserInfo1.Empname);
                $("#UserType").html(UserInfo1.UserType);
            });
        })
        .fail(function (stat, msg, custom) {
         
        });
}
    //-----------------------------------------------------------------
    //----------------------Add User----------------------------------


$("#btnNewUser").on("click", function () {
    
    window.location.replace("/AddUser/Index");
})
    //-----------------------update user
$("#btnUpdateUser").on("click", function () {
    var forRemarksUpdate = []
    var oTable = $("#tblUser_Header").DataTable();
   
    var U_Rigths_ = '';
    var V_Rights_ = '';
    oTable.rows().every(function (index, element) {
        var row = $(this.node());
        
        var data = this.data();
        
        var ViewRights_ =$("#ViewRights_" + data[0]).prop('checked');
        var UpdateRights_ = $("#UpdateRights_" + data[0]).prop('checked');
     
        if ($("#ViewRights_" + data[0]).prop('checked') == true) {
            if ($("#UpdateRights_" + data[0]).prop('checked') == true) { V_Rights_ = '1'; U_Rigths_ = '1'; }
            else { V_Rights_ = '1'; U_Rigths_ = '0'; }
        }
        else {
            if ($("#UpdateRights_" + data[0]).prop('checked') == true) { V_Rights_ = '0'; U_Rigths_ = '1'; }
            else { V_Rights_ = '0'; U_Rigths_ = '0'; }
        }
        forRemarksUpdate.push({
            EmpID: data[0],
            EmpName: data[1],
            V_Rights: V_Rights_,
            U_Rights: U_Rigths_
            
        });
        
        console.log(data[0] + "  " + data[1] + "  " + V_Rights_ + "  " + U_Rigths_ + "  ");
    });

    $.post("/UserMain/UpdateWebUsers", { erine: forRemarksUpdate })
       .done(function () {
           console.log("aa");
           var currDate = new Date();
           var asOfDate = ConvertDate(currDate);
           LoadLoaUncheck(asOfDate);
           toastr.success("Succesfully added remarks to selected data.");

       })
            .fail(function (stat, msg, custom) {
                console.log("gg");
                toastr.warning("Error, Please contact your system administrator");
            })
})


});