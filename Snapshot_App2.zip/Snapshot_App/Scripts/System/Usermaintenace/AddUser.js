﻿$(function ()
{
    cboUser_U
    cboUserType_U
    UserAccess();
    function UserAccess() {
        $.post("/AddUser/UserAccess")
            .done(function (data) {

                data = JSON.parse(data);


                $(data).each(function (i, UserInfo1) {
                    console.log("33333333");
                    console.log(UserInfo1.Empname);
                    $("#UserFname").html(UserInfo1.Empname);
                    $("#UserType").html(UserInfo1.UserType);
                    
                });
            })
            .fail(function (stat, msg, custom) {
                console.log("8888");
            });
    }
    GetWebUser();
    function GetWebUser() {
        document.getElementById("AddPanel").style.display = "none";
         console.log('hide');
    }
    LoadDropDown();

    //=======================LOAD USER=========================
    function LoadDropDown(Param) {
        $.post('/AddUser/PopulateDropdow')
            .done(function (data) {
                data = JSON.parse(data);
                var cboUser_U = $('#cboUser_U');
                cboUser_U.html('');
                cboUser_U.append('<option value="0"> -- Select User -- </option>');
                $(data).each(function (i, row) {
                    cboUser_U.append('<option value="' + row.UserID + '">' + row.FName + '</option>');
                });
            })
            .fail(function (stat, msg, custom) {

            });
    }
    
    $("#cboUser_U").on("change", function () {

        $("#txtUserID_U").val($("#cboUser_U option:selected").val());
    });
    LoadUsrType();
    //=======================LOAD USER TYPE=========================
    function LoadUsrType(Param) {
        $.post('/AddUser/GetUserType')
            .done(function (data) {
                console.log('asdadasdasd');
                data = JSON.parse(data);
                var cboUserType_U = $('#cboUserType_U');
                cboUserType_U.html('');
                cboUserType_U.append('<option value="0"> -- Select User Type -- </option>');
                $(data).each(function (i, row) {
                    cboUserType_U.append('<option value="' + row.UserID + '">' + row.UserType + '</option>');
                });
                
            })
            .fail(function (stat, msg, custom) {

            });
    }
   
    $("#cboUserType_U").on("change", function () {

        var typeCd = $("#cboUserType_U option:selected").val();
        if (typeCd == 1)
        {
            document.getElementById("ViewR").innerHTML = "&#10004;";
            document.getElementById("UpdateR").innerHTML = "&#10004;";
        }
        else if (typeCd == 12)
        {
            document.getElementById("ViewR").innerHTML = "&#10004;";
            document.getElementById("UpdateR").innerHTML = "";
        }
    });

    //=======================Cancel Adding Records=========================
    $("#btnCancelUser").on("click", function () {

    document.getElementById("AddPanel").style.display = "none";
    console.log('Unhide');
    });
    //=======================Adding Records=========================
    $("#btnAddUser").on("click", function () {
        var forRemarksUpdate = [];
        var forRemarksUpdate2 = [];
        var oTable = $("#tblAddUser_Header").DataTable();
        console.log(oTable.rows().count());
        var e = document.getElementById("cboUser_U");
        var UserID = e.options[e.selectedIndex].value;
        var FullName = e.options[e.selectedIndex].text;
        var e2 = document.getElementById("cboUserType_U");
        var UserID2 = e2.options[e2.selectedIndex].value;
        var FullName2 = e2.options[e2.selectedIndex].text;
        var UA_Rigths_ = '';
        var VA_Rights_ = '';
        var U_Rigths_ = '';
        var V_Rights_ = '';
        var UserType = '';
        var UserType_ = '12';
        var _UserType = '';
        var cnt = '0';

        var vr=document.getElementById("ViewR").innerText;
        var ur = document.getElementById("UpdateR").innerText;
        
        

        if (UserID == "0") {
            toastr.info("User is required", "Notification")
            document.getElementById("cboUser_U").focus();
        }
        else if (UserID2 == "0") {
            
            toastr.info("User Type is required", "Notification")
            document.getElementById("cboUserType_U").focus();
        }
        else {
            console.log(vr);
            console.log(ur);
            
            if (vr == "✔") { VA_Rights_ = '1'; }
            else { VA_Rights_ = '0'; }
            if (ur == "✔") { UA_Rigths_ = '1'; }
            else { UA_Rigths_ = '0'; }
            if (VA_Rights_ == '1' && UA_Rigths_ == '1') { UserType_ = '1' }
            console.log(vr + "___" + VA_Rights_);
            console.log(ur+ "___" + UA_Rigths_);
            document.getElementById("AddPanel").style.display = "block";
            console.log(oTable.rows().count());
            console.log('Unhideww');
            //=======================get all data in tblBody==================================
            oTable.rows().every(function (index, element) {
                console.log('Unhide3333');
                var row = $(this.node());

                var data = this.data();
                if (UserID == data[0]) {
                    cnt = '1';
                    
                }
                


                    var ViewRights_ = $("#ViewRights_" + data[0]).prop('checked');
                    var UpdateRights_ = $("#UpdateRights_" + data[0]).prop('checked');
                    console.log(ViewRights_)
                    if ($("#ViewRights_" + data[0]).prop('checked') == true) {
                        if ($("#UpdateRights_" + data[0]).prop('checked') == true) { V_Rights_ = '1'; U_Rigths_ = '1'; _UserType = '1'; }
                        else { V_Rights_ = '1'; U_Rigths_ = '0'; _UserType = '12'; }
                    }
                    else {
                        if ($("#UpdateRights_" + data[0]).prop('checked') == true) { V_Rights_ = '0'; U_Rigths_ = '1'; _UserType = '12'; }
                        else { V_Rights_ = '0'; U_Rigths_ = '0'; _UserType = '12'; }
                    }
                    console.log(data[0] + "___" + data[1] + "___" + V_Rights_ + "___" + U_Rigths_);
                    forRemarksUpdate.push({
                        EmpID: data[0],
                        EmpName: data[1],
                        V_Rights: V_Rights_,
                        U_Rights: U_Rigths_,
                        UserType: _UserType,
                    });
                


            });
            if(cnt=="0"){
                forRemarksUpdate2.push({
                    EmpID: UserID,
                    EmpName: FullName,
                    V_Rights: VA_Rights_,
                    U_Rights: UA_Rigths_,
                    UserType: UserType_,
                });
                }
                else{toastr.info("User was already added on the list", "Notification")
                document.getElementById("cboUser_U").focus();
            }
           
        
        //$("#tblAddUser_Header").DataTable().clear().draw().destroy();
        //=====================================All data sends to Code behind==========================
        $.post("/AddUser/AddWebUsers", { Tbldata: forRemarksUpdate, Additonaldata: forRemarksUpdate2 })
           .done(function (data) {
               data = JSON.parse(data);
               //var tableBody = $("#tblAddUser_Header");
               $("#tblAddUser_Header").DataTable().clear().draw().destroy();
               //tableBody.html("");
               var tblUser_Body = $("#tblAddUser_Body");

               //tblUser_Body.html("");
               var IsCheck = "";
               var IsCheck1 = "";
               console.log("awitdsadas222");
               $(data).each(function (i, UserInfo) {
                   if (UserInfo.V_Rights == "1") { IsCheck = "checked"; } else { IsCheck = ""; }
                   if (UserInfo.U_Rights == "1") { IsCheck1 = "checked"; } else { IsCheck1 = ""; }

                   tblUser_Body.append('<tr>' +
                       '<td>' + UserInfo.EmpID + '</td>' +
                       '<td>' + UserInfo.EmpName + '</td>' +

                       '<td align="center">' +
                        '<div class="blue-square-container">' +
                       '<div class="custom-control custom-checkbox blue-square">' +
                       '<input type="checkbox" class="custom-control-input" id="ViewRights_' + UserInfo.EmpID + '" ' + IsCheck + '>' +
                       '<label class="custom-control-label" for="ViewRights_' + UserInfo.EmpID + '">View</label>' +
                        '</div>' +
                       '</div>' +
                       '</td>' +

                       '<td align="center">' +
                       '<div class=" blue-square-container">' +
                       '<div class="custom-control custom-checkbox blue-square">' +
                       '<input type="checkbox" class="custom-control-input" id="UpdateRights_' + UserInfo.EmpID + '" ' + IsCheck1 + '>' +
                       '<label class="custom-control-label" for="UpdateRights_' + UserInfo.EmpID + '">Update</label>' +
                         '</div>' +
                       '</div>' +
                       '</td>' +
                  '</tr>')


               });
               //$("#tblAddUser_Header").DataTable().draw(false);
               })
                .fail(function (stat, msg, custom) {
                    console.log("gg");
                    toastr.warning("Error, Please contact your system administrator");
                });

            }

    });

    $("#btnSaveUser").on("click", function () {
        

        SaveUser();

    });
    function SaveUser() {
        var forRemarksUpdate = [];
        var forRemarksUpdate2 = [];
        var oTable = $("#tblAddUser_Header").DataTable();
        console.log(oTable.rows().count());
        var e = document.getElementById("cboUser_U");
        var UserID = e.options[e.selectedIndex].value;
        var FullName = e.options[e.selectedIndex].text;
        var UA_Rigths_ = '';
        var VA_Rights_ = '';
        var U_Rigths_ = '';
        var V_Rights_ = '';
        var UserType = '';
        var UserType_ = '12';
        var _UserType = '';
        var oTable = $("#tblAddUser_Header").DataTable();
        console.log('BBB');
        oTable.rows().every(function (index, element) {
            console.log('Unhide3333');
            var row = $(this.node());

            var data = this.data();

            var ViewRights_ = $("#ViewRights_" + data[0]).prop('checked');
            var UpdateRights_ = $("#UpdateRights_" + data[0]).prop('checked');
            console.log(ViewRights_)
            if ($("#ViewRights_" + data[0]).prop('checked') == true) {
                if ($("#UpdateRights_" + data[0]).prop('checked') == true) { V_Rights_ = '1'; U_Rigths_ = '1'; _UserType = '1'; }
                else { V_Rights_ = '1'; U_Rigths_ = '0'; _UserType = '12'; }
            }
            else {
                if ($("#UpdateRights_" + data[0]).prop('checked') == true) { V_Rights_ = '0'; U_Rigths_ = '1'; _UserType = '12'; }
                else { V_Rights_ = '0'; U_Rigths_ = '0'; _UserType = '12'; }
            }
            console.log(data[0] + "___" + data[1] + "___" + V_Rights_ + "___" + U_Rigths_);
            forRemarksUpdate.push({
                EmpID: data[0],
                EmpName: data[1],
                V_Rights: V_Rights_,
                U_Rights: U_Rigths_,
                UserType: _UserType,
            });


        });
        console.log('AAA');
        $.post("/AddUser/SaveUsers", { AddTemp: forRemarksUpdate })
            .done(function (data) {
                data = JSON.parse(data);
                if(data=="Success"){alert("Successfuly added")}
                else { alert(data) }
            })
            .fail(function (stat, msg, custom) {
                console.log("awitdsadas4");
                toastr.warning(stat.status + ": " + custom)
            });
    }
})
   