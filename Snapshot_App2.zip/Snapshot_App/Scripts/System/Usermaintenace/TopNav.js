﻿$(function () {
function openwindow() {
    console.log("AA2222");
    window.location.replace("/UserMain/Index");
}
})
