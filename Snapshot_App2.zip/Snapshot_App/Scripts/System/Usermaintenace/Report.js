﻿$(function () {

    UserAccess();
    function UserAccess() {
        $.post("/Report/UserAccess")
            .done(function (data) {

                data = JSON.parse(data);


                $(data).each(function (i, UserInfo1) {
                    console.log("33333333");
                    console.log(UserInfo1.Empname);
                    $("#UserFname").html(UserInfo1.Empname);
                    $("#UserType").html(UserInfo1.UserType);
                });
            })
            .fail(function (stat, msg, custom) {
                console.log("8888");
            });
    }

  

    //=======================LOAD USER=========================



    //=======================Cancel Adding Records=========================


})

