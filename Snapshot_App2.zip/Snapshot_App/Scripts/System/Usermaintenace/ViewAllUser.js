﻿$(document).ready(function () {

    GetWebUser();
    function GetWebUser() {

        $("#tblUser_Header tbody tr").remove();
        $("#tblUser_Header").DataTable().clear().draw();
        $("#tblUser_Header").DataTable().destroy();
        console.log("awitdsadas");

        $.post("/ViewAllUser/GetWebUsers")
            .done(function (data) {

                data = JSON.parse(data);
                var tblUser_Body = $("#tblUser_Body");
                tblUser_Body.html("");
                var IsCheck = "";
                var IsCheck1 = "";
                console.log("awitdsadas222");
                $(data).each(function (i, UserInfo) {
                    //if (UserInfo.V_Rights == "False") { IsCheck = "hidde"; } else { IsCheck = ""; }
                    //if (UserInfo.U_Rights == "False") { IsCheck1 = "hidde"; } else { IsCheck1 = ""; }
                    if (UserInfo.V_Rights == "True") { IsCheck = "checked"; } else { IsCheck = ""; }
                    if (UserInfo.U_Rights == "True") { IsCheck1 = "checked"; } else { IsCheck1 = ""; }
                    console.log(UserInfo.EmpID + "___" + UserInfo.EmpName + "____" + UserInfo.V_Rights + "____" + UserInfo.U_Rights);
                    tblUser_Body.append('<tr>' +
                        '<td>' + UserInfo.EmpID + '</td>' +
                        '<td>' + UserInfo.EmpName + '</td>' +
                        //'<td style="text-align: center;vertical-align: middle;"><span style="font- size:100px;"' + IsActive +
                        //'>&#10004;</span><label class="custom-control-label" for="ViewRights_' + UserInfo.EmpID + '">View</label></td>' +
                        //'<td style="text-align: center;vertical-align: middle;"><span style="font- size:100px;"' + IsActive +
                        //'>&#10004;</span><label class="custom-control-label" for="UpdateRights_' + UserInfo.EmpID +
                        //'">Update</label></td>' +
                        '<td align="left">' +
                         '<div class="blue-square-container">' +
                        '<div class="custom-control custom-checkbox blue-square">' +
                        '<input type="checkbox" class="custom-control-input" id="ViewRights_' + UserInfo.EmpID + '" ' + IsCheck + '>' +
                        '<label class="custom-control-label" for="ViewRights_' + UserInfo.EmpID + '">View</label>' +
                         '</div>' +
                        '</div>' +
                        '</td>' +

                        '<td align="center">' +
                        '<div class=" blue-square-container">' +
                        '<div class="custom-control custom-checkbox blue-square">' +
                        '<input type="checkbox" class="custom-control-input" id="UpdateRights_' + UserInfo.EmpID + '" ' + IsCheck1 + '>' +
                        '<label class="custom-control-label" for="UpdateRights_' + UserInfo.EmpID + '">Update</label>' +
                          '</div>' +
                        '</div>' +
                        '</td>' +
                   '</tr>')
                    console.log(UserInfo.EmpID + "___" + UserInfo.EmpName + "____" + UserInfo.V_Rights + "____" + UserInfo.U_Rights);
                });



            })
            .fail(function (stat, msg, custom) {
                console.log("awitdsadas4");
                toastr.warning(stat.status + ": " + custom)
            });
    }
    //-----------------------------------------------------------------
    UserAccess();
    function UserAccess() {
        $.post("/ViewAllUser/UserAccess")
            .done(function (data) {

                data = JSON.parse(data);


                $(data).each(function (i, UserInfo1) {
                    console.log("33333333");
                    console.log(UserInfo1.Empname);
                    $("#UserFname").html(UserInfo1.Empname);
                    $("#UserType").html(UserInfo1.UserType);
                });
            })
            .fail(function (stat, msg, custom) {
                console.log("8888");
            });
    }



});