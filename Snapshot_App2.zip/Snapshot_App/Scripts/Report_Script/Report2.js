﻿$(document).ready(function () {
    document.getElementById('btnSave_FS').disabled = true;
    document.getElementById('btnExport_FS').disabled = true;

    //-----------------------------------------------------------------
    var AllowAdd;
    var AllowEdit;
    var AllowDelete;
    var AllowView;
    var AllowPrint;
    var AllowImport
    var AllowExport;
    var AllowPost;
    var AllowUnpost;
    var AllowApprove;
    //-----------------------------------------------------------------
    $.ajax({
        type: "POST",
        url: "/CBS/Common/Permissions",
        success: function (data) {
            data = JSON.parse(data)
            AllowAdd = data[0]["Add"]
            AllowEdit = data[0]["Edit"];
            AllowDelete = data[0]["Delete"];
            AllowView = data[0]["View"];
            AllowPrint = data[0]["Print"];
            AllowImport = data[0]["Import"];
            AllowExport = data[0]["Export"];
            AllowPost = data[0]["Post"];
            AllowUnpost = data[0]["Unpost"];
            AllowApprove = data[0]["Approve"];
        },
        async: false

    })
    //-------------------------------

    function getBool(val) {
        return !!JSON.parse(String(val).toLowerCase());
    }
    //-----------------------------------------------------------------


    $.post("/CBS/Common/GetBranch", function (data) {
        data = JSON.parse(data);
        var cboBranch_FS = $("#cboBranch_FS");
        cboBranch_FS.html('');
        $(data).each(function (index, br) {
            cboBranch_FS.append('<option value="' + br.Whscode + '">' + br.whsName + '</option>');
        });
    });
    //----------------------------------------------------------------
    $.post("/CBS/TrialBalance/GetMonths", function (data) {
        data = JSON.parse(data);
        var cboMonth_FS = $("#cboMonth_FS");
        cboMonth_FS.html('');
        $(data).each(function (index, br) {
            cboMonth_FS.append('<option value="' + br.MonthNum + '">' + br.MonthName + '</option>');
        });
    });
    //----------------------------------------------------------------
    $.post("/CBS/TBFS/GetType", function (data) {
        data = JSON.parse(data);
        var cboType_FS = $("#cboType_FS");
        cboType_FS.html('');
        $(data).each(function (index, br) {
            cboType_FS.append('<option value="' + br.TBtypeCode + '">' + br.TBtype + '</option>');
        });
    });
    //----------------------------------------------------------------
    function GenerateFS(branch,month,year,tbtype,posted)
    {
      

     if (year == "")
        {
            toastr.info("Year is Required", "Notification");
        }
     else if (year.length != 4) {
            toastr.error("Invalid Year", "Notification");
        }
       
     else {

            $(".preloader-it").fadeIn(); //show
            
            $("#tblFS_Header tbody tr").remove();
            $("#tblFS_Header").DataTable().clear().draw();
            $("#tblFS_Header").DataTable().destroy();

            $.post("/CBS/TBFS/GenerateFS", { Branch: branch, Month: month, Year: year, TBType: tbtype, posted: posted })
             .done(function (data) {
                 data = JSON.parse(data);
                 var tblFS_Body = $("#tblFS_Body");
                 tblFS_Body.html("");

                 $(data).each(function (i, TrialBalance) {
                     var RorNum = parseInt(i) + 1
                     tblFS_Body.append('<tr>' +
                             '<td>' + RorNum + '</td>' +
                             '<td>' + TrialBalance.isMod + '</td>' +
                             '<td>' + TrialBalance.DocEntry + '</td>' +
                             '<td>' + TrialBalance.TBtype + '</td>' +
                             '<td>' + TrialBalance.Desc + '</td>' +
                             '<td class="text-right">' + numeral(TrialBalance.BegAmt).format("0,0.00") + '</td>' +
                             '<td class="text-right">' + numeral(TrialBalance.NetAmt).format("0,0.00") + '</td>' +
                             '<td class="text-right">' + numeral(TrialBalance.EndAmt).format("0,0.00") + '</td>' +
                             '<td align="middle">' +
                                '<button type="button" id="btnView_FS" class="btn btn-xs btn-outline-primary btn-rounded" title="Click to View Transactions" ' +
                                ' data-DocEntry ="' + TrialBalance.DocEntry + '"' +
                                ' data-TBtype ="' + TrialBalance.TBtype + '"' +
                                ' data-Desc ="' + TrialBalance.Desc + '"' +
                                ' data-Mod ="' + TrialBalance.isMod + '"' +
                                ' >' +
                                '<i class="fa fa-folder-open"></i>' +
                                '</button > ' +
                              '</td > ' +
                         '</tr>')

                 });

                 if (data.length > 0)
                 {
                     document.getElementById('btnSave_FS').disabled = false;
                     document.getElementById('btnExport_FS').disabled = false;
                 }
             

                 $(".preloader-it").fadeOut("slow");
                 $("#tblFS_Header").DataTable().draw();






             })
             .fail(function (stat, msg, custom) {
                 document.getElementById('btnSave_FS').disabled = true;
                 document.getElementById('btnExport_FS').disabled = true;
                    $(".preloader-it").fadeOut("slow");
                    toastr.warning(stat.status + ": " + custom)
                });
        }
    }
    //----------------------------------------------------------------
    $("#btnGenerate_FS").on("click", function () {
        var branch = $("#cboBranch_FS").val();
        var month = $("#cboMonth_FS").val();
        var year = $("#txtyear_FS").val();
        var tbtype = $("#cboType_FS").val();
        var posted = document.getElementById("ChkPosted_FS").checked;
               
        GenerateFS(branch, month, year, tbtype, posted);
    });
    //----------------------------------------------------------------
    function ViewFS(branch_Name, branch, month, year, docentry, desc, Mod) {
        $("#FSDet_Branch").val(branch_Name);
        $("#FSDet_DocEntry").val(docentry);
        $("#FSDet_Desc").val(desc);
        $("#FSDet_Mod").val(Mod);

        $("#tblFSDetal_Header tbody tr").remove();
        $("#tblFSDetal_Header").DataTable().clear().draw();
        $("#tblFSDetal_Header").DataTable().destroy();

        $.post("/CBS/TBFS/GenerateFSDetail", { Branch: branch, DocEntry: docentry, Month: month, Year: year, mod: Mod })
        .done(function (data) {
            data = JSON.parse(data);
            var tblFSDetal_Body = $("#tblFSDetal_Body");
            tblFSDetal_Body.html("");

            $(data).each(function (i, TrialBalance) {

                var totalrowcolor;
                var btnStat;
                if (TrialBalance.AcctName.match("TOTAL")) {
                    totalrowcolor = "background-color: #61646094;color: white;font-size: 12px;font-weight: bold;"
                    btnStat = "hidden";
                }
                else {
                    totalrowcolor = "";
                    btnStat = "";
                }
                var row;
                if (TrialBalance.RowNo == 0) { row = " "; }
                else { row = TrialBalance.RowNo; }

                tblFSDetal_Body.append('<tr style="' + totalrowcolor + '" >' +
                    '<td>' + row + '</td>' +
                    '<td>' + TrialBalance.FormatCode + '</td>' +
                    '<td>' + TrialBalance.AcctName + '</td>' +
                    '<td class="text-right">' + numeral(TrialBalance.BegAmt).format("0,0.00") + '</td>' +
                    '<td class="text-right">' + numeral(TrialBalance.CurrAmt).format("0,0.00") + '</td>' +
                    '<td class="text-right">' + numeral(TrialBalance.EndAmt).format("0,0.00") + '</td>' +
                    '</tr>')
            });  
           
            $("#tblFSDetal_Header").DataTable({
                //scrollX: true,
                ordering: false//,

            }).draw();
            $("#mod-ViewDetail_FS").modal("show");


        })
        .fail(function (stat, msg, custom) {
             toastr.warning(stat.status + ": " + custom)
        });
    }
    //----------------------------------------------------------------
    $("#tblFS_Header").on("click","#btnView_FS", function () {
        if (getBool(AllowView) == false) {
            toastr.info("Access Denied!", "Notification");
            return;
        }


        var cboBranch_FS = document.getElementById("cboBranch_FS")
        var branch_Name = cboBranch_FS.options[cboBranch_FS.selectedIndex].text;
        var branch = $("#cboBranch_FS").val();
        var month = $("#cboMonth_FS").val();
        var year = $("#txtyear_FS").val();
        var docentry = $(this).attr("data-DocEntry");
        var desc = $(this).attr("data-Desc");
        var Mod = $(this).attr("data-Mod");
        ViewFS(branch_Name, branch, month, year, docentry, desc, Mod);
    });
    //--------------------------------------------------------
    $("#btnSave_FS").on("click", function () {
        if (getBool(AllowAdd) == false) {
            toastr.info("Access Denied!", "Notification");
            return;
        }


        var branch = $("#cboBranch_FS").val();
        var month = $("#cboMonth_FS").val();
        var year = $("#txtyear_FS").val();
        var Post = 0;
        if (month == 13) { Post = 1; }

        var FSData = [];
        var data = $("#tblFS_Header").DataTable().rows().data();
        data.each(function (value, index) {
            FSData.push({
                "DocEntry": value[2],
                "BegAmt": numeral(value[5]).value(),
                "CurrAmt": numeral(value[6]).value(),
                "EndAmt": numeral(value[7]).value()

            })       
        })

        if (FSData.length > 0)
        {
            $.confirm({
                title: "Confirmation",
                content: "Save Record/s",
                buttons: {
                    yes: function () {
                        $.post("/CBS/TBFS/ValidateBeforeDeletion", { Branch: branch, Month: month, Year: year })
                        .done(function (data) {
                            data = JSON.parse(data);
                            if (data == "-4")
                            {
                                $.confirm({
                                    title: "Confirmation",
                                    content: "Posted record/s already exists. would you like to overwrite?",
                                    buttons:{
                                        yes: function () {
                                            $(".preloader-it").fadeIn(); //show
                                            $.post("/CBS/TBFS/SaveFS", { FSData: FSData, branch: branch, Month: month, Year: year, isExist:true  })
                                            .done(function (data) {
                                                data = JSON.parse(data);
                                                $(".preloader-it").fadeOut("slow");
                                                toastr.success("Record Successfully Saved!.", "Notification");
                                            })

                                             .fail(function (stat, msg, custom) {
                                                 $(".preloader-it").fadeOut("slow");
                                                 toastr.info(stat.status + ": " + custom)
                                             })
                                        },
                                        cancel: function(){}
                                    }
                                })
                            }
                            //----
                            else
                            {
                                $(".preloader-it").fadeIn(); //show
                                $.post("/CBS/TBFS/SaveFS", { FSData: FSData, branch: branch, Month: month, Year: year, isExist: false })
                                .done(function (data) {
                                    data = JSON.parse(data);
                                    $(".preloader-it").fadeOut("slow");
                                    toastr.success("Record Successfully Saved!.", "Notification");
                                })

                                 .fail(function (stat, msg, custom) {
                                     $(".preloader-it").fadeOut("slow");
                                     toastr.info(stat.status + ": " + custom)
                                 })
                            }
                        })
                         .fail(function (stat, msg, custom) {
                             $(".preloader-it").fadeOut("slow");
                             toastr.info(stat.status + ": " + custom)
                         })
                    },
                    cancel: function () { }

                }

            })


        }







    });
    //--------------------------------------------------------
    $("#btnExport_FS").on("click", function () {

        if (getBool(AllowExport) == false) {
            toastr.info("Access Denied!", "Notification");
            return;
        }

        $.confirm({
            title: "Confirmation",
            content: "Export Records?",
            buttons:{
                yes: function () {

                    $(".preloader-it").fadeIn(); //show
                    var branchCode = $("#cboBranch_FS").val();

                    var cbo = document.getElementById("cboBranch_FS");
                    var BranchName = cbo.options[cbo.selectedIndex].text;

                    var month = $("#cboMonth_FS").val();
                    var year = $("#txtyear_FS").val();
                    var posted = document.getElementById("ChkPosted_FS").checked;
                    $.post("/CBS/TBFS/ExportData", { branchname: BranchName, branch: branchCode, Month: month, Year: year, Posted: posted })
                    .done(function (data) {
                        window.location = '/CBS/TrialBalance/Download?fileGuid=' + data.FileGuid + '&filename=' + data.FileName;
                        $(".preloader-it").fadeOut("slow");
                        toastr.success("Record successfully Exported.", "Notification");
                    })
                    .fail(function (stat, msg, custom) {
                        $(".preloader-it").fadeOut("slow");
                        toastr.info(stat.status + ": " + custom)
                    })



                },
                cancel: function () { }
            }
        })
    })
    //--------------------------------------------------------
    function LoadFormulas(branch, selectedText) {
        //var branch = $("#cboBranch_FS").val();
        //var branchName = document.getElementById("cboBranch_FS");
        //var selectedText = branchName.options[branchName.selectedIndex].text;

        $("#txtBranchformula_FS").val(selectedText);


        $("#tblFSFormula_Header tbody tr").remove();
        $("#tblFSFormula_Header").DataTable().clear().draw();
        $("#tblFSFormula_Header").DataTable().destroy();

        $.post("/CBS/TBFS/LoadFormulaPerBranch", { branch: branch })
            .done(function (data) {
                data = JSON.parse(data);


                var tblFSFormula_Body = $("#tblFSFormula_Body");
                tblFSFormula_Body.html("");

                $(data).each(function (i, TrialBalance) {
                    var RowNum = parseInt(i) + 1
                    tblFSFormula_Body.append('<tr>' +
                        '<td>' + RowNum + ' </td>' +
                        '<td>' + TrialBalance.DocEntry + ' </td>' +
                        '<td>' + TrialBalance.RowNo + ' </td>' +
                        '<td>' + TrialBalance.Desc + ' </td>' +
                        '<td>' + TrialBalance.TBtypeCode + ' </td>' +
                        '<td>' + TrialBalance.BegFormula + ' </td>' +
                        '<td>' + TrialBalance.CurrFormula + ' </td>' +
                        '<td>' + TrialBalance.EndFormula + ' </td>' +
                        '<td align="middle">' +
                                '<button type="button" id="btnUpdateFormula_FS" class="btn btn-xs btn-outline-primary btn-rounded" title="Click to Update Records" ' +
                                ' data-DocEntry ="' + TrialBalance.DocEntry + '"' +
                                ' data-RowNo ="' + TrialBalance.RowNo + '"' +
                                ' data-Desc ="' + TrialBalance.Desc + '"' +
                                ' data-TBtypeCode ="' + TrialBalance.TBtypeCode + '"' +
                                ' data-BegFormula ="' + TrialBalance.BegFormula + '"' +
                                ' data-CurrFormula ="' + TrialBalance.CurrFormula + '"' +
                                ' data-EndFormula ="' + TrialBalance.EndFormula + '"' +
                                ' data-BranchCode ="' + branch + '"' +
                                ' data-BranchName ="' + selectedText + '"' +
                                ' > <i class="fa fa-edit"></i> </button > ' +
                        '</td > ' +
                        '</tr>')


                });

                $("#tblFSFormula_Header").DataTable().draw();
                $("#mod-Formulas_FS").modal("show");

            })
            .fail(function (stat, msg, custom) {
                //$(".preloader-it").fadeOut("slow");
                toastr.info(stat.status + ": " + custom)
            })
    }
    //--------------------------------------------------------
    $("#btnFormulas_FS").on("click", function () {

        if (getBool(AllowView) == false) {
            toastr.info("Access Denied!", "Notification");
            return;
        }


            var branch = $("#cboBranch_FS").val();
            var branchName = document.getElementById("cboBranch_FS");
            var selectedText = branchName.options[branchName.selectedIndex].text;
            LoadFormulas(branch,selectedText);
    })
    //--------------------------------------------------------
    $("#mod-Formulas_FS").on("click", "#btnUpdateFormula_FS", function () {

        if (getBool(AllowEdit) == false) {
            toastr.info("Access Denied!", "Notification");
            return;
        }

        var branchcode = $(this).attr("data-BranchCode");
        var DocEntry = $(this).attr("data-DocEntry");
        var Desc = $(this).attr("data-Desc");
        var Beg = $(this).attr("data-BegFormula");
        var Curr = $(this).attr("data-CurrFormula");
        var End = $(this).attr("data-EndFormula");


        $("#txtBranchCode_FS").val(branchcode);
        $("#txtDocEntry_FS").val(DocEntry);
        $("#txtDesc_FS").val(Desc);
        $("#txtBegFormula_FS").val(Beg);
        $("#txtCurrFormula_FS").val(Curr);
        $("#txtEndFormula_FS").val(End);


        $("#mod-Formulas_FS").modal("hide");
        $("#mod-UpdateFormula_FS").modal("show");
    })
    //--------------------------------------------------------
    $("#mod-UpdateFormula_FS").on("click", "#CloseUpdateFormulas_FS", function () {
        var branchcode = $("#txtBranchCode_FS").val();
        var branchName = document.getElementById("cboBranch_FS");
        var selectedText = branchName.options[branchName.selectedIndex].text;
        $("#mod-UpdateFormula_FS").modal("hide");
        LoadFormulas(branchcode, selectedText);
    })
   
    $("#mod-UpdateFormula_FS").on("click", "#btnCancelFormula_FS", function () {
        var branchcode = $("#txtBranchCode_FS").val();
        var branchName = document.getElementById("cboBranch_FS");
        var selectedText = branchName.options[branchName.selectedIndex].text;
        $("#mod-UpdateFormula_FS").modal("hide");
        LoadFormulas(branchcode, selectedText);
    })
    //-------------------------------------------------------
    $("#mod-Formulas_FS").on("click", "#btnNewFormulas_FS", function () {

        if (getBool(AllowAdd) == false) {
            toastr.info("Access Denied!", "Notification");
            return;
        }
        
        $("#txtBranchCode_FS").val($("#cboBranch_FS").val());
        $("#txtDocEntry_FS").val("");
        $("#txtDesc_FS").val("");
        $("#txtBegFormula_FS").val("");
        $("#txtCurrFormula_FS").val("");
        $("#txtEndFormula_FS").val("");

        $("#mod-Formulas_FS").modal("hide");
        $("#mod-UpdateFormula_FS").modal("show");
    })

    //-------------------------------------------------------
    $("#mod-UpdateFormula_FS").on("click", "#btnUpdateFormula_FS", function () {
        
        var branchName = document.getElementById("cboBranch_FS");
        var selectedText = branchName.options[branchName.selectedIndex].text;
        var branchcode = $("#txtBranchCode_FS").val();
        var DocEntry = $("#txtDocEntry_FS").val();
        var Desc = $("#txtDesc_FS").val();
        var Beg = $("#txtBegFormula_FS").val();
        var Curr = $("#txtCurrFormula_FS").val();
        var End = $("#txtEndFormula_FS").val();

        $.confirm({
            title: "Confirmation",
            content: "Update Record?",
            buttons: {
                yes: function () {
                    $.post("/CBS/TBFS/UpdateFormulas", { Desc: Desc, Beg: Beg, Curr: Curr, Ending: End, Branch: branchcode, DocEntry: DocEntry })
                    .done(function () {
                        $("#mod-UpdateFormula_FS").modal("hide");
                        LoadFormulas(branchcode, selectedText);
                    })
                    .fail(function (stat, msg, custom) {
                          //$(".preloader-it").fadeOut("slow");
                          toastr.info(stat.status + ": " + custom)
                      })
                },
                cancel: function () { }
            }
        })

    })

    //-------------------------------------------------------
    $("#btnImport_FS").on("click", function () {

        if (getBool(AllowImport) == false) {
            toastr.info("Access Denied!", "Notification");
            return;
        }



        var branchCode = $("#cboBranch_FS").val();
        var branchName = document.getElementById("cboBranch_FS");
        var selectedText = branchName.options[branchName.selectedIndex].text;

        $.post("/CBS/TBFS/CheckBeginningifExist", { Branch: branchCode })
        .done(function (data) {
            data = JSON.parse(data);
            if (data == 1)         
                {
                    toastr.info("Setup for selected branch already exists.", "Notification");
                }
            else
                {
                $.confirm({
                    title: "Confirmation",
                    content: "Import data for " + selectedText + "?",
                    buttons:{
                        yes: function () {
                            $("#txtImportFile_FS").val("");
                            $('.custom-file-label').html("Choose file...");

                            $("#tblImportFS_Header tbody tr").remove();
                            $("#tblImportFS_Header").DataTable().clear().draw();
                            $("#tblImportFS_Header").DataTable().destroy();

                            $("#mod-ImportFS").modal("show");

                        },
                        Cancel: function () { }
                    }

                });

                }
        })
       .fail(function (stat, msg, custom) {
        toastr.info(stat.status + ": " + custom)
       })

      


    });

    //-------------------------------------------------------
    $("#mod-ImportFS").on("change", "#txtImportFile_FS", function () {
        var fileName = $(this).val();
        $(this).next('.custom-file-label').html(fileName.replace('C:\\fakepath\\', " "));
    })

    //----------------------------------------------------
    $("#mod-ImportFS").on("click", "#btnLoadExcelData_FS", function () {
        var formData = new FormData();
        var fileInput = document.getElementById("txtImportFile_FS")
        for (i = 0; i < fileInput.files.length; i++) {
            formData.append(fileInput.files[i].name, fileInput.files[i]);
        }

        $("#tblImportFS_Body").html('');
        $.ajax({
            url: "/CBS/TBFS/ImportFS",
            type: "POST",
            processData: false,
            contentType: false,
            data: formData,
            success: function (data) {
                $("#tblImportFS_Header tbody tr").remove();
                $("#tblImportFS_Header").DataTable().clear().draw();
                $("#tblImportFS_Header").DataTable().destroy();

                var tblImportFS_Body = $("#tblImportFS_Body");
                tblImportFS_Body.html("");

                $(data).each(function (i, TrialBalance) {
                    var row = parseInt(i + 1);
                    var BegF = "";
                    var CurrF = "";
                    var EndF = "";
                    if (TrialBalance.BegFormula != "") { BegF = "=" + TrialBalance.BegFormula; }
                    if (TrialBalance.CurrFormula != "") { CurrF = "=" + TrialBalance.CurrFormula; }
                    if (TrialBalance.EndFormula != "") { EndF = "=" + TrialBalance.EndFormula; }
                    
                    tblImportFS_Body.append('<tr>' +
                        '<td>' + row + '</td>' +
                        '<td>'+ TrialBalance.Desc +'</td>' + 
                        '<td>'+ TrialBalance.RowNo +'</td>' + 
                        '<td class="text-right">' + numeral(TrialBalance.TransAmount).format("0,0.00") + '</td>' +
                        '<td>' + TrialBalance.TBtypeCode + '</td>' +
                         '<td>' + BegF + '</td>' +
                         '<td>' + CurrF + '</td>' +
                         '<td>' + EndF + '</td>' +
                        '<td>' + TrialBalance.DescFontstyle + '</td>' +
                        '<td>' + TrialBalance.AmtFontstyle + '</td>' +
                        '<td>' + TrialBalance.DescFontcolor + '</td>' +
                        '<td>' + TrialBalance.AmtFontcolor + '</td>' +
                        '<td>' + TrialBalance.DescBG + '</td>' +
                        '<td>' + TrialBalance.AmtGB + '</td>' +
                        '<td>' + TrialBalance.DescTopBorder + '</td>' +
                        '<td>' + TrialBalance.DescBotBorder + '</td>' +
                        '<td>' + TrialBalance.AmtTop  + '</td>' +
                        '<td>' + TrialBalance.AmtBot  + '</td>' +
                        '<td>' + TrialBalance.IsHidden + '</td>' +
                        '</tr>')
                   
                });
                $("#tblImportFS_Header").DataTable({
                    scrollX: true
                }).draw();
                
            },

      

            
            error: function (stat, msg, custom) {

                $(".preloader-it").fadeOut('slow');
                toastr.info(stat.status + ": " + custom);
            }
            });


    })
    
    //----------------------------------------------
    $("#mod-ImportFS").on("click", "#btnSave_WSAddBegAmnt", function () {
        var branchCode = $("#cboBranch_FS").val();
        var branchName = document.getElementById("cboBranch_FS");
        var selectedText = branchName.options[branchName.selectedIndex].text;


        var ImportedData = [];
        var tblImportFS_Header = $("#tblImportFS_Header").DataTable().rows().data();
        tblImportFS_Header.each(function (value, index) {
            ImportedData.push({
                "Desc": value[1],
                "BranchCode": branchCode,
                "RowNo": value[2],
                "TBtypeCode": value[4],
                "BegFormula": value[5],
                "CurrFormula": value[6],
                "EndFormula": value[7],
                "DescFontstyle": value[8],
                "AmtFontstyle": value[9],
                "DescFontcolor": value[10],
                "AmtFontcolor": value[11],
                "DescBG": value[12],
                "AmtGB": value[13],
                "DescTopBorder": value[14],
                "DescBotBorder": value[15],
                "AmtTop": value[16],
                "AmtBot": value[17],
                "IsHidden": value[18]
            });
        });
      
        if (ImportedData.length != 0)
        {
            $.confirm({
                title: "Confirmation",
                content: "Save Financial Statement Beginning Setup for " + selectedText + "?",
                buttons: {
                    yes: function () {
                        $(".preloader-it").fadeIn(); //show
                         $.post("/CBS/TBFS/SaveImportedSetup", { ImportedData: ImportedData, branch: branchCode })
                         .done(function () {
                              $(".preloader-it").fadeOut("slow");
                              toastr.success("Record Successfully Saved!.", "Notification");

                         })
                         .fail(function (stat, msg, custom) {
                              $(".preloader-it").fadeOut("slow");
                              toastr.info(stat.status + ": " + custom)
                          })

                    },
                    cancel: function () { }
                }


            })
        }
        else
        {
            toastr.info("No Records to Save","Notification")
        }
    })

    //---------------------------------------------

})
