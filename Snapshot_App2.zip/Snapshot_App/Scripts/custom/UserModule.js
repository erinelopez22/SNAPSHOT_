﻿$(document).ready(function () {
   
  
        $.post("/CBS/Login/UserModule")
          .done(function (data) {
              data = JSON.parse(data);
              //console.log(data);
                  $(data).each(function (i, Modules) {
                      if (Modules.isHidden == "1")
                      {
                     

                          var elem = document.getElementById(Modules.HtmlID);
                          if (typeof elem !== 'undefined' && elem !== null)
                          {
                              //document.getElementById(Modules.HtmlID).style.display = "none";
                              document.getElementById(Modules.HtmlID).remove();
                              if (Modules.HtmlTabID != Modules.HtmlID)
                              {
                                  var elemTab = document.getElementById(Modules.HtmlTabID);
                                  if (typeof elemTab !== 'undefined' && elemTab !== null) {
                                      document.getElementById(Modules.HtmlTabID).remove();
                                      
                                  }
                              }
                          }

                      }



                  })
               })
           .fail(function (stat, msg, custom) {
               toastr.warning(custom)
           })
    
})