﻿$(document).ready(function () {
    //onload---------------------------
    SetDate()
    Purchases()
    //events---------------------------
    $(".list-group").on("click", ".list-group-item", function() {
        $(".list-group-item").removeClass("text-primary")
        $(".list-group-item").removeClass("active")
        $(this).addClass("text-primary")
    })

    $("#table-purchases").DataTable({
        scrollX: true
    })

    //functions------------------------
    function SetDate() {
        console.log("Set Date")
        $.get("../../Reports/Books/GetDate", function (date) {
            var datenow = moment(date).format("YYYY-MM-DD")
            $("#card-purchases input[name='startdate']").val(datenow)
            $("#card-purchases input[name='enddate']").val(datenow)
        })
        .fail(function (stat, msg, custom) {
            toastr.error(custom)
        })
    }

    function Purchases() {
        var obj = {
            startdate: '2018-01-01',
            enddate: '2018-01-31',
            branchcode: '002',
            type: 'include'
        }

        $.get("../../Reports/Books/Purchases",obj, function(data) {
            console.table(data)
        })
        .fail(function(stat,msg,custom) {
            toastr.error(custom)
        })
    }
})
