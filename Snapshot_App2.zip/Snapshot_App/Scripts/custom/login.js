﻿$(document).ready(function() {
    //onload------------------------

    //events------------------------
    $("#btn-login").on("click", function(e) {
        e.preventDefault()
        var user = $("input#username").val()
        var pass = $("input#password").val()
        Login(user,pass)
    })
    //functions---------------------
    function Login(user, pass) {

        if (user == "")
        {
            toastr.info("Username is required", "Notification")
            document.getElementById("username").focus();
        }
        else if (pass == "")
        {
            toastr.info("Password is required", "Notification")
            document.getElementById("password").focus();
        }
        else {
            $.post("/CBS/Login/Login", { Username: user, Password: pass })
               .done(function (response) {
    
                   //--------------------------------------------------------------------------
                   $.post("/CBS/Login/UserModule")
        .done(function (data) {
            data = JSON.parse(data);
            console.log(data);
            $(data).each(function (i, Modules) {
                if (Modules.isHidden == "1") {


                    var elem = document.getElementById(Modules.HtmlID);
                    if (typeof elem !== 'undefined' && elem !== null) {
                        //document.getElementById(Modules.HtmlID).style.display = "none";
                        document.getElementById(Modules.HtmlID).remove();
                        if (Modules.HtmlTabID != Modules.HtmlID) {
                            var elemTab = document.getElementById(Modules.HtmlTabID);
                            if (typeof elemTab !== 'undefined' && elemTab !== null) {
                                document.getElementById(Modules.HtmlTabID).remove();

                            }
                        }
                    }

                }
            })
        })
        .fail(function (stat, msg, custom) {
            toastr.warning(custom)
        })


                   //-------------------------------------------------------------------------













                   $(".preloader-it").fadeIn(); //show
                   window.location.replace("/CBS/Home/Index")
                   $(".preloader-it").fadeOut("slow");
               })
               .fail(function (stat, msg, custom) {
                   $(".preloader-it").fadeOut("slow");
                   toastr.warning(custom)
               })
        }
       
    }

    
    function ShowPassword() {
        var x = document.getElementById("password");
        if (x.type === "password") {

            
            x.type = "text";
        } else {

            x.type = "password";

        }
    }

    $("#showpass").on("click", function () {
    
        ShowPassword()
    })

})