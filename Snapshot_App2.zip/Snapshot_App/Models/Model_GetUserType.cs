﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Snapshot_App.Models
{
    public class Model_GetUserType
    {
        public string UserID { get; set; }
        public string UserType { get; set; }
    }
}