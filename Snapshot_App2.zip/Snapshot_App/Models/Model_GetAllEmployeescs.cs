﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Snapshot_App.Models
{
    public class Model_GetAllEmployeescs
    {
        public string UserID { get; set; }
        public string FName { get; set; }
    }
}