﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Snapshot_App.Models
{
    public class Model_GetMonth
    {
        public int MonthNum { get; set; }
        public string MonthName { get; set; }
    }
}